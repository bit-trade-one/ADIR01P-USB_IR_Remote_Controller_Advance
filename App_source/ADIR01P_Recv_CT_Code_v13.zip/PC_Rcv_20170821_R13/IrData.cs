﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace IR_Remote_Control_Pro
{
    public class IrData
    {
        [System.Xml.Serialization.XmlElement("IR_FREQ")]
        public int[] ir_freq = new int[Constants.IR_DATA_REC_NUM];			// 周波数
        [System.Xml.Serialization.XmlElement("IR_DATA_SIZE")]
        public int[] ir_data_size = new int[Constants.IR_DATA_BUFF_SIZE];	// データサイズ

        public IrData()
        {
            int fi;
            try
            {
                for(fi = 0; fi < 32; fi++)
                {
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                }
            }
            catch
            {
            }
        }

        public int Init(int mag_ang)
        {
            int ret = 0;
            int fi;
            try
            {
                for (fi = 0; fi < 32; fi++)
                {
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int Dispose()
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }

        private int ir_data_copy( int  p_idx, int p_ir_freq, int p_ir_data_size, byte[] p_ir_data)
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }
        private int ir_data_clear(int p_idx)
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_all_clear()
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }
    }
}
