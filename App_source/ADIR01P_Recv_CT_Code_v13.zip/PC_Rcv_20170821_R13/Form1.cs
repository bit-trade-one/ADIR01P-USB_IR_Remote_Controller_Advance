//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
/********************************************************************
 FileName:		Form1.cs
 Dependencies:	When compiled, needs .NET framework 2.0 redistributable to run.
 Hardware:		Need a free USB port to connect USB peripheral device
				programmed with appropriate Generic HID firmware.  VID and
				PID in firmware must match the VID and PID in this
				program.
 Compiler:  	Microsoft Visual C# 2005 Express Edition (or better)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�E for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively with Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS�ECONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  2.5a	07/17/2009	 Initial Release.  Ported from HID PnP Demo
                     application source, which was originally 
                     written in MSVC++ 2005 Express Edition.
********************************************************************
NOTE:	All user made code contained in this project is in the Form1.cs file.
		All other code and files were generated automatically by either the
		new project wizard, or by the development environment (ex: code is
		automatically generated if you create a new button on the form, and
		then double click on it, which creates a click event handler
		function).  User developed code (code not developed by the IDE) has
        been marked in "cut and paste blocks" to make it easier to identify.
********************************************************************/

//NOTE: In order for this program to "find" a USB device with a given VID and PID, 
//both the VID and PID in the USB device descriptor (in the USB firmware on the 
//microcontroller), as well as in this PC application source code, must match.
//To change the VID/PID in this PC application source code, scroll down to the 
//CheckIfPresentAndGetUSBDevicePath() function, and change the line that currently
//reads:

//   String DeviceIDToFind = "Vid_04d8&Pid_003f";


//NOTE 2: This C# program makes use of several functions in setupapi.dll and
//other Win32 DLLs.  However, one cannot call the functions directly in a 
//32-bit DLL if the project is built in "Any CPU" mode, when run on a 64-bit OS.
//When configured to build an "Any CPU" executable, the executable will "become"
//a 64-bit executable when run on a 64-bit OS.  On a 32-bit OS, it will run as 
//a 32-bit executable, and the pointer sizes and other aspects of this 
//application will be compatible with calling 32-bit DLLs.

//Therefore, on a 64-bit OS, this application will not work unless it is built in
//"x86" mode.  When built in this mode, the exectuable always runs in 32-bit mode
//even on a 64-bit OS.  This allows this application to make 32-bit DLL function 
//calls, when run on either a 32-bit or 64-bit OS.

//By default, on a new project, C# normally wants to build in "Any CPU" mode.  
//To switch to "x86" mode, open the "Configuration Manager" window.  In the 
//"Active solution platform:" drop down box, select "x86".  If this option does
//not appear, select: "<New...>" and then select the x86 option in the 
//"Type or select the new platform:" drop down box.  

//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------



using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Threading;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;


namespace IR_Remote_Control_Pro
{
    public partial class Form1 : Form
    {
#if DEBUG
        internal const bool __DEBUG_FLAG__ = true;    // �f�o�b�O��
#else
        internal const bool __DEBUG_FLAG__ = false;     // �����[�X��
#endif

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        internal const string DEF_VID_PID = "Vid_22EA&Pid_003A";
        internal const string DEF_VID_PID2 = "Mi_03";
        //Constant definitions from setupapi.h, which we aren't allowed to include directly since this is C#
        internal const uint DIGCF_PRESENT = 0x02;
        internal const uint DIGCF_DEVICEINTERFACE = 0x10;
        //Constants for CreateFile() and other file I/O functions
        internal const short FILE_ATTRIBUTE_NORMAL = 0x80;
        internal const short INVALID_HANDLE_VALUE = -1;
        internal const uint GENERIC_READ = 0x80000000;
        internal const uint GENERIC_WRITE = 0x40000000;
        internal const uint CREATE_NEW = 1;
        internal const uint CREATE_ALWAYS = 2;
        internal const uint OPEN_EXISTING = 3;
        internal const uint FILE_SHARE_READ = 0x00000001;
        internal const uint FILE_SHARE_WRITE = 0x00000002;
        //Constant definitions for certain WM_DEVICECHANGE messages
        internal const uint WM_DEVICECHANGE = 0x0219;
        internal const uint DBT_DEVICEARRIVAL = 0x8000;
        internal const uint DBT_DEVICEREMOVEPENDING = 0x8003;
        internal const uint DBT_DEVICEREMOVECOMPLETE = 0x8004;
        internal const uint DBT_CONFIGCHANGED = 0x0018;
        //Other constant definitions
        internal const uint DBT_DEVTYP_DEVICEINTERFACE = 0x05;
        internal const uint DEVICE_NOTIFY_WINDOW_HANDLE = 0x00;
        internal const uint ERROR_SUCCESS = 0x00;
        internal const uint ERROR_NO_MORE_ITEMS = 0x00000103;
        internal const uint SPDRP_HARDWAREID = 0x00000001;

        //Various structure definitions for structures that this code will be using
        internal struct SP_DEVICE_INTERFACE_DATA
        {
            internal uint cbSize;               //DWORD
            internal Guid InterfaceClassGuid;   //GUID
            internal uint Flags;                //DWORD
            internal uint Reserved;             //ULONG_PTR MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
        {
            internal uint cbSize;               //DWORD
            internal char[] DevicePath;         //TCHAR array of any size
        }
        
        internal struct SP_DEVINFO_DATA
        {
            internal uint cbSize;       //DWORD
            internal Guid ClassGuid;    //GUID
            internal uint DevInst;      //DWORD
            internal uint Reserved;     //ULONG_PTR  MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct DEV_BROADCAST_DEVICEINTERFACE
        {
            internal uint dbcc_size;            //DWORD
            internal uint dbcc_devicetype;      //DWORD
            internal uint dbcc_reserved;        //DWORD
            internal Guid dbcc_classguid;       //GUID
            internal char[] dbcc_name;          //TCHAR array
        }

        internal struct ST_IR_DATA_INFO
        {
            internal uint ir_freq;
            internal uint ir_data_byte_size;
            internal uint ir_data_bit_len;
            internal byte device_type;
            internal byte device_data_size;
            internal byte[] device_data;
            internal byte memo_byte_size;
            internal byte[] memo_data;

            internal void init()
            {
                ir_freq = 38000;
                ir_data_byte_size = 0;
                ir_data_bit_len = 0;
                device_type = 0;
                device_data_size = 8;
                device_data = new byte[device_data_size];
                memo_byte_size = 0;
                memo_data = new byte[0x100];
            }
            internal void clr()
            {
                //ir_freq = 38000;
                ir_freq = 0;
                ir_data_byte_size = 0;
                ir_data_bit_len = 0;
                device_type = 0;
                device_data_size = 8;
                for (int fi = 0; fi < device_data.Length; fi++)
                {
                    device_data[fi] = 0;
                }
                memo_byte_size = 0;
                for (int fi = 0; fi < memo_data.Length; fi++)
                {
                    memo_data[fi] = 0;
                }
            }
            internal void get(ref uint o_freq, ref uint o_byte_size, ref uint o_bit_len, ref byte o_device_type, ref byte o_device_data_size, byte[] o_devive_data, ref byte o_memo_byte_size, byte[] o_memo_data)
            {
                o_freq = ir_freq;
                o_byte_size = ir_data_byte_size;
                o_bit_len = ir_data_bit_len;
                o_device_type = device_type;
                o_device_data_size = device_data_size;
                for (int fi = 0; fi < device_data.Length && fi < o_devive_data.Length; fi++)
                {
                    o_devive_data[fi] = device_data[fi];
                }
                o_memo_byte_size = memo_byte_size;
                for (int fi = 0; fi < o_memo_data.Length; fi++)
                {
                    o_memo_data[fi] = 0;
                }
                for (int fi = 0; fi < memo_byte_size && fi < o_memo_data.Length; fi++)
                {
                    o_memo_data[fi] = memo_data[fi];
                }
            }
            internal void set(uint p_freq, uint p_byte_size, uint p_bit_len, byte p_device_type, byte p_device_data_size, byte[] p_devive_data, byte p_memo_byte_size, byte[] p_memo_data)
            {
                ir_freq = p_freq;
                ir_data_byte_size = p_byte_size;
                ir_data_bit_len = p_bit_len;
                device_type = p_device_type;
                device_data_size = p_device_data_size;
                for (int fi = 0; fi < device_data.Length && fi < p_devive_data.Length; fi++)
                {
                    device_data[fi] = p_devive_data[fi];
                }
                memo_byte_size = p_memo_byte_size;
                for (int fi = 0; fi < memo_data.Length; fi++)
                {
                    memo_data[fi] = 0;
                }
                for (int fi = 0; fi < p_memo_byte_size && fi < memo_data.Length; fi++)
                {
                    memo_data[fi] = p_memo_data[fi];
                }
            }

        }

        //internal struct SP_COMMTIMEOUTS
        //{
        //    internal uint ReadIntervalTimeout;
	    //    internal uint ReadTotalTimeoutMultiplier;
	    //    internal uint ReadTotalTimeoutConstant;
	    //    internal uint WriteTotalTimeoutMultiplier;
	    //    internal uint WriteTotalTimeoutConstant;
        //}


        //DLL Imports.  Need these to access various C style unmanaged functions contained in their respective DLL files.
        //--------------------------------------------------------------------------------------------------------------
        //Returns a HDEVINFO type for a device information set.  We will need the 
        //HDEVINFO as in input parameter for calling many of the other SetupDixxx() functions.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,     //LPGUID    Input: Need to supply the class GUID. 
            IntPtr Enumerator,      //PCTSTR    Input: Use NULL here, not important for our purposes
            IntPtr hwndParent,      //HWND      Input: Use NULL here, not important for our purposes
            uint Flags);            //DWORD     Input: Flags describing what kind of filtering to use.

	    //Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
	    //from class GUID).  We need the interface GUID to get the device path.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr DeviceInfoSet,           //Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
            IntPtr DeviceInfoData,          //Input (optional)
            ref Guid InterfaceClassGuid,    //Input 
            uint MemberIndex,               //Input: "Index" of the device you are interested in getting the path for.
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);    //Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

        //SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiDestroyDeviceInfoList(
            IntPtr DeviceInfoSet);          //Input: Give it a handle to a device info list to deallocate from RAM.

        //SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInfo(
            IntPtr DeviceInfoSet,
            uint MemberIndex,
            ref SP_DEVINFO_DATA DeviceInterfaceData);

        //SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            ref uint PropertyRegDataType,
            IntPtr PropertyBuffer,
            uint PropertyBufferSize,
            ref uint RequiredSize);

        //SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,                    //Input: Pointer to an structure which defines the device interface.  
            IntPtr  DeviceInterfaceDetailData,      //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will receive the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            ref uint RequiredSize,                  //Output (optional): The number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Overload for SetupDiGetDeviceInterfaceDetail().  Need this one since we can't pass NULL pointers directly in C#.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,               //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,       //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will contain the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            IntPtr RequiredSize,                    //Output (optional): Pointer to a DWORD to tell you the number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
        //description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
        //avoid possible build error conflicts.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr RegisterDeviceNotification(
            IntPtr hRecipient,
            IntPtr NotificationFilter,
            uint Flags);

        //Takes in a device path and opens a handle to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode, 
            IntPtr lpSecurityAttributes, 
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes, 
            IntPtr hTemplateFile);

        //Uses a handle (created with CreateFile()), and lets us write USB data to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            ref uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        //Uses a handle (created with CreateFile()), and lets us read USB data from the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            ref uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);

        //
        //[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        //static extern bool SetCommTimeouts(
        //    SafeFileHandle hFile,
        //    ref SP_COMMTIMEOUTS lpCommTimeouts);


	    //--------------- Global Varibles Section ------------------
	    //USB related variables that need to have wide scope.
	    bool AttachedState = false;						//Need to keep track of the USB device attachment status for proper plug and play operation.
	    bool AttachedButBroken = false;
        bool AttachedFirstTime = true;
        SafeFileHandle WriteHandleToUSBDevice = null;
        SafeFileHandle ReadHandleToUSBDevice = null;
        String DevicePath = null;   //Need the find the proper device path before you can open file handles.

        bool b_FlashRead = false;
        bool b_FlashWrite = false;
        bool b_FlashErase = false;
        long l_ReadAddress = -1;
        byte byte_ReadSize = 0;
        byte[] FlashReadData = new byte[64];
        long l_WriteAddress = -1;
        byte byte_WriteSize = 0;
        byte[] FlashWriteData = new byte[64];
        int byte_FlashWrite_Ans = -1;
        long l_EraseAddress = -1;
        int byte_FlashErase_Ans = -1;

        // Ir
        int ir_data_select_no = 0;
        Button[] my_select_button;
        TextBox[] my_set_data_textbox;
        TextBox[] my_memo_textbox;

        // Read
        bool b_ir_read_start_req = false;
        bool b_ir_read_stop_req = false;
        bool b_ir_read_stop_comp = false;
        bool b_ir_read_data_get_req = false;
        bool b_ir_read_data_get_comp = false;
        bool b_ir_reading_flag = false;
        int ir_read_data_rec_buff_no = 0;
        int ir_read_data_get_count = 0;
        int ir_reading_data_get_count = 0;
        int ir_reading_data_get_count_fix = 0;
        int ir_read_data_total_size = 0;
        int[] ir_freq_select_datas = new int[26] { 25000, 26000, 27000, 28000, 29000, 30000, 31000, 32000, 33000, 34000, 35000, 36000, 37000, 38000, 39000, 40000, 41000, 42000, 43000, 44000, 45000, 46000, 47000, 48000, 49000, 50000};
        const int ir_freq_select_default = 38000;
        int ir_read_start_freq = ir_freq_select_default;
        byte ir_read_result_data = 0;
        int reading_redraw_interval = 0;
        const uint ir_read_stop_on_time = 0x0008;       // �ǂݍ��ݒ�~ ON����
        const uint ir_read_stop_off_time = 0x0474;      // �ǂݍ��ݒ�~ OFF���� 30ms = 30ms / 38kHz = 1140 =0x474
        //const uint ir_read_stop_on_time = 0x0010;       // �ǂݍ��ݒ�~ ON����
        //const uint ir_read_stop_off_time = 0x1000;      // �ǂݍ��ݒ�~ OFF����
        // Send
        bool b_ir_send_data_set_req = false;
        int ir_send_data_set_pos = 0;
        int ir_send_data_set_buff_no = 0;
        const int ir_send_data_usb_send_max_size = 14;  // USB���M�P��ő��M����ő吔
        bool b_ir_send_send_req = false;
        // Data Buff
        //public const int IR_DATA_BUFF_SIZE = 32000;
        uint[] ir_read_data = new uint[Constants.IR_DATA_BUFF_SIZE];
        // Disp Buff data
        bool b_ir_data_buff_disp_req = false;
        int ir_data_buff_disp_no = 0;

        // IR Data REC
        //public const int IR_DATA_REC_NUM = 32;
        //int[,] ir_data_rec_buff = new int[Constants.IR_DATA_REC_NUM, Constants.IR_DATA_BUFF_SIZE];
        public IR_Remote_Control_Pro.IrData my_Ir_data = new IR_Remote_Control_Pro.IrData(Constants.IR_DATA_REC_NUM, Constants.IR_DATA_BUFF_SIZE);
        ST_IR_DATA_INFO ir_data_info_select;
        ST_IR_DATA_INFO[] ir_data_infos = new ST_IR_DATA_INFO[Constants.IR_DATA_REC_NUM];
        // Flash Read
        bool ir_data_info_read_req = true;
        bool[] ir_data_info_read_reqs = new bool[Constants.IR_DATA_REC_NUM];
        int ir_data_info_read_now_idx = 0;
        bool ir_data_info_read_comp = false;
        // Flash Write
        bool ir_data_info_write_req = false;
        bool[] ir_data_info_write_reqs = new bool[Constants.IR_DATA_REC_NUM];
        bool ir_data_info_write_comp = false;
        bool ir_data_info_erase_req = false;
        bool[] ir_data_info_erase_reqs = new bool[Constants.IR_DATA_REC_NUM];
        bool ir_data_info_erase_comp = false;
        

        // IR Data Code Match
        const int IR_DATA_MATCH_OK_RANGE = 5;   // �R�[�h��v���e�͈�

        // �f�o�C�X�^�C�v
        string[] device_type = new string[] { "�Ȃ�", "�}�E�X", "�L�[�{�[�h", "�{�����[��" };
        string[] device_type_disp = new string[] { "", "Mouse", "Keyboard", "Volume" };
        const int DEVICE_TYPE_NONE = 0;
        const int DEVICE_TYPE_MOUSE = 1;
        const int DEVICE_TYPE_KEYBOARD = 2;
        const int DEVICE_TYPE_VOLUME = 3;
        // �}�E�X���蓖��
        string[] mouse_select_value = new string[] { "���N���b�N", "�E�N���b�N", "�z�C�[���N���b�N", "�_�u���N���b�N", "�㉺���E�ړ�", "�z�C�[���X�N���[��" };
        string[] mouse_select_value_disp = new string[] { "Left Click", "Right Click", "Wheel Click", "Double Click", "Move", "Wheel Scroll" };
        const int MOUSE_VALUE_LEFTCLICK = 0;
        const int MOUSE_VALUE_RIGHTCLICK = 1;
        const int MOUSE_VALUE_WHEELCLICK = 2;
        const int MOUSE_VALUE_DOUBLECLICK = 3;
        const int MOUSE_VALUE_MOUSEMOVE = 4;
        const int MOUSE_VALUE_WHEELSCROLL = 5;
        const int MOUSE_DATA_SET_IDX = 0;
        const int MOUSE_X_DATA_SET_IDX = 1;
        const int MOUSE_Y_DATA_SET_IDX = 2;
        const int MOUSE_WS_DATA_SET_IDX = 3;
        byte[] mouse_set_value = new byte[] { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20 };
        // �L�[�{�[�h���蓖�� 0x01:Ctrl, 0x02:Shift, 0x04:Alt, 0x08:Win 
        byte[] keyboard_set_value = new byte[] { 0x01, 0x02, 0x04, 0x08 };
        string[] keyboard_select_value_disp = new string[] { "Ctrl", "Shift", "Alt", "Win" };
        CheckBox[] my_keyboard_modifier;
        const int KEYBOARD_DATA_MODIFIER_SET_IDX = 0;
        const int KEYBOARD_DATA_KEYCODE_SET_IDX = 2;
        byte tmp_keyboard_input_key = 0;
        // �{�����[�����蓖��
        string[] volume_select_value = new string[] { "�A�b�v", "�_�E��", "�~���[�g" };
        string[] volume_select_value_disp = new string[] { "Up", "Down", "Mute" };
        const int VOLUME_VALUE_UP = 0;
        const int VOLUME_VALUE_DOWN = 1;
        const int VOLUME_VALUE_MUTE = 2;
        byte[] volume_set_value = new byte[] { 0x01, 0x02, 0x04 };
        const int VOLUME_DATA_SET_IDX = 0;

        // Flash
        long FLASH_SECTOR_SIZE = 0x10000;
        long FLASH_IR_INFO_DATA_ADR = 0x0000;
        long FLASH_MEMO_DATA_ADR = 0x0080;
        uint FLASH_MEMO_DATA_MAX_SIZE = 0x80;
        long FLASH_IR_DATA_ADR = 0x0100;
        //long FLASH_IR_DATA_MAX_BYTE_SIZE = 0xFF00;
        long FLASH_IR_DATA_MAX_BYTE_SIZE = Constants.IR_DATA_BUFF_SIZE * 4;

        // Backup
        int backup_restore_flag = Constants.BACKUP_FLAG_NON;
        string backup_file_path = "";
        int backup_restore_progressbar_value = 0;
        int backup_restore_progressbar_max_value = 0;
        bool restore_comp_disp_enable = false;
        bool restore_reboot_flag = false;
        int backup_restore_error_code = 0;

        //�o�[�`�����L�[�R�[�h��USB�L�[�R�[�h�̕ϊ��p�z��
        byte[] VKtoUSBkey = new byte[256]{
            0x00,   //0
            0x00,   //1
            0x00,   //2
            0x00,   //3
            0x00,   //4
            0x00,   //5
            0x00,   //6
            0x00,   //7
            0x2A,   //8
            0x2B,   //9
            0x00,   //10
            0x00,   //11
            0x00,   //12
            0x28,   //13
            0x00,   //14
            0x00,   //15
            0xE1,   //16
            0xE0,   //17
            0xE2,   //18
            0x48,   //19
            0x39,   //20
            0x88,   //21
            0x00,   //22
            0x00,   //23
            0x00,   //24
            0x35,   //25
            0x00,   //26
            0x29,   //27
            0x8A,   //28
            0x8B,   //29
            0x00,   //30
            0x00,   //31
            0x2C,   //32
            0x4B,   //33
            0x4E,   //34
            0x4D,   //35
            0x4A,   //36
            0x50,   //37
            0x52,   //38
            0x4F,   //39
            0x51,   //40
            0x00,   //41
            0x00,   //42
            0x00,   //43
            0x46,   //44
            0x49,   //45
            0x4C,   //46
            0x00,   //47
            0x27,   //48
            0x1E,   //49
            0x1F,   //50
            0x20,   //51
            0x21,   //52
            0x22,   //53
            0x23,   //54
            0x24,   //55
            0x25,   //56
            0x26,   //57
            0x00,   //58
            0x00,   //59
            0x00,   //60
            0x00,   //61
            0x00,   //62
            0x00,   //63
            0x00,   //64
            0x04,   //65
            0x05,   //66
            0x06,   //67
            0x07,   //68
            0x08,   //69
            0x09,   //70
            0x0A,   //71
            0x0B,   //72
            0x0C,   //73
            0x0D,   //74
            0x0E,   //75
            0x0F,   //76
            0x10,   //77
            0x11,   //78
            0x12,   //79
            0x13,   //80
            0x14,   //81
            0x15,   //82
            0x16,   //83
            0x17,   //84
            0x18,   //85
            0x19,   //86
            0x1A,   //87
            0x1B,   //88
            0x1C,   //89
            0x1D,   //90
            0xE3,   //91
            0xE7,   //92
            0x65,   //93
            0x00,   //94
            0x00,   //95
            0x62,   //96
            0x59,   //97
            0x5A,   //98
            0x5B,   //99
            0x5C,   //100
            0x5D,   //101
            0x5E,   //102
            0x5F,   //103
            0x60,   //104
            0x61,   //105
            0x55,   //106
            0x57,   //107
            0x85,   //108
            0x56,   //109
            0x63,   //110
            0x54,   //111
            0x3A,   //112
            0x3B,   //113
            0x3C,   //114
            0x3D,   //115
            0x3E,   //116
            0x3F,   //117
            0x40,   //118
            0x41,   //119
            0x42,   //120
            0x43,   //121
            0x44,   //122
            0x45,   //123
            0x68,   //124
            0x69,   //125
            0x6A,   //126
            0x6B,   //127
            0x6C,   //128
            0x6D,   //129
            0x6E,   //130
            0x6F,   //131
            0x70,   //132
            0x71,   //133
            0x72,   //134
            0x73,   //135
            0x00,   //136
            0x00,   //137
            0x00,   //138
            0x00,   //139
            0x00,   //140
            0x00,   //141
            0x00,   //142
            0x00,   //143
            0x53,   //144
            0x47,   //145
            0x67,   //146
            0x00,   //147
            0x00,   //148
            0x00,   //149
            0x00,   //150
            0x00,   //151
            0x00,   //152
            0x00,   //153
            0x00,   //154
            0x00,   //155
            0x00,   //156
            0x00,   //157
            0x00,   //158
            0x00,   //159
            0xE1,   //160
            0xE5,   //161
            0xE0,   //162
            0xE4,   //163
            0xE2,   //164
            0xE6,   //165
            0x00,   //166
            0x00,   //167
            0x00,   //168
            0x00,   //169
            0x00,   //170
            0x00,   //171
            0x00,   //172
            0x00,   //173
            0x00,   //174
            0x00,   //175
            0x00,   //176
            0x00,   //177
            0x00,   //178
            0x00,   //179
            0x00,   //180
            0x00,   //181
            0x00,   //182
            0x00,   //183
            0x00,   //184
            0x00,   //185
            0x34,   //186
            0x33,   //187
            0x36,   //188
            0x2D,   //189
            0x37,   //190
            0x38,   //191
            0x2F,   //192
            0x00,   //193
            0x00,   //194
            0x00,   //195
            0x00,   //196
            0x00,   //197
            0x00,   //198
            0x00,   //199
            0x00,   //200
            0x00,   //201
            0x00,   //202
            0x00,   //203
            0x00,   //204
            0x00,   //205
            0x00,   //206
            0x00,   //207
            0x00,   //208
            0x00,   //209
            0x00,   //210
            0x00,   //211
            0x00,   //212
            0x00,   //213
            0x00,   //214
            0x00,   //215
            0x00,   //216
            0x00,   //217
            0x00,   //218
            0x30,   //219
            0x89,   //220
            0x32,   //221
            0x2E,   //222
            0x00,   //223
            0x00,   //224
            0x00,   //225
            0x87,   //226
            0x00,   //227
            0x00,   //228
            0x00,   //229
            0x00,   //230
            0x00,   //231
            0x00,   //232
            0x00,   //233
            0x00,   //234
            0x00,   //235
            0x00,   //236
            0x00,   //237
            0x00,   //238
            0x00,   //239
            0x00,   //240
            0x00,   //241
            0x00,   //242
            0x00,   //243
            0x00,   //244
            0x00,   //245
            0x00,   //246
            0x00,   //247
            0x00,   //248
            0x00,   //249
            0x00,   //250
            0x00,   //251
            0x00,   //252
            0x00,   //253
            0x00,   //254
            0x00,   //255
       };

        // DEBUG
        int[] Debug_Array = new int[15];    //DEBUG
        int[] Debug_Arr2 = new int[15] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        //bool b_btn_debug1 = false;
        //bool b_btn_debug2 = false;
        //bool b_btn_debug3 = false;
        //bool b_btn_debug4 = false;
        //bool b_btn_debug5 = false;
        //bool b_btn_debug6 = false;
        //bool b_btn_debug7 = false;
        //bool b_btn_debug8 = false;
        //bool b_btn_debug9 = false;
        //bool b_btn_debug10 = false;
        bool b_ir_read_data_get_req_debug = false;
        bool debug_flash_read_req = false;
        bool debug_flash_read_comp = false;
        uint debug_flash_read_start_addr = 0;
        uint debug_flash_read_size = 0;
        byte[] debug_flash_read_buff = new byte[0x10000];
        // DEBUG





        bool VersionReadReq = true;
        bool VersionReadComp = false;
        byte[] version_buff = new byte[64];




        //Globally Unique Identifier (GUID) for HID class devices.  Windows uses GUIDs to identify things.
        Guid InterfaceClassGuid = new Guid(0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30); 
	    //--------------- End of Global Varibles ------------------

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Need to check "Allow unsafe code" checkbox in build properties to use unsafe keyword.  Unsafe is needed to
        //properly interact with the unmanged C++ style APIs used to find and connect with the USB device.
        public unsafe Form1()
        {
            InitializeComponent();

            if (__DEBUG_FLAG__ == false)
            {
                this.Size = new System.Drawing.Size(1165, 714);

                groupBox2.Visible = false;
                gbx_ir_read.Visible = false;
                groupBox5.Visible = false;
            }


            //�������g�̃o�[�W���������擾����
            System.Diagnostics.FileVersionInfo fver = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location);
            this.Text += fver.FileVersion;

            //�R���g���[���z��
            my_select_button = new Button[Constants.IR_DATA_REC_NUM] {  btn_select_No01, btn_select_No02, btn_select_No03, btn_select_No04, btn_select_No05, btn_select_No06, btn_select_No07, btn_select_No08,
                                                                        btn_select_No09, btn_select_No10, btn_select_No11, btn_select_No12, btn_select_No13, btn_select_No14, btn_select_No15, btn_select_No16,
                                                                        btn_select_No17, btn_select_No18, btn_select_No19, btn_select_No20, btn_select_No21, btn_select_No22, btn_select_No23, btn_select_No24,
                                                                        btn_select_No25, btn_select_No26, btn_select_No27, btn_select_No28, btn_select_No29, btn_select_No30, btn_select_No31, btn_select_No32};
            my_set_data_textbox = new TextBox[Constants.IR_DATA_REC_NUM] {  txtbx_usb_out_No01, txtbx_usb_out_No02, txtbx_usb_out_No03, txtbx_usb_out_No04, txtbx_usb_out_No05, txtbx_usb_out_No06, txtbx_usb_out_No07, txtbx_usb_out_No08,
                                                                            txtbx_usb_out_No09, txtbx_usb_out_No10, txtbx_usb_out_No11, txtbx_usb_out_No12, txtbx_usb_out_No13, txtbx_usb_out_No14, txtbx_usb_out_No15, txtbx_usb_out_No16, 
                                                                            txtbx_usb_out_No17, txtbx_usb_out_No18, txtbx_usb_out_No19, txtbx_usb_out_No20, txtbx_usb_out_No21, txtbx_usb_out_No22, txtbx_usb_out_No23, txtbx_usb_out_No24, 
                                                                            txtbx_usb_out_No25, txtbx_usb_out_No26, txtbx_usb_out_No27, txtbx_usb_out_No28, txtbx_usb_out_No29, txtbx_usb_out_No30, txtbx_usb_out_No31, txtbx_usb_out_No32};
            my_memo_textbox = new TextBox[Constants.IR_DATA_REC_NUM] {  txtbx_memo_No01, txtbx_memo_No02, txtbx_memo_No03, txtbx_memo_No04, txtbx_memo_No05, txtbx_memo_No06, txtbx_memo_No07, txtbx_memo_No08,
                                                                        txtbx_memo_No09, txtbx_memo_No10, txtbx_memo_No11, txtbx_memo_No12, txtbx_memo_No13, txtbx_memo_No14, txtbx_memo_No15, txtbx_memo_No16,
                                                                        txtbx_memo_No17, txtbx_memo_No18, txtbx_memo_No19, txtbx_memo_No20, txtbx_memo_No21, txtbx_memo_No22, txtbx_memo_No23, txtbx_memo_No24,
                                                                        txtbx_memo_No25, txtbx_memo_No26, txtbx_memo_No27, txtbx_memo_No28, txtbx_memo_No29, txtbx_memo_No30, txtbx_memo_No31, txtbx_memo_No32};
            my_keyboard_modifier = new CheckBox[] { chkbx_Key_Ctrl, chkbx_Key_Shift, chkbx_Key_Alt, chkbx_Key_Win };

            ir_data_info_select.init();
            for (int fi = 0; fi < ir_data_infos.Length; fi++ )
            {
                ir_data_infos[fi].init();
            }
            for (int fi = 0; fi < ir_data_info_read_reqs.Length; fi++)
            {
                ir_data_info_read_reqs[fi] = true;
            }

            int tmp_tabidx = 201;
            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
            {
                my_select_button[fi].TabIndex = tmp_tabidx++;
                my_select_button[fi].Tag = fi;
                my_select_button[fi].Text = string.Format("No.{0:00}", fi + 1);
                my_set_data_textbox[fi].TabIndex = tmp_tabidx++;
                my_set_data_textbox[fi].Tag = fi;
                my_set_data_textbox[fi].TabStop = false;
                my_memo_textbox[fi].TabIndex = tmp_tabidx++;
                my_memo_textbox[fi].Tag = fi;
                my_memo_textbox[fi].TabStop = false;
            }
            // ���g���I�����ݒ�
            int select_idx = 0;
            for (int fi = 0; fi < ir_freq_select_datas.Length; fi++ )
            {
                cmbbx_ir_freq.Items.Add(ir_freq_select_datas[fi]);
                if (ir_freq_select_datas[fi] == ir_freq_select_default)
                {
                    select_idx = fi;
                }
            }
            cmbbx_ir_freq.SelectedIndex = select_idx;
            // �o�b�t�@No.�I�����ݒ�
            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
            {
                cmbbx_Read_Buff_No.Items.Add(fi + 1);
                cmbbx_Send_Buff_No.Items.Add(fi + 1);
                cmbbx_Disp_Buff_No.Items.Add(fi + 1);
                cmbbx_match_check_buff_no.Items.Add(fi + 1);
            }
            cmbbx_Read_Buff_No.SelectedIndex = 0;
            cmbbx_Send_Buff_No.SelectedIndex = 0;
            cmbbx_Disp_Buff_No.SelectedIndex = 0;
            cmbbx_match_check_buff_no.SelectedIndex = 0;

            // �f�o�C�X�^�C�v
            cmbbx_device_type.Items.AddRange(device_type);
            cmbbx_device_type.SelectedIndex = 0;
            // �}�E�X�ݒ�l
            cmbbx_mouse_input.Items.AddRange(mouse_select_value);
            cmbbx_mouse_input.SelectedIndex = 0;
            // �{�����[���ݒ�l
            cmbbx_volume_input.Items.AddRange(volume_select_value);
            cmbbx_volume_input.SelectedIndex = 0;


            // ���߂Ȃǂ̂��߂ɐe�ݒ�
            gbx_Setting.Parent = this;
            gbx_Setting_list.Parent = this;


            // �ۑ��o�b�t�@����R�s�[
            my_Ir_data.ir_data_get(ir_data_select_no, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);
            // Select�f�[�^�\��
            my_select_data_disp(ir_data_select_no);



            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
			//Additional constructor code

            //Initialize tool tips, to provide pop up help when the mouse cursor is moved over objects on the form.
            //Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
            DEV_BROADCAST_DEVICEINTERFACE DeviceBroadcastHeader = new DEV_BROADCAST_DEVICEINTERFACE();
            DeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
            DeviceBroadcastHeader.dbcc_size = (uint)Marshal.SizeOf(DeviceBroadcastHeader);
            DeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
            DeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;

            //Need to get the address of the DeviceBroadcastHeader to call RegisterDeviceNotification(), but
            //can't use "&DeviceBroadcastHeader".  Instead, using a roundabout means to get the address by 
            //making a duplicate copy using Marshal.StructureToPtr().
            IntPtr pDeviceBroadcastHeader = IntPtr.Zero;  //Make a pointer.
            pDeviceBroadcastHeader = Marshal.AllocHGlobal(Marshal.SizeOf(DeviceBroadcastHeader)); //allocate memory for a new DEV_BROADCAST_DEVICEINTERFACE structure, and return the address 
            Marshal.StructureToPtr(DeviceBroadcastHeader, pDeviceBroadcastHeader, false);  //Copies the DeviceBroadcastHeader structure into the memory already allocated at DeviceBroadcastHeaderWithPointer
            RegisterDeviceNotification(this.Handle, pDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
			if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
			{
				uint ErrorStatusWrite;
				uint ErrorStatusRead;


				//We now have the proper device path, and we can finally open read and write handles to the device.
                WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

				if((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
				{
					AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
					AttachedButBroken = false;
                    connect_status_lbl.Text = "�ڑ�����܂���";
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState = false;		//Let the rest of this application known not to read/write to the device.
					AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
					if(ErrorStatusWrite == ERROR_SUCCESS)
						WriteHandleToUSBDevice.Close();
					if(ErrorStatusRead == ERROR_SUCCESS)
						ReadHandleToUSBDevice.Close();
				}
			}
			else	//Device must not be connected (or not programmed with correct firmware)
			{
				AttachedState = false;
				AttachedButBroken = false;
			}

            if (AttachedState == true)
            {
                connect_status_lbl.Text = "�ڑ�����܂����B";
            }
            else
            {
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";
            }

			ReadWriteThread.RunWorkerAsync();	//Recommend performing USB read/write operations in a separate thread.  Otherwise,
												//the Read/Write operations are effectively blocking functions and can lock up the
												//user interface if the I/O operations take a long time to complete.

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
        //PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
        //INPUT:	Uses globally declared String DevicePath, globally declared GUID, and the MY_DEVICE_ID constant.
        //OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
        //			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
        //			to the USB device with the matching VID/PID.

        bool CheckIfPresentAndGetUSBDevicePath()
        {
		    /* 
		    Before we can "connect" our application to our USB embedded device, we must first find the device.
		    A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
		    This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
		    a unique combination of VID and PID.  

		    Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
		    for each function used can be found in the MSDN library.  We will be using the following functions (unmanaged C functions):

		    SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
		    SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
		    GetLastError()							//provided by kernel32.dll, which comes with Windows
		    SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
		    CreateFile()							//provided by kernel32.dll, which comes with Windows

            In order to call these unmanaged functions, the Marshal class is very useful.
             
		    We will also be using the following unusual data types and structures.  Documentation can also be found in
		    the MSDN library:

		    PSP_DEVICE_INTERFACE_DATA
		    PSP_DEVICE_INTERFACE_DETAIL_DATA
		    SP_DEVINFO_DATA
		    HDEVINFO
		    HANDLE
		    GUID

		    The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
		    read and write handles to the USB device.  Once the read/write handles are opened, only then can this
		    PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

		    Getting the device path is a multi-step round about process, which requires calling several of the
		    SetupDixxx() functions provided by setupapi.dll.
		    */

            try
            {
		        IntPtr DeviceInfoTable = IntPtr.Zero;
		        SP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA();
                SP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                SP_DEVINFO_DATA DevInfoData = new SP_DEVINFO_DATA();

		        uint InterfaceIndex = 0;
		        uint dwRegType = 0;
		        uint dwRegSize = 0;
                uint dwRegSize2 = 0;
		        uint StructureSize = 0;
		        IntPtr PropertyValueBuffer = IntPtr.Zero;
                bool MatchFound = false;
                bool MatchFound2 = false;
		        uint ErrorStatus;
		        uint LoopCounter = 0;

                //Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
                //Make sure the value appearing in the parathesis matches the USB device descriptor
                //of the device that this aplication is intending to find.
                String DeviceIDToFind = DEF_VID_PID;
                String DeviceIDToFind2 = DEF_VID_PID2;

		        //First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
		        DeviceInfoTable = SetupDiGetClassDevs(ref InterfaceClassGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

                if(DeviceInfoTable != IntPtr.Zero)
                {
		            //Now look through the list we just populated.  We are trying to see if any of them match our device. 
		            while(true)
		            {
                        InterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(InterfaceDataStructure);
			            if(SetupDiEnumDeviceInterfaces(DeviceInfoTable, IntPtr.Zero, ref InterfaceClassGuid, InterfaceIndex, ref InterfaceDataStructure))
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            if (ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
				            {	//Cound not find the device.  Must not have been attached.
					            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
					            return false;		
				            }
			            }
			            else	//Else some other kind of unknown error ocurred...
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
				            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				            return false;	
			            }

			            //Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
			            //check to see if it is the correct device or not.

			            //Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
                        DevInfoData.cbSize = (uint)Marshal.SizeOf(DevInfoData);
			            SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, ref DevInfoData);

			            //First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
			            SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, IntPtr.Zero, 0, ref dwRegSize);

			            //Allocate a buffer for the hardware ID.
                        //Should normally work, but could throw exception "OutOfMemoryException" if not enough resources available.
                        PropertyValueBuffer = Marshal.AllocHGlobal((int)dwRegSize);

			            //Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
			            //REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
			            //buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
			            //format "Vid_04d8&Pid_003f".
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, PropertyValueBuffer, dwRegSize, ref dwRegSize2);

			            //Now check if the first string in the hardware ID matches the device ID of the USB device we are trying to find.
			            String DeviceIDFromRegistry = Marshal.PtrToStringUni(PropertyValueBuffer); //Make a new string, fill it with the contents from the PropertyValueBuffer

			            Marshal.FreeHGlobal(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

			            //Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
			            DeviceIDFromRegistry = DeviceIDFromRegistry.ToLowerInvariant();
                        DeviceIDToFind = DeviceIDToFind.ToLowerInvariant();
                        DeviceIDToFind2 = DeviceIDToFind2.ToLowerInvariant();
			            //Now check if the hardware ID we are looking at contains the correct VID/PID
                        MatchFound = DeviceIDFromRegistry.Contains(DeviceIDToFind);
                        MatchFound2 = DeviceIDFromRegistry.Contains(DeviceIDToFind2);
                        if (MatchFound == true && MatchFound2 == true)
			            {
                            //Device must have been found.  In order to open I/O file handle(s), we will need the actual device path first.
				            //We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
				            //time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
				            //get the structure (after we have allocated enough memory for the structure.)
                            DetailedInterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(DetailedInterfaceDataStructure);
				            //First call populates "StructureSize" with the correct value
				            SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, IntPtr.Zero, 0, ref StructureSize, IntPtr.Zero);
                            //Need to call SetupDiGetDeviceInterfaceDetail() again, this time specifying a pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA buffer with the correct size of RAM allocated.
                            //First need to allocate the unmanaged buffer and get a pointer to it.
                            IntPtr pUnmanagedDetailedInterfaceDataStructure = IntPtr.Zero;  //Declare a pointer.
                            pUnmanagedDetailedInterfaceDataStructure = Marshal.AllocHGlobal((int)StructureSize);    //Reserve some unmanaged memory for the structure.
                            DetailedInterfaceDataStructure.cbSize = 6; //Initialize the cbSize parameter (4 bytes for DWORD + 2 bytes for unicode null terminator)
                            Marshal.StructureToPtr(DetailedInterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, false); //Copy managed structure contents into the unmanaged memory buffer.

                            //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the device path in the structure at pUnmanagedDetailedInterfaceDataStructure.
                            if (SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, StructureSize, IntPtr.Zero, IntPtr.Zero))
                            {
                                //Need to extract the path information from the unmanaged "structure".  The path starts at (pUnmanagedDetailedInterfaceDataStructure + sizeof(DWORD)).
                                IntPtr pToDevicePath = new IntPtr((uint)pUnmanagedDetailedInterfaceDataStructure.ToInt32() + 4);  //Add 4 to the pointer (to get the pointer to point to the path, instead of the DWORD cbSize parameter)
                                DevicePath = Marshal.PtrToStringUni(pToDevicePath); //Now copy the path information into the globally defined DevicePath String.
                                
                                //We now have the proper device path, and we can finally use the path to open I/O handle(s) to the device.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return true;    //Returning the device path in the global DevicePath String
                            }
                            else //Some unknown failure occurred
                            {
                                uint ErrorCode = (uint)Marshal.GetLastWin32Error();
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return false;    
                            }
                        }

			            InterfaceIndex++;	
			            //Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
			            //However, just in case some unexpected error occurs, keep track of the number of loops executed.
			            //If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
			            LoopCounter++;
			            if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
			            {
				            return false;
			            }
		            }//end of while(true)
                }
                return false;
            }//end of try
            catch
            {
                //Something went wrong if PC gets here.  Maybe a Marshal.AllocHGlobal() failed due to insufficient resources or something.
			    return false;	
            }
        }
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        //This is a callback function that gets called when a Windows message is received by the form.
        //We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_DEVICECHANGE)
            {
                if (((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED))
                {
                    //WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
                    //sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
                    //to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
                    //(the message could have been totally unrelated to your application/USB device)

                    if (CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
                    {
                        //If executes to here, this means the device is currently attached and was found.
                        //This code needs to decide however what to do, based on whether or not the device was previously known to be
                        //attached or not.
                        if ((AttachedState == false) || (AttachedButBroken == true))	//Check the previous attachment state
                        {
                            uint ErrorStatusWrite;
                            uint ErrorStatusRead;

                            //We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
                            //is now possible to open read and write handles to the device.
                            WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                            ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                            if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                            {
                                AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                                AttachedButBroken = false;
                                connect_status_lbl.Text = "�ڑ�����܂����B";

                            }
                            else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                            {
                                AttachedState = false;		//Let the rest of this application known not to read/write to the device.
                                AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                                if (ErrorStatusWrite == ERROR_SUCCESS)
                                    WriteHandleToUSBDevice.Close();
                                if (ErrorStatusRead == ERROR_SUCCESS)
                                    ReadHandleToUSBDevice.Close();
                            }
                        }
                        //else we did find the device, but AttachedState was already true.  In this case, don't do anything to the read/write handles,
                        //since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
                    }
                    else	//Device must not be connected (or not programmed with correct firmware)
                    {
                        if (AttachedState == true)		//If it is currently set to true, that means the device was just now disconnected
                        {
                            AttachedState = false;
                            WriteHandleToUSBDevice.Close();
                            ReadHandleToUSBDevice.Close();
                        }
                        AttachedState = false;
                        AttachedButBroken = false;
                    }
                }
            } //end of: if(m.Msg == WM_DEVICECHANGE)

            base.WndProc(ref m);
        } //end of: WndProc() function
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void ReadWriteThread_DoWork(object sender, DoWorkEventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

            /*This thread does the actual USB read/write operations (but only when AttachedState == true) to the USB device.
            It is generally preferrable to write applications so that read and write operations are handled in a separate
            thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
            take a very long time to complete.

            Since this is a separate thread, this code below executes independently from the rest of the
            code in this application.  All this thread does is read and write to the USB device.  It does not update
            the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
            The information that this thread obtains is stored in atomic global variables.
            Form updates are handled by the FormUpdateTimer Tick event handler function.

            This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
            This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
            Both of these functions are documented in the MSDN library.  Calling ReadFile() is a not perfectly straight
            foward in C# environment, since one of the input parameters is a pointer to a buffer that gets filled by ReadFile().
            The ReadFile() function is therefore called through a wrapper function ReadFileManagedBuffer().

            All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
            calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
            the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
            asynchronous I/O function calls.  

            Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
            USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
            when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
            the issue described in Microsoft knowledge base article 940021:
            http://support.microsoft.com/kb/940021/en-us 

            Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
            directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
            write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
            WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
            for some USB operations and the source code can be used	as an example.*/


            Byte[] OUTBuffer = new byte[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
		    Byte[] INBuffer = new byte[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
		    uint BytesWritten = 0;
            uint BytesRead = 0;
            bool b_usb_write_ret = false;
            bool b_Error_Flag = false;
            ArrayList al_temp1 = new ArrayList();
            long l_address;
            long l_size;
            byte b_size;
            long l_comp_size;
            int i_send_data_pos;

		    while(true)
		    {
                try
                {
                    if (AttachedState == true)	//Do not try to use the read/write handles unless the USB device is attached and ready
                    {
                        //VersionReadReq = false;
                        if (VersionReadReq == true)
                        {
                            VersionReadReq = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x56;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x56)
                                        {
                                            for (uint i = 2; i < 65; i++)
                                            {
                                                version_buff[i - 2] = INBuffer[i];
                                            }
                                            VersionReadComp = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }

                        /* Flash Read */
                        if (b_FlashRead == true)
                        {
                            b_FlashRead = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x11;		//0x21 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_ReadAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_ReadAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_ReadAddress >> 8) & 0xFF);		//
                            OUTBuffer[5] = (byte)(l_ReadAddress & 0xFF);		    //
                            OUTBuffer[6] = byte_ReadSize;		            //Size

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x11)
                                        {
                                            if (INBuffer[2] == byte_ReadSize)
                                            {
                                                // OK
                                                FlashReadData[0] = INBuffer[2];
                                                for (int fi = 0; fi < INBuffer[2]; fi++)
                                                {
                                                    FlashReadData[1 + fi] = INBuffer[3 + fi];
                                                }
                                            }
                                            else
                                            {
                                                // NG
                                                FlashReadData[0] = INBuffer[2];
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        /* Flash Write */
                        if (b_FlashWrite == true)
                        {
                            b_FlashWrite = false;
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x12;		//0x22 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_WriteAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_WriteAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_WriteAddress >> 8) & 0xFF);		    //
                            OUTBuffer[5] = (byte)(l_WriteAddress & 0xFF);		        //
                            OUTBuffer[6] = byte_WriteSize;		                           //Size
                            for (uint i = 0; i < byte_WriteSize; i++)
                            {
                                OUTBuffer[7 + i] = FlashWriteData[i];
                            }

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x12)
                                        {
                                            //ANS
                                            byte_FlashWrite_Ans = INBuffer[2];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        /* Flash Erase */
                        if (b_FlashErase == true)
                        {
                            b_FlashErase = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x13;		//0x22 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_EraseAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_EraseAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_EraseAddress >> 8) & 0xFF);		    //
                            OUTBuffer[5] = (byte)(l_EraseAddress & 0xFF);		        //

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x13)
                                        {
                                            //ANS
                                            byte_FlashErase_Ans = INBuffer[2];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }


                        // RESTORE�֌W
                        if (backup_restore_flag != Constants.BACKUP_FLAG_NON)
                        {
                            b_Error_Flag = false;

                            // RESTORE�f�[�^�̓ǂݏo��
                            if (b_Error_Flag == false && backup_restore_flag == Constants.BACKUP_FLAG_RESTORE)
                            {
                                if (my_Load_Backup_File(backup_file_path, ref al_temp1) == true)
                                {   //�ǂݍ��ُ݈�
                                    b_Error_Flag = true;
                                    backup_restore_error_code = 1001;
                                }
                            }

                            // �S�Z�N�^�[����
                            if (b_Error_Flag == false && (backup_restore_flag == Constants.BACKUP_FLAG_RESET || backup_restore_flag == Constants.BACKUP_FLAG_RESTORE))
                            {
                                l_address = 0;
                                l_comp_size = 0;
                                i_send_data_pos = 0;

                                while (l_address < (long)Constants.FM_TOTAL_SIZE && b_Error_Flag == false)
                                {
                                    //�i���X�V
                                    backup_restore_progressbar_value++;

                                    // �Z�N�^�[����
                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x13;		//0x22 is the "Get Pushbutton State" command in the firmware
                                    OUTBuffer[2] = (byte)((l_address >> 24) & 0xFF);		//Address
                                    OUTBuffer[3] = (byte)((l_address >> 16) & 0xFF);		//
                                    OUTBuffer[4] = (byte)((l_address >> 8) & 0xFF);		    //
                                    OUTBuffer[5] = (byte)(l_address & 0xFF);		        //
                                    for (uint i = 6; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x13)
                                                {
                                                    //ANS
                                                    if (INBuffer[2] != 0x00)
                                                    {
                                                        b_Error_Flag = true;
                                                        backup_restore_error_code = 2001;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }

                                    // ���̏����Z�N�^�[
                                    l_address += (long)Constants.FM_SECTOR_SIZE;
                                }
                            }

                            // �S�f�[�^�ǂݏo��
                            if (b_Error_Flag == false && backup_restore_flag == Constants.BACKUP_FLAG_BACKUP)
                            {
                                al_temp1.Clear();
                                l_address = 0;
                                l_comp_size = 0;

                                while (l_comp_size < Constants.FM_TOTAL_SIZE && b_Error_Flag == false)
                                {
                                    //�i���X�V
                                    backup_restore_progressbar_value++;

                                    l_size = Constants.FM_TOTAL_SIZE - l_comp_size;
                                    if (l_size > Constants.FM_USB_READ_DATA_SIZE)
                                    {
                                        l_size = Constants.FM_USB_READ_DATA_SIZE;
                                    }
                                    l_comp_size += l_size;

                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x11;		//0x21 is the "Get Pushbutton State" command in the firmware
                                    OUTBuffer[2] = (byte)((l_address >> 24) & 0xFF);    //Address
                                    OUTBuffer[3] = (byte)((l_address >> 16) & 0xFF);    //
                                    OUTBuffer[4] = (byte)((l_address >> 8) & 0xFF);     //
                                    OUTBuffer[5] = (byte)(l_address & 0xFF);            //
                                    b_size = (byte)(l_size & 0xFF);
                                    OUTBuffer[6] = b_size;               //Size
                                    for (uint i = 7; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x11)
                                                {
                                                    if (INBuffer[2] == b_size)
                                                    {
                                                        // OK
                                                        for (int fi = 0; fi < INBuffer[2]; fi++)
                                                        {
                                                            al_temp1.Add(INBuffer[3 + fi]);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        // NG
                                                        b_Error_Flag = true;
                                                        backup_restore_error_code = 2002;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }

                                    l_address += l_size;
                                }


                                if (al_temp1.Count == Constants.FM_TOTAL_SIZE)
                                {
                                    my_Save_Backup_File(backup_file_path, al_temp1);
                                }
                            }

                            // �S�f�[�^��������
                            if (b_Error_Flag == false && backup_restore_flag == Constants.BACKUP_FLAG_RESTORE)
                            {
                                l_address = 0;
                                l_comp_size = 0;
                                i_send_data_pos = 0;

                                while (l_comp_size < Constants.FM_TOTAL_SIZE && b_Error_Flag == false)
                                {
                                    //�i���X�V
                                    backup_restore_progressbar_value++;

                                    l_size = Constants.FM_TOTAL_SIZE - l_comp_size;
                                    if (l_size > Constants.FM_USB_WRITE_DATA_SIZE)
                                    {
                                        l_size = Constants.FM_USB_WRITE_DATA_SIZE;
                                    }
                                    // 0x100���Ƃ̃Z�N�V�������܂����Ƃ��͕���
                                    long l_temp = 0x100 - (l_address & 0xFF);
                                    if (l_temp < l_size)
                                    {
                                        l_size = l_temp;
                                    }
                                    l_comp_size += l_size;


                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x12;		//0x22 is the "Get Pushbutton State" command in the firmware
                                    OUTBuffer[2] = (byte)((l_address >> 24) & 0xFF);		//Address
                                    OUTBuffer[3] = (byte)((l_address >> 16) & 0xFF);		//
                                    OUTBuffer[4] = (byte)((l_address >> 8) & 0xFF);		//
                                    OUTBuffer[5] = (byte)(l_address & 0xFF);		    //

                                    //���M�o�C�g�f�[�^���o�̓o�b�t�@�ɃR�s�[
                                    for (int fi = 0; fi < l_size; fi++, i_send_data_pos++)
                                    {
                                        OUTBuffer[7 + fi] = (byte)al_temp1[i_send_data_pos];
                                    }
                                    OUTBuffer[6] = (byte)(l_size & 0xFF);		        //Size

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x12)
                                                {
                                                    //ANS
                                                    if (INBuffer[2] != 0x00)
                                                    {
                                                        b_Error_Flag = true;
                                                        backup_restore_error_code = 3001;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }

                                    l_address += l_size;
                                }
                            }

                            backup_restore_flag = Constants.BACKUP_FLAG_NON;

                            // �o�b�t�@�N���A
                            al_temp1.Clear();
                        }


                        // �ԊO���ݒ���̓ǂݍ��ݗv������
                        if (ir_data_info_read_req == true)
                        {
                            ir_data_info_read_req = false;

                            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
                            {
                                if (ir_data_info_read_reqs[fi] == true)
                                {
                                    ir_data_info_read_reqs[fi] = false;


                                    // �ݒ���擾
                                    for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    {
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                    }
                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x1A;		//0x81 is the "Get Pushbutton State" command in the firmware
                                    OUTBuffer[2] = (byte)(fi & 0xFF);

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x1A && INBuffer[2] == 0x00)
                                                {
                                                    uint tmp_uint = 0;
                                                    tmp_uint = INBuffer[3];
                                                    tmp_uint = (tmp_uint << 8) | INBuffer[4];
                                                    ir_data_infos[fi].ir_freq = tmp_uint;
                                                    tmp_uint = INBuffer[5];
                                                    tmp_uint = (tmp_uint << 8) | INBuffer[6];
                                                    ir_data_infos[fi].ir_data_byte_size = tmp_uint;
                                                    tmp_uint = INBuffer[7];
                                                    tmp_uint = (tmp_uint << 8) | INBuffer[8];
                                                    ir_data_infos[fi].ir_data_bit_len = tmp_uint;
                                                    ir_data_infos[fi].memo_byte_size = INBuffer[9];
                                                    ir_data_infos[fi].device_type = INBuffer[10];
                                                    ir_data_infos[fi].device_data_size = INBuffer[11];
                                                    for (int fj = 0; fj < 8 && fj < ir_data_infos[fi].device_data_size; fj++)
                                                    {
                                                        ir_data_infos[fi].device_data[fj] = INBuffer[12 + fj];
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }

                                    string tmp_memo_str = "";
                                    // �����f�[�^�擾
                                    if (ir_data_infos[fi].memo_byte_size > 0)
                                    {
                                        for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        {
                                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                        }

                                        long tmp_ReadAddress = (FLASH_SECTOR_SIZE * fi) + FLASH_MEMO_DATA_ADR;
                                        byte tmp_ReadSize = 0;
                                        byte tmp_Comp_ReadSize = 0;

                                        while(tmp_Comp_ReadSize < ir_data_infos[fi].memo_byte_size)
                                        {
                                            tmp_ReadSize = (byte)(ir_data_infos[fi].memo_byte_size - tmp_Comp_ReadSize);
                                            if(tmp_ReadSize > 50)
                                            {
                                                tmp_ReadSize = 50;
                                            }


                                            //Get the pushbutton state from the microcontroller firmware.
                                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                            OUTBuffer[1] = 0x11;		//0x21 is the "Get Pushbutton State" command in the firmware
                                            OUTBuffer[2] = (byte)((tmp_ReadAddress >> 24) & 0xFF);		//Address
                                            OUTBuffer[3] = (byte)((tmp_ReadAddress >> 16) & 0xFF);		//
                                            OUTBuffer[4] = (byte)((tmp_ReadAddress >> 8) & 0xFF);		//
                                            OUTBuffer[5] = (byte)(tmp_ReadAddress & 0xFF);		    //
                                            OUTBuffer[6] = tmp_ReadSize;		            //Size

                                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //Now get the response packet from the firmware.
                                                INBuffer[0] = 0;
                                                {
                                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                    {
                                                        //INBuffer[0] is the report ID, which we don't care about.
                                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                        if (INBuffer[1] == 0x11)
                                                        {
                                                            if (INBuffer[2] == tmp_ReadSize)
                                                            {
                                                                // OK
                                                                for (int fj = 0; fj < INBuffer[2]; fj++)
                                                                {
                                                                    ir_data_infos[fi].memo_data[tmp_Comp_ReadSize + fj] = INBuffer[3 + fj];
                                                                }
                                                            }
                                                            else
                                                            {
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                AttachedState = false;
                                            }

                                            tmp_ReadAddress += tmp_ReadSize;
                                            tmp_Comp_ReadSize += tmp_ReadSize;
                                        }

                                        tmp_memo_str = System.Text.Encoding.Unicode.GetString(ir_data_infos[fi].memo_data, 0, ir_data_infos[fi].memo_byte_size);
                                    }

                                    // �ԊO���f�[�^�擾
                                    uint[] tmp_ir_data = new uint[Constants.IR_DATA_BUFF_SIZE];
                                    if (ir_data_infos[fi].ir_data_byte_size > 0)
                                    {
                                        for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        {
                                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                        }

                                        uint tmp_ir_data_set_pos = 0;
                                        long tmp_ReadAddress = (FLASH_SECTOR_SIZE * fi) + FLASH_IR_DATA_ADR;
                                        uint tmp_ReadSize = 0;
                                        uint tmp_Comp_ReadSize = 0;

                                        while (tmp_Comp_ReadSize < ir_data_infos[fi].ir_data_byte_size)
                                        {
                                            tmp_ReadSize = (uint)(ir_data_infos[fi].ir_data_byte_size - tmp_Comp_ReadSize);
                                            if (tmp_ReadSize > 52)
                                            {
                                                tmp_ReadSize = 52;  // 4 �̔{����(64-4-1-1)�ȉ��̒l�Ƃ���
                                            }


                                            //Get the pushbutton state from the microcontroller firmware.
                                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                            OUTBuffer[1] = 0x11;		//0x21 is the "Get Pushbutton State" command in the firmware
                                            OUTBuffer[2] = (byte)((tmp_ReadAddress >> 24) & 0xFF);		//Address
                                            OUTBuffer[3] = (byte)((tmp_ReadAddress >> 16) & 0xFF);		//
                                            OUTBuffer[4] = (byte)((tmp_ReadAddress >> 8) & 0xFF);		//
                                            OUTBuffer[5] = (byte)(tmp_ReadAddress & 0xFF);		    //
                                            OUTBuffer[6] = (byte)(tmp_ReadSize & 0xFF);		            //Size

                                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //Now get the response packet from the firmware.
                                                INBuffer[0] = 0;
                                                {
                                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                    {
                                                        //INBuffer[0] is the report ID, which we don't care about.
                                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                        if (INBuffer[1] == 0x11)
                                                        {
                                                            if (INBuffer[2] == tmp_ReadSize)
                                                            {
                                                                // OK
                                                                for (int fj = 0; fj < INBuffer[2]; )
                                                                {
                                                                    tmp_ir_data[tmp_ir_data_set_pos] = INBuffer[3 + fj++];
                                                                    tmp_ir_data[tmp_ir_data_set_pos] = (tmp_ir_data[tmp_ir_data_set_pos] << 8) | INBuffer[3 + fj++];
                                                                    tmp_ir_data_set_pos++;
                                                                }
                                                            }
                                                            else
                                                            {
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                AttachedState = false;
                                            }

                                            tmp_ReadAddress += tmp_ReadSize;
                                            tmp_Comp_ReadSize += tmp_ReadSize;
                                        }

                                    }
                                    my_Ir_data.ir_data_set(fi, tmp_memo_str, (int)ir_data_infos[fi].ir_freq, (int)ir_data_infos[fi].ir_data_bit_len, tmp_ir_data);
                                }
                            }

                            ir_data_info_read_comp = true;
                        }
                        // Flash Erase�v������
                        if (ir_data_info_erase_req == true)
                        {
                            ir_data_info_erase_req = false;

                            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
                            {
                                if (ir_data_info_erase_reqs[fi] == true)
                                {
                                    ir_data_info_erase_reqs[fi] = false;

                                    for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    {
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                    }

                                    long tmp_EraseAddress = (FLASH_SECTOR_SIZE * fi);
                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                    OUTBuffer[1] = 0x13;		//0x22 is the "Get Pushbutton State" command in the firmware
                                    OUTBuffer[2] = (byte)((tmp_EraseAddress >> 24) & 0xFF);		//Address
                                    OUTBuffer[3] = (byte)((tmp_EraseAddress >> 16) & 0xFF);		//
                                    OUTBuffer[4] = (byte)((tmp_EraseAddress >> 8) & 0xFF);		    //
                                    OUTBuffer[5] = (byte)(tmp_EraseAddress & 0xFF);		        //

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                    if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x13)
                                                {
                                                    //ANS
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }
                                }
                            }

                            ir_data_info_erase_comp = true;
                        }
                        // Flash �������ݗv������
                        if(ir_data_info_write_req == true)
                        {
                            ir_data_info_write_req = false;

                            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
                            {
                                if (ir_data_info_write_reqs[fi] == true && ir_data_info_erase_reqs[fi] == false)
                                {   // �������ݗv������ŁA�Z�N�^�[���������ς�
                                    ir_data_info_write_reqs[fi] = false;


                                    // �ݒ��񏑂�����
                                    for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    {
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                    }
                                    //Get the pushbutton state from the microcontroller firmware.
                                    OUTBuffer[0] = 0;
                                    OUTBuffer[1] = 0x1B;
                                    OUTBuffer[2] = (byte)(fi & 0xFF);   //idx
                                    OUTBuffer[3] = (byte)((ir_data_infos[fi].ir_freq >> 8) & 0xFF);
                                    OUTBuffer[4] = (byte)(ir_data_infos[fi].ir_freq & 0xFF);
                                    OUTBuffer[5] = (byte)((ir_data_infos[fi].ir_data_byte_size >> 8) & 0xFF);
                                    OUTBuffer[6] = (byte)(ir_data_infos[fi].ir_data_byte_size & 0xFF);
                                    OUTBuffer[7] = (byte)((ir_data_infos[fi].ir_data_bit_len >> 8) & 0xFF);
                                    OUTBuffer[8] = (byte)(ir_data_infos[fi].ir_data_bit_len & 0xFF);
                                    OUTBuffer[9] = ir_data_infos[fi].memo_byte_size;
                                    OUTBuffer[10] = ir_data_infos[fi].device_type;
                                    OUTBuffer[11] = ir_data_infos[fi].device_data_size;
                                    for (int fj = 0; fj < 8 && fj < ir_data_infos[fi].device_data_size; fj++)
                                    {
                                        OUTBuffer[12 + fj] = ir_data_infos[fi].device_data[fj];
                                    }

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x1B && INBuffer[2] == 0x00)
                                                {
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        AttachedState = false;
                                    }

                                    // �����f�[�^��������
                                    if (ir_data_infos[fi].memo_byte_size > 0)
                                    {
                                        long tmp_WriteAddress = (FLASH_SECTOR_SIZE * fi) + FLASH_MEMO_DATA_ADR;
                                        byte tmp_WriteSize = 0;
                                        byte tmp_Comp_WriteSize = 0;

                                        while (tmp_Comp_WriteSize < ir_data_infos[fi].memo_byte_size)
                                        {
                                            tmp_WriteSize = (byte)(ir_data_infos[fi].memo_byte_size - tmp_Comp_WriteSize);
                                            if (tmp_WriteSize > 32)
                                            {
                                                tmp_WriteSize = 32;
                                            }

                                            //Get the pushbutton state from the microcontroller firmware.
                                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                            OUTBuffer[1] = 0x12;		//0x22 is the "Get Pushbutton State" command in the firmware
                                            OUTBuffer[2] = (byte)((tmp_WriteAddress >> 24) & 0xFF);		//Address
                                            OUTBuffer[3] = (byte)((tmp_WriteAddress >> 16) & 0xFF);		//
                                            OUTBuffer[4] = (byte)((tmp_WriteAddress >> 8) & 0xFF);		    //
                                            OUTBuffer[5] = (byte)(tmp_WriteAddress & 0xFF);		        //
                                            OUTBuffer[6] = tmp_WriteSize;		                           //Size
                                            for (uint i = 0; i < tmp_WriteSize; i++)
                                            {
                                                OUTBuffer[7 + i] = ir_data_infos[fi].memo_data[tmp_Comp_WriteSize + i];
                                            }

                                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //Now get the response packet from the firmware.
                                                INBuffer[0] = 0;
                                                {
                                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                    {
                                                        //INBuffer[0] is the report ID, which we don't care about.
                                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                        if (INBuffer[1] == 0x12)
                                                        {
                                                            //ANS
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                AttachedState = false;
                                            }

                                            tmp_WriteAddress += tmp_WriteSize;
                                            tmp_Comp_WriteSize += tmp_WriteSize;
                                        }
                                    }

                                    // �ԊO���f�[�^��������
                                    if (ir_data_infos[fi].ir_data_byte_size > 0)
                                    {

                                        uint[] tmp_ir_data = new uint[Constants.IR_DATA_BUFF_SIZE];
                                        string tmp_str = "";
                                        int tmp_int1 = 0;
                                        int tmp_int2 = 0;
                                        int tmp_set_ir_data_pos = 0;
                                        my_Ir_data.ir_data_get(fi, tmp_str, ref tmp_int1, ref tmp_int2, ref tmp_ir_data, tmp_ir_data.Length);

                                        long tmp_WriteAddress = (FLASH_SECTOR_SIZE * fi) + FLASH_IR_DATA_ADR;
                                        uint tmp_WriteSize = 0;
                                        uint tmp_Comp_WriteSize = 0;

                                        while (tmp_Comp_WriteSize < ir_data_infos[fi].ir_data_byte_size)
                                        {
                                            tmp_WriteSize = ir_data_infos[fi].ir_data_byte_size - tmp_Comp_WriteSize;
                                            if (tmp_WriteSize > 32)
                                            {
                                                tmp_WriteSize = 32;
                                            }

                                            //Get the pushbutton state from the microcontroller firmware.
                                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                                            OUTBuffer[1] = 0x12;		//0x22 is the "Get Pushbutton State" command in the firmware
                                            OUTBuffer[2] = (byte)((tmp_WriteAddress >> 24) & 0xFF);		//Address
                                            OUTBuffer[3] = (byte)((tmp_WriteAddress >> 16) & 0xFF);		//
                                            OUTBuffer[4] = (byte)((tmp_WriteAddress >> 8) & 0xFF);		    //
                                            OUTBuffer[5] = (byte)(tmp_WriteAddress & 0xFF);		        //
                                            OUTBuffer[6] = (byte)(tmp_WriteSize & 0xFF);		                           //Size
                                            for (uint i = 0; i < tmp_WriteSize; )
                                            {
                                                OUTBuffer[7 + i++] = (byte)((tmp_ir_data[tmp_set_ir_data_pos] >> 8) & 0xFF);
                                                OUTBuffer[7 + i++] = (byte)(tmp_ir_data[tmp_set_ir_data_pos] & 0xFF);
                                                tmp_set_ir_data_pos++;
                                            }

                                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //Now get the response packet from the firmware.
                                                INBuffer[0] = 0;
                                                {
                                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                    {
                                                        //INBuffer[0] is the report ID, which we don't care about.
                                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                        if (INBuffer[1] == 0x12)
                                                        {
                                                            //ANS
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                AttachedState = false;
                                            }

                                            tmp_WriteAddress += tmp_WriteSize;
                                            tmp_Comp_WriteSize += tmp_WriteSize;
                                        }
                                    }






                                }
                                else if (ir_data_info_write_reqs[fi] == true && ir_data_info_erase_reqs[fi] == true)
                                {   // �������ݗv������ŁA�Z�N�^�[����������������
                                    ir_data_info_write_req = true;
                                }
                            }


                            // �������݊���
                            if (ir_data_info_write_req == false)
                            {
                                ir_data_info_write_comp = true;
                            }
                        }



                        // IR�ǂݍ��݊J�n
                        if (b_ir_read_start_req == true)
                        {
                            b_ir_read_start_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x31;		//0x81 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((ir_read_start_freq >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)(ir_read_start_freq & 0xFF);
                            OUTBuffer[4] = 1;   // �ǂݍ��ݒ�~�t���O�@��~����
                            OUTBuffer[5] = (byte)((ir_read_stop_on_time >> 8) & 0xFF);      // �ǂݍ��ݒ�~ON����MSB
                            OUTBuffer[6] = (byte)(ir_read_stop_on_time & 0xFF);             // �ǂݍ��ݒ�~ON����LSB
                            OUTBuffer[7] = (byte)((ir_read_stop_off_time >> 8) & 0xFF);     // �ǂݍ��ݒ�~OFF����MSB
                            OUTBuffer[8] = (byte)(ir_read_stop_off_time & 0xFF);            // �ǂݍ��ݒ�~OFF����LSB

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x31)
                                        {
                                            ir_reading_data_get_count = 0;
                                            ir_reading_data_get_count_fix = 0;
                                            b_ir_reading_flag = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��ݏI��
                        if (b_ir_read_stop_req == true)
                        {
                            b_ir_read_stop_req = false;
                            b_ir_reading_flag = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x32;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x32)
                                        {
                                            ir_read_result_data = INBuffer[2];
                                            b_ir_read_stop_comp = true;

                                            // �ǂݍ��ݐ���I�����́A�f�[�^�擾�v��������
                                            if (ir_read_result_data == 0x00)
                                            {
                                                b_ir_read_data_get_req = true;
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��݃f�[�^�擾
                        if (b_ir_read_data_get_req == true)
                        {
                            //b_ir_read_data_get_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x33;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x33)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && tmp_total_size >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++ )
                                                {
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_read_data_get_count++;
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_read_data_get_count++;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_read_data_total_size = tmp_total_size;
                                                b_ir_read_data_get_req = false;
                                                b_ir_read_data_get_comp = true;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��ݒ��f�[�^�擾
                        if (b_ir_reading_flag == true)
                        {
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x37;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x37)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && tmp_total_size >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++)
                                                {
                                                    ir_read_data[ir_reading_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_reading_data_get_count] = (ir_read_data[ir_reading_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_reading_data_get_count++;
                                                    ir_read_data[ir_reading_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_reading_data_get_count] = (ir_read_data[ir_reading_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_reading_data_get_count++;
                                                }

                                                if (tmp_total_size == (tmp_start_pos + tmp_read_size))
                                                {
                                                    ir_reading_data_get_count_fix = ir_reading_data_get_count;
                                                    ir_reading_data_get_count = 0;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_reading_data_get_count_fix = ir_reading_data_get_count;
                                                ir_reading_data_get_count = 0;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR���M�f�[�^�Z�b�g
                        if (b_ir_send_data_set_req == true)
                        {
                            b_ir_send_data_set_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            // �ԊO�����M�f�[�^���Z�b�g
                            while (true)
                            {
                                OUTBuffer[0] = 0;
                                OUTBuffer[1] = 0x34;

                                OUTBuffer[2] = (byte)((my_Ir_data.ir_data_size[ir_send_data_set_buff_no] >> 8) & 0xFF);
                                OUTBuffer[3] = (byte)(my_Ir_data.ir_data_size[ir_send_data_set_buff_no] & 0xFF);
                                OUTBuffer[4] = (byte)((ir_send_data_set_pos >> 8) & 0xFF);
                                OUTBuffer[5] = (byte)(ir_send_data_set_pos & 0xFF);

                                int set_data_size = my_Ir_data.ir_data_size[ir_send_data_set_buff_no] - ir_send_data_set_pos;
                                if (set_data_size > ir_send_data_usb_send_max_size)
                                {
                                    set_data_size = ir_send_data_usb_send_max_size;
                                }
                                else if (set_data_size < 0)
                                {
                                    set_data_size = 0;
                                }
                                OUTBuffer[6] = (byte)(set_data_size & 0xFF);

                                if (0 < set_data_size)
                                {
                                    for (int fi = 0; fi < set_data_size; fi++)
                                    {
                                        int get_pos = ir_send_data_set_pos * 2;

                                        // ON Count
                                        OUTBuffer[7 + (fi * 4)] = (byte)((my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                        OUTBuffer[7 + (fi * 4) + 1] = (byte)(my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos++] & 0xFF);
                                        // OFF Count
                                        OUTBuffer[7 + (fi * 4) + 2] = (byte)((my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                        OUTBuffer[7 + (fi * 4) + 3] = (byte)(my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos++] & 0xFF); ;
                                        ir_send_data_set_pos++;
                                    }

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x34)
                                                {
                                                    if (INBuffer[2] == 0x00)
                                                    {   // OK
                                                    }
                                                    else
                                                    {
                                                        // NG
                                                    }
                                                }
                                            }
                                            else
                                            {
                                            }
                                        }
                                    }
                                    else
                                    {
                                    }
                                }
                                else
                                {   // ���M�f�[�^�Ȃ�
                                    break;
                                }
                            }

                            // �ԊO�����M�v�����Z�b�g
                            b_ir_send_send_req = true;

                        }
                        // IR���M�v���Z�b�g
                        if (b_ir_send_send_req == true)
                        {
                            b_ir_send_send_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;
                            OUTBuffer[1] = 0x35;
                            OUTBuffer[2] = (byte)((my_Ir_data.ir_freq[ir_send_data_set_buff_no] >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)(my_Ir_data.ir_freq[ir_send_data_set_buff_no] & 0xFF);
                            OUTBuffer[4] = (byte)((my_Ir_data.ir_data_size[ir_send_data_set_buff_no] >> 8) & 0xFF);
                            OUTBuffer[5] = (byte)(my_Ir_data.ir_data_size[ir_send_data_set_buff_no] & 0xFF);

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x35)
                                        {
                                            if (INBuffer[2] == 0x00)
                                            {   // OK
                                            }
                                            else
                                            {
                                                // NG
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��݃f�[�^�擾(�f�o�b�O)
                        if (b_ir_read_data_get_req_debug == true)
                        {
                            //b_ir_read_data_get_req_debug = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x36;		//0x81 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)(((ir_read_data_get_count / 2) >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)((ir_read_data_get_count / 2) & 0xFF);
                            OUTBuffer[4] = 14;

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x36)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && ir_read_data.Length >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0 && tmp_total_size > tmp_start_pos)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++)
                                                {
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_read_data_get_count++;
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_read_data_get_count++;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_read_data_total_size = tmp_total_size;
                                                b_ir_read_data_get_req_debug = false;
                                                b_ir_read_data_get_comp = true;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }


#pragma warning disable 0162
                        //DEBUG DEBUG DEBUG *****************************************************************************************************
                        if (__DEBUG_FLAG__ == true)
                        {
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x40;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x40)
                                        {
                                            Debug_Array[0] = (int)(INBuffer[2]);
                                            Debug_Array[1] = (int)(INBuffer[3]);
                                            Debug_Array[2] = (int)(INBuffer[4]);
                                            Debug_Array[3] = (int)(INBuffer[5]);
                                            Debug_Array[4] = (int)(INBuffer[6]);
                                            Debug_Array[5] = (int)(INBuffer[7]);
                                            Debug_Array[6] = (int)(INBuffer[8]);
                                            Debug_Array[7] = (int)(INBuffer[9]);
                                            Debug_Array[8] = (int)(INBuffer[10]);
                                            Debug_Array[9] = (int)(INBuffer[11]);
                                            Debug_Array[10] = (int)(INBuffer[12]);
                                            Debug_Array[11] = (int)(INBuffer[13]);
                                            Debug_Array[12] = (int)(INBuffer[14]);
                                            Debug_Array[13] = (int)(INBuffer[15]);
                                            Debug_Array[14] = (int)(INBuffer[16]);
                                            //Debug_3++;
                                        }
                                    }
                                }
                            }

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x41;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x41)
                                        {
                                            Debug_Arr2[0] = (int)(INBuffer[2]);
                                            Debug_Arr2[1] = (int)(INBuffer[3]);
                                            Debug_Arr2[2] = (int)(INBuffer[4]);
                                            Debug_Arr2[3] = (int)(INBuffer[5]);
                                            Debug_Arr2[4] = (int)(INBuffer[6]);
                                            Debug_Arr2[5] = (int)(INBuffer[7]);
                                            Debug_Arr2[6] = (int)(INBuffer[8]);
                                            Debug_Arr2[7] = (int)(INBuffer[9]);
                                            Debug_Arr2[8] = (int)(INBuffer[10]);
                                            Debug_Arr2[9] = (int)(INBuffer[11]);
                                            Debug_Arr2[10] = (int)(INBuffer[12]);
                                            Debug_Arr2[11] = (int)(INBuffer[13]);
                                            Debug_Arr2[12] = (int)(INBuffer[14]);
                                            Debug_Arr2[13] = (int)(INBuffer[15]);
                                            Debug_Arr2[14] = (int)(INBuffer[16]);
                                        }
                                    }
                                }
                            }
                            // Flash Read
                            if (debug_flash_read_req == true)
                            {
                                debug_flash_read_req = false;

                                for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                {
                                    OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                }

                                uint tmp_flash_read_address = debug_flash_read_start_addr;
                                uint tmp_flash_read_size = 0;
                                uint tmp_buff_set_pos = 0;
                                while(true)
                                {
                                    OUTBuffer[0] = 0;
                                    OUTBuffer[1] = 0x11;
                                    OUTBuffer[2] = (byte)((tmp_flash_read_address >> 24) & 0xFF);		//Address
                                    OUTBuffer[3] = (byte)((tmp_flash_read_address >> 16) & 0xFF);		//
                                    OUTBuffer[4] = (byte)((tmp_flash_read_address >> 8) & 0xFF);		//
                                    OUTBuffer[5] = (byte)(tmp_flash_read_address & 0xFF);		        //

                                    tmp_flash_read_size = (debug_flash_read_start_addr + debug_flash_read_size) - tmp_flash_read_address;
                                    if (tmp_flash_read_size > 60)
                                    {
                                        tmp_flash_read_size = 60;
                                    }
                                    else if(tmp_flash_read_size == 0)
                                    {   // ���ׂēǂݍ��݊���
                                        debug_flash_read_comp = true;
                                        break;
                                    }
                                    OUTBuffer[6] = (byte)(tmp_flash_read_size & 0xFF);		            //Size
                                    tmp_flash_read_address += tmp_flash_read_size;

                                    //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                    b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                                    if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //Now get the response packet from the firmware.
                                        INBuffer[0] = 0;
                                        {
                                            if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //INBuffer[0] is the report ID, which we don't care about.
                                                //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                if (INBuffer[1] == 0x11)
                                                {
                                                    if (INBuffer[2] == tmp_flash_read_size)
                                                    {
                                                        // OK
                                                        for (int fi = 0; fi < INBuffer[2]; fi++)
                                                        {
                                                            debug_flash_read_buff[tmp_buff_set_pos++] = INBuffer[3 + fi];
                                                        }
                                                    }
                                                    else
                                                    {
                                                        // NG
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        //DEBUG DEBUG DEBUG *****************************************************************************************************
#pragma warning restore 0162
                        Thread.Sleep(1);
                    } //end of: if(AttachedState == true)
                    else
                    {
                        Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                                            //high CPU utilization, with no particular benefit to the application.
                    }
                }
                catch
                {
                    //Exceptions can occur during the read or write operations.  For example,
                    //exceptions may occur if for instance the USB device is physically unplugged
                    //from the host while the above read/write functions are executing.

                    //Don't need to do anything special in this case.  The application will automatically
                    //re-establish communications based on the global AttachedState boolean variable used
                    //in conjunction with the WM_DEVICECHANGE messages to dyanmically respond to Plug and Play
                    //USB connection events.
                }

		    } //end of while(true) loop
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }



        private void FormUpdateTimer_Tick(object sender, EventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
            //This timer tick event handler function is used to update the user interface on the form, based on data
            //obtained asynchronously by the ReadWriteThread and the WM_DEVICECHANGE event handler functions.
            

            //Check if user interface on the form should be enabled or not, based on the attachment state of the USB device.
            if (AttachedState == true)
            {
                //Device is connected and ready to communicate, enable user interface on the form 
                connect_status_lbl.Text = "�ڑ�����܂����B";

            }
            if ((AttachedState == false) || (AttachedButBroken == true))
            {
                //Device not available to communicate. Disable user interface on the form.
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";

                AttachedFirstTime = true;

                ir_data_select_no = 0;
                ir_data_info_read_now_idx = 0;
                ir_data_info_read_comp = false;
                for(int fi = 0; fi < ir_data_info_read_reqs.Length; fi++)
                {
                    ir_data_info_read_reqs[fi] = true;
                }
                ir_data_info_read_req = true;

                // �o�[�W�����ǂݍ��ݗv����ݒ�
                VersionReadReq = true;
                VersionReadComp = false;

                // �R���g���[������
                my_Display_Enabled(false, false, false);
            }

            //Update the various status indicators on the form with the latest info obtained from the ReadWriteThread()
            if (AttachedState == true)
            {

                if (AttachedFirstTime == true && ir_data_info_read_comp == true)
                {
                    AttachedFirstTime = false;

                    // �R���g���[���L��
                    my_Display_Enabled(true, true, false);
                    my_progress_bar_display(false, 0, 0);


                    // ���X�g�ɕ\��
                    my_list_data_disp();

                    // �ۑ��o�b�t�@����R�s�[
                    my_Ir_data.ir_data_get(ir_data_select_no, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);
                    my_ir_data_info_now_get(ir_data_select_no);
                    my_select_data_disp(ir_data_select_no);
                }

                // �t�@�[���E�F�A�o�[�W�����\��
                if (VersionReadComp == true)
                {
                    VersionReadComp = false;

                    lbl_FW_Version.Text = "FW Version " + Encoding.Default.GetString(version_buff);
                }

                // �ǂݍ��݌���
                if (b_ir_read_stop_comp == true)
                {
                    b_ir_read_stop_comp = false;
                    lbl_ir_read_result.Text = ir_read_result_data.ToString();
                }
                // �ǂݍ��݃f�[�^�\��
                if (b_ir_read_data_get_comp == true || b_ir_data_buff_disp_req == true || b_ir_reading_flag == true)
                {
                    string read_data_header = "";
                    read_data_header = "       ";
                    int const_1line_num = 16;
                    int line_data_count = 0;
                    int line_count = 1;
                    for (int fi = 0; fi < const_1line_num; fi++)
                    {
                        read_data_header += string.Format("{0:X4} ", fi);
                    }
                    read_data_header += "\n";

                    if (b_ir_read_data_get_comp == true)
                    {   // �ǂݍ��݃f�[�^�̕\��
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < ir_read_data_get_count; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", ir_read_data[fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                        lbl_ir_read_size.Text = "Read Size:" + ir_read_data_total_size.ToString() + "bits (" + string.Format("{0}", ir_read_data_total_size * 4) + "byte) : Freq=" + ir_read_start_freq.ToString() + "Hz";
                        //// �ۑ��o�b�t�@�ɂ��R�s�[
                        //my_Ir_data.ir_data_set(ir_read_data_rec_buff_no, ir_read_start_freq, ir_read_data_total_size, ir_read_data);
                    }
                    else if (b_ir_data_buff_disp_req == true)
                    {   // �o�b�t�@�̃f�[�^��\��
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < my_Ir_data.ir_data_size[ir_data_buff_disp_no]*2; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", my_Ir_data.ir_data_rec_buff[ir_data_buff_disp_no,fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                        lbl_ir_read_size.Text = "" + my_Ir_data.ir_data_size[ir_data_buff_disp_no].ToString() + "bits (" + string.Format("{0}", my_Ir_data.ir_data_size[ir_data_buff_disp_no] * 4) + "byte) : Freq=" + my_Ir_data.ir_freq[ir_data_buff_disp_no].ToString() + "Hz";
                    }
                    else if (b_ir_reading_flag == true)
                    {   // �ǂݍ��ݒ��f�[�^�̕\��
                        reading_redraw_interval++;
                        if (reading_redraw_interval >= 40)
                        {
                            reading_redraw_interval = 0;

                            rtxtbx_ir_read_data.Text = read_data_header;
                            for (int fi = 0; fi < ir_reading_data_get_count_fix; fi++)
                            {
                                if (line_data_count == 0)
                                {
                                    line_data_count = 0;
                                    rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                    line_count++;
                                }

                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", ir_read_data[fi]);

                                line_data_count++;
                                if (line_data_count >= const_1line_num)
                                {
                                    line_data_count = 0;
                                    rtxtbx_ir_read_data.Text += "\n";
                                }
                            }
                            lbl_ir_read_size.Text = "Read Size:" + ir_read_data_total_size.ToString() + "bits (" + string.Format("{0}", ir_read_data_total_size * 4) + "byte)";
                        }
                    }

                    b_ir_read_data_get_comp = false;
                    b_ir_data_buff_disp_req = false;
                }

                if (backup_restore_flag != Constants.BACKUP_FLAG_NON)
                {
                    // �R���g���[������
                    my_Display_Enabled(false, false, false);

                    if (backup_restore_flag == Constants.BACKUP_FLAG_BACKUP)
                    {   // �o�b�N�A�b�v�I����A�R���g���[���L����
                        restore_comp_disp_enable = true;
                    }
                    else
                    {   // ���X�g�A�����Z�b�g���͍ċN��
                        restore_reboot_flag = true;
                    }

                    // �i���\��
                    if (0 <= backup_restore_progressbar_value && backup_restore_progressbar_value <= backup_restore_progressbar_max_value)
                    {
                        my_progress_bar_display(true, backup_restore_progressbar_value, backup_restore_progressbar_max_value);
                    }
                    else
                    {
                        my_progress_bar_display(true, backup_restore_progressbar_max_value, backup_restore_progressbar_max_value);
                    }
                }
                else if (backup_restore_flag == Constants.BACKUP_FLAG_NON)
                {
                    if (backup_restore_error_code > 0)
                    {   // �G���[����
                        string tmp_msg = string.Format(Constants.RESTORE_ERROR_MSG1, backup_restore_error_code);
                        backup_restore_error_code = 0;
                        MessageBox.Show(tmp_msg, Constants.APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                        restore_comp_disp_enable = true;
                    }
                    if(restore_comp_disp_enable == true)
                    {
                        restore_comp_disp_enable = false;

                        // �R���g���[���L��
                        my_Display_Enabled(true, true, false);
                        my_progress_bar_display(false, 0, 0);
                    }
                    if (restore_reboot_flag == true)
                    {
                        restore_reboot_flag = false;

                        string tmp_msg = Constants.RESTORE_COMP_WARNING_MSG1;
                        MessageBox.Show(tmp_msg, Constants.APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }


                //DEBUG
                string debug_str = "";
                colum_lbl.Text = string.Format("{0:000} : {1:000} : {2:000} : {3:000} : {4:000} : {5:000} : {6:000} : {7:000} : {8:000} : {9:000} : {10:000} : {11:000} : {12:000} : {13:000} : {14:000}",
                                                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14);

                debug01_lbl.Text = string.Format("{0:000} : {1:000} : {2:000} : {3:000} : {4:000} : {5:000} : {6:000} : {7:000} : {8:000} : {9:000} : {10:000} : {11:000} : {12:000} : {13:000} : {14:000}",
                    Debug_Array[0], Debug_Array[1], Debug_Array[2], Debug_Array[3], Debug_Array[4], Debug_Array[5], Debug_Array[6], Debug_Array[7], Debug_Array[8], Debug_Array[9], Debug_Array[10], Debug_Array[11], Debug_Array[12], Debug_Array[13], Debug_Array[14]);
                debug_str = "";
                for (int fi = 0; fi < 15; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Array[fi]);
                }
                debug02_lbl.Text = debug_str;
                debug_str = "";
                for (int fi = 0; fi < 15; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Arr2[fi]);
                }
                debug03_lbl.Text = debug_str;


                if (debug_flash_read_comp == true)
                {
                    debug_flash_read_comp = false;

                    string out_str = "0xXXXXXX:";
                    rtxtbx_debug_flash_read.Text = "";

                    // Header
                    for (int fi = 0; fi < 16; fi++)
                    {
                        out_str += string.Format(" {0:X2}", fi);
                    }

                    uint tmp_addr = debug_flash_read_start_addr & 0x1FFFF0;
                    uint tmp_buff_read_pos = 0;
                    // data
                    while (true)
                    {
                        if ((tmp_addr & 0xF) == 0)
                        {
                            out_str += string.Format("\n0x{0:X6}:", tmp_addr);
                        }
                        if (tmp_addr < debug_flash_read_start_addr)
                        {
                            out_str += string.Format("   ");
                        }
                        else if (tmp_addr < (debug_flash_read_start_addr + debug_flash_read_size))
                        {
                            if (tmp_buff_read_pos < debug_flash_read_buff.Length)
                            {
                                out_str += string.Format(" {0:X2}", debug_flash_read_buff[tmp_buff_read_pos++]);
                            }
                        }
                        else
                        {
                            break;
                        }
                        tmp_addr++;
                    }


                    rtxtbx_debug_flash_read.Text = out_str;
                }
                // DEBUG

            }

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------------
        //FUNCTION:	ReadFileManagedBuffer()
        //PURPOSE:	Wrapper function to call ReadFile()
        //
        //INPUT:	Uses managed versions of the same input parameters as ReadFile() uses.
        //
        //OUTPUT:	Returns boolean indicating if the function call was successful or not.
        //          Also returns data in the byte[] INBuffer, and the number of bytes read. 
        //
        //Notes:    Wrapper function used to call the ReadFile() function.  ReadFile() takes a pointer to an unmanaged buffer and deposits
        //          the bytes read into the buffer.  However, can't pass a pointer to a managed buffer directly to ReadFile().
        //          This ReadFileManagedBuffer() is a wrapper function to make it so application code can call ReadFile() easier
        //          by specifying a managed buffer.
        //--------------------------------------------------------------------------------------------------------------------------
        public unsafe bool ReadFileManagedBuffer(SafeFileHandle hFile, byte[] INBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            IntPtr pINBuffer = IntPtr.Zero;

            try
            {
                pINBuffer = Marshal.AllocHGlobal((int)nNumberOfBytesToRead);    //Allocate some unmanged RAM for the receive data buffer.

                if (ReadFile(hFile, pINBuffer, nNumberOfBytesToRead, ref lpNumberOfBytesRead, lpOverlapped))
                {
                    Marshal.Copy(pINBuffer, INBuffer, 0, (int)lpNumberOfBytesRead);    //Copy over the data from unmanged memory into the managed byte[] INBuffer
                    Marshal.FreeHGlobal(pINBuffer);
                    return true;
                }
                else
                {
                    Marshal.FreeHGlobal(pINBuffer);
                    return false;
                }

            }
            catch
            {
                if (pINBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pINBuffer);
                }
                return false;
            }
        }


        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
            }
            catch
            {
            }
        }

        private void btn_ir_read_start_Click(object sender, EventArgs e)
        {
            try
            {
                int freq_idx = cmbbx_ir_freq.SelectedIndex;
                if (0 <= freq_idx && freq_idx < ir_freq_select_datas.Length)
                {
                    ir_read_start_freq = ir_freq_select_datas[freq_idx];
                    b_ir_read_start_req = true;

                    btn_ir_read_start.Enabled = false;
                    btn_ir_read_stop.Enabled = true;

                    btn_Setting_Set.Enabled = false;
                    btn_setting_clr.Enabled = false;
                    btn_clip_copy.Enabled = false;
                }
            }
            catch
            {
            }
        }

        private void btn_ir_read_stop_Click(object sender, EventArgs e)
        {
            try
            {
                int buff_idx = ir_data_select_no;
                //int buff_idx = cmbbx_Read_Buff_No.SelectedIndex;
                if (0 <= buff_idx && buff_idx < Constants.IR_DATA_REC_NUM)
                {
                    ir_read_data_rec_buff_no = buff_idx;
                    ir_read_data_total_size = 0;
                    ir_read_data_get_count = 0;
                    b_ir_read_data_get_comp = false;
                    b_ir_read_stop_comp = false;
                    b_ir_read_stop_req = true;
                }
                btn_ir_read_start.Enabled = true;
                btn_ir_read_stop.Enabled = false;

                btn_Setting_Set.Enabled = true;
                btn_setting_clr.Enabled = true;
                btn_clip_copy.Enabled = true;
            }
            catch
            {
            }
        }

        private void btn_ir_data_read_Click(object sender, EventArgs e)
        {
            try
            {
                ir_read_data_total_size = 0;
                ir_read_data_get_count = 0;
                b_ir_read_data_get_comp = false;
                b_ir_read_data_get_req_debug = true;
            }
            catch
            {
            }
        }

        private void btn_ir_send_data_set_Click(object sender, EventArgs e)
        {
            try
            {
                int buff_idx = cmbbx_Send_Buff_No.SelectedIndex;
                if (0 <= buff_idx && buff_idx < Constants.IR_DATA_REC_NUM)
                {
                    ir_send_data_set_buff_no = buff_idx;
                    ir_send_data_set_pos = 0;

                    if (my_Ir_data.ir_data_size[ir_send_data_set_buff_no] > 0)
                    {
                        b_ir_send_data_set_req = true;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_ir_send_req_Click(object sender, EventArgs e)
        {
            try
            {
                int freq_idx = cmbbx_ir_freq.SelectedIndex;
                if (0 <= freq_idx && freq_idx < ir_freq_select_datas.Length)
                {
                    ir_read_start_freq = ir_freq_select_datas[freq_idx];
                    b_ir_send_send_req = true;
                }
            }
            catch
            {
            }
        }

        private void btn_match_check_Click(object sender, EventArgs e)
        {
            bool match_NG_flag = false;
            uint out_range_max = 0;
            uint check_val_min, check_val_max;
            try
            {
                int check_buff_idx = cmbbx_match_check_buff_no.SelectedIndex;
                if (0 <= check_buff_idx && check_buff_idx < Constants.IR_DATA_REC_NUM)
                {
                    // ���g��
                    if (ir_read_start_freq != my_Ir_data.ir_freq[check_buff_idx])
                    {
                        match_NG_flag = true;
                    }

                    // �T�C�Y
                    if (ir_read_data_total_size != my_Ir_data.ir_data_size[check_buff_idx])
                    {
                        match_NG_flag = true;
                    }

                    // �����܂ň�v���Ă�����A�f�[�^�`�F�b�N���s��
                    if (match_NG_flag == false)
                    {
                        for (int fi = 0; fi < my_Ir_data.ir_data_size[check_buff_idx]*2; fi++)
                        {
                            if (ir_read_data[fi] > IR_DATA_MATCH_OK_RANGE)
                            {
                                check_val_min = ir_read_data[fi] - IR_DATA_MATCH_OK_RANGE;
                            }
                            else
                            {
                                check_val_min = 0;
                            }
                            check_val_max = ir_read_data[fi] + IR_DATA_MATCH_OK_RANGE;
                            if (check_val_min <= my_Ir_data.ir_data_rec_buff[check_buff_idx, fi]
                                && my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] <= check_val_max)
                            {
                                // �͈͓�
                            }
                            else if (check_val_min > my_Ir_data.ir_data_rec_buff[check_buff_idx, fi])
                            {   // -���͈͊O
                                // �ő�덷�X�V �A���A30ms�ȏ��OFF�͌덷�̃`�F�b�N���s��Ȃ� 30,000us / 26us = 1153(0x481)
                                if ((fi % 2) == 1 && my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] < 0x500 && ir_read_data[fi] < 0x481)
                                {
                                    if (out_range_max < (ir_read_data[fi] - my_Ir_data.ir_data_rec_buff[check_buff_idx, fi]))
                                    {
                                        out_range_max = ir_read_data[fi] - my_Ir_data.ir_data_rec_buff[check_buff_idx, fi];
                                    }
                                    match_NG_flag = true;
                                }
                            }
                            else if (my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] > check_val_max)
                            {   // +���͈͊O
                                // �ő�덷�X�V �A���A30ms�ȏ��OFF�͌덷�̃`�F�b�N���s��Ȃ� 30,000us / 26us = 1153(0x481)
                                if ((fi % 2) == 1 && my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] < 0x500 && ir_read_data[fi] < 0x481)
                                {
                                    if (out_range_max < (my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] - ir_read_data[fi]))
                                    {
                                        out_range_max = my_Ir_data.ir_data_rec_buff[check_buff_idx, fi] - ir_read_data[fi];
                                    }
                                    match_NG_flag = true;
                                }
                            }
                        }
                    }

                    //���ʕ\��
                    if (match_NG_flag == true)
                    {   // �s��v
                        lbl_match_check_result.Text = "�s��v:";
                    }
                    else
                    {   // ��v
                        lbl_match_check_result.Text = "��v:";
                    }
                    lbl_match_check_result.Text += "���g��[" + ir_read_start_freq.ToString() + "," + my_Ir_data.ir_freq[check_buff_idx].ToString() + "] �T�C�Y[" + ir_read_data_total_size.ToString() + "," + my_Ir_data.ir_data_size[check_buff_idx].ToString() + "] �ő�덷[" + out_range_max.ToString() + "]";
                }
            }
            catch
            {
            }
        }

        private void btn_Disp_Buff_Click(object sender, EventArgs e)
        {
            try
            {
                int buff_idx = cmbbx_Disp_Buff_No.SelectedIndex;
                if (0 <= buff_idx && buff_idx < Constants.IR_DATA_REC_NUM)
                {
                    ir_data_buff_disp_no = buff_idx;
                    b_ir_data_buff_disp_req = true;
                }
            }
            catch
            {
            }
        }

        private void btn_ir_data_file_save_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileDialog1.Title = "Save As...";
                saveFileDialog1.Filter = "CSV file(*.csv)|*.csv|All file(*.*)|*.*";
                saveFileDialog1.DefaultExt = ".csv";
                saveFileDialog1.FileName = "";

                DialogResult dr = saveFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    my_File_Save(saveFileDialog1.FileName, true);
                }
            }
            catch
            {
            }
        }

        private int my_File_Save(string file_name, bool save_flag)
        {
            int ret = -1;
            try
            {

#if true   // CSV
                //System.Text.Encoding enc = System.Text.Encoding.GetEncoding("Shift_JIS");
                System.Text.Encoding enc = System.Text.Encoding.GetEncoding("UTF-8");
                System.IO.StreamWriter sw = null;
                try
                {
                    sw = new System.IO.StreamWriter(file_name, false, enc);
                    string out_str = "";
                    string tmp_str = "";
                    for (int data_idx = 0; data_idx < Constants.IR_DATA_REC_NUM; data_idx++)
                    {
                        out_str = "";

                        // memo
                        tmp_str = my_Ir_data.memo[data_idx];
                        out_str = my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // freq
                        tmp_str = string.Format("{0}", my_Ir_data.ir_freq[data_idx]);
                        out_str += my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // size
                        tmp_str = string.Format("{0}", my_Ir_data.ir_data_size[data_idx]);
                        out_str += my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // data
                        for (int data_pos = 0; data_pos < (my_Ir_data.ir_data_size[data_idx]*2); data_pos++)
                        {
                            if (data_pos > 0)
                            {
                                out_str += ",";
                            }
                            tmp_str = string.Format("0x{0:X4}", my_Ir_data.ir_data_rec_buff[data_idx, data_pos]);
                            out_str += my_Enclose_Double_Quotes(tmp_str);
                        }
                        sw.Write(out_str);
                        sw.Write("\r\n");//���s
                    }
                }
                catch
                {
                    sw.Write("\r\nerror");
                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Close();
                        sw.Dispose();
                    }
                }

#endif
#if false   // XML
                Stream stream = null;
                try
                {
                    stream = File.Open(file_name, FileMode.Create);
                    SoapFormatter formatter = new SoapFormatter();

                    formatter.Serialize(stream, my_Ir_data);
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                        stream.Dispose();
                    }
                }
#endif
            }
            catch
            {
            }
            return ret;
        }

        private void btn_ir_data_file_read_Click(object sender, EventArgs e)
        {
            int i_ret = 0;
            try
            {
                openFileDialog1.Title = "Open...";
                openFileDialog1.Filter = "CSV file(*.csv)|*.csv|All file(*.*)|*.*";
                openFileDialog1.DefaultExt = ".csv";
                openFileDialog1.FileName = "";

                DialogResult dr = openFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    i_ret = my_File_Read(openFileDialog1.FileName);

                    if (i_ret > 0)
                    {
                        my_Ir_data.ir_data_get(0, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);
                        ir_read_data_get_count = ir_read_data_total_size * 2;

                        my_list_data_disp();
                    }
                }
            }
            catch
            {
            }
        }

        private int my_File_Read(string file_name)
        {
            int ret = 0;
            try
            {

#if true   // CSV
                //System.Text.Encoding enc = System.Text.Encoding.GetEncoding("Shift_JIS");
                System.Text.Encoding enc = System.Text.Encoding.GetEncoding("UTF-8");
                System.IO.StreamReader sr = null;
                try
                {
                    sr = new System.IO.StreamReader(file_name, enc);
                    string in_str = "";
                    int read_idx = 0;

                    my_Ir_data.ir_data_all_clear();

                    while (sr.Peek() > -1 && read_idx < Constants.IR_DATA_REC_NUM && ret >= 0)
                    {
                        in_str = sr.ReadLine();
                        try
                        {
                            string[] in_str_arry = new string[1];
                            if (my_csv_to_array_buff(in_str, ref in_str_arry) >= 3)
                            {   // freq, data size
                                string memo = in_str_arry[0];
                                int freq = int.Parse(in_str_arry[1]);
                                int data_size = int.Parse(in_str_arry[2]);
                                if (data_size > 0)
                                {   // �f�[�^����
                                    if (in_str_arry.Length >= (2 + data_size))
                                    {   // �f�[�^�T�C�Y�Ǝ��ۂ̃f�[�^�̐����`�F�b�N
                                        uint[] tmp_data = new uint[data_size*2];
                                        try
                                        {
                                            for (int fi = 0; fi < (data_size*2); fi++)
                                            {
                                                //tmp_data[fi] = uint.Parse(in_str_arry[3+fi], System.Globalization.NumberStyles.HexNumber);
                                                tmp_data[fi] = Convert.ToUInt32(in_str_arry[3 + fi], 16);
                                            }

                                            // �����܂ŃG���[�Ȃ�
                                            // �f�[�^�Z�b�g
                                            my_Ir_data.ir_data_set(read_idx, memo, freq, data_size, tmp_data);
                                            ret++;
                                        }
                                        catch
                                        {
                                            ret = -3;
                                        }
                                    }
                                }
                            }
                        }
                        catch
                        {
                            ret = -2;
                        }
                        read_idx++;
                    }
                }
                catch
                {
                    ret = -1;
                }
                finally
                {
                    if (sr != null)
                    {
                        sr.Close();
                        sr.Dispose();
                    }
                }

#endif
#if false   // XML
                Stream stream = null;
                try
                {
                    stream = File.Open(file_name, FileMode.Open);
                    SoapFormatter formatter = new SoapFormatter();

                    my_Ir_data = (IrData)formatter.Deserialize(stream);
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                        stream.Dispose();
                    }
                }
#endif
            }
            catch
            {
            }
            return ret;
        }

        private void btn_clip_copy_Click(object sender, EventArgs e)
        {
            string clip_copy_data = "";
            try
            {
                if (ir_read_data_total_size > 0)
                {
                    int line_data_count = 0;
                    for (int fi = 0; fi < ir_read_data_total_size * 2; fi++)
                    {
                        if (fi != 0)
                        {
                            clip_copy_data += ",";
                        }
                        if (line_data_count == 16)
                        {
                            line_data_count = 0;
                            //clip_copy_data += "\n";
                        }
                        clip_copy_data += string.Format("0x{0:X2},0x{1:X2}", (ir_read_data[fi] >> 8) & 0xFF, ir_read_data[fi] & 0xFF);
                        line_data_count++;
                    }
                }
#if false
                if (my_Ir_data.ir_data_size[ir_data_select_no] > 0)
                {
                    int line_data_count = 0;
                    for (int fi = 0; fi < my_Ir_data.ir_data_size[ir_data_select_no] * 2; fi++)
                    {
                        if(fi != 0)
                        {
                            clip_copy_data += ",";
                        }
                        if (line_data_count == 16)
                        {
                            line_data_count = 0;
                            //clip_copy_data += "\n";
                        }
                        clip_copy_data += string.Format("0x{0:X2},0x{1:X2}", (my_Ir_data.ir_data_rec_buff[ir_data_select_no, fi] >> 8) & 0xFF, my_Ir_data.ir_data_rec_buff[ir_data_select_no, fi] & 0xFF);
                        line_data_count++;
                    }
                }
#endif

                Clipboard.SetDataObject(clip_copy_data, true);
            }
            catch
            {
            }
        }

        private void my_select_data_disp(int p_select_no)
        {
            try
            {
                if (0 <= p_select_no && p_select_no < Constants.IR_DATA_REC_NUM)
                {
                    lbl_SelectNo.Text = "No." + string.Format("{0:00}", p_select_no + 1);

                    txtbx_memo.Text = my_Ir_data.memo[p_select_no];
                    if (txtbx_memo.Text == "")
                    {
                        txtbx_memo.Text = Constants.IR_DATA_MEMO_DEFAULT;
                    }

                    string read_data_header = "";
                    read_data_header = "       ";
                    int const_1line_num = 16;
                    int line_data_count = 0;
                    int line_count = 1;
                    for (int fi = 0; fi < const_1line_num; fi++)
                    {
                        read_data_header += string.Format("{0:X4} ", fi);
                    }
                    read_data_header += "\n";

                    // �o�b�t�@�̃f�[�^��\��
                    if (my_Ir_data.ir_data_size[p_select_no] > 0)
                    {
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < my_Ir_data.ir_data_size[p_select_no] * 2; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", my_Ir_data.ir_data_rec_buff[p_select_no, fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                    }
                    else
                    {
                        rtxtbx_ir_read_data.Text = "";
                    }
                    lbl_ir_read_size.Text = "Read Size:" + my_Ir_data.ir_data_size[p_select_no].ToString() + "bits (" + string.Format("{0}", my_Ir_data.ir_data_size[p_select_no] * 4) + "byte) : Freq=" + my_Ir_data.ir_freq[p_select_no].ToString() + "Hz";

                    // USB �ݒ�
                    cmbbx_device_type.SelectedIndex = ir_data_info_select.device_type;
                    my_usb_input_value_set(ir_data_info_select.device_type, ir_data_info_select.device_data, ir_data_info_select.device_data_size);
                }
                else
                {
                }
            }
            catch
            {
            }
        }

        private void my_list_data_disp()
        {
            sbyte tmp_sbyte;
            try
            {
                for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++ )
                {
                    my_memo_textbox[fi].Text = my_Ir_data.memo[fi];

                    string tmp_assign = "";
                    if (ir_data_infos[fi].device_type < device_type_disp.Length)
                    {
                        tmp_assign = device_type_disp[ir_data_infos[fi].device_type];

                        switch (ir_data_infos[fi].device_type)
                        {
                            case DEVICE_TYPE_NONE:
                                break;
                            case DEVICE_TYPE_MOUSE:
                                if(ir_data_infos[fi].device_data_size > 0)
                                {
                                    for (int fj = 0; fj < mouse_set_value.Length && fj < mouse_select_value_disp.Length; fj++)
                                    {
                                        if (mouse_set_value[fj] == ir_data_infos[fi].device_data[MOUSE_DATA_SET_IDX])
                                        {
                                            tmp_assign += " " + mouse_select_value_disp[fj];

                                            if (fj == MOUSE_VALUE_MOUSEMOVE)
                                            {   // X, Y
                                                if (ir_data_infos[fi].device_data[MOUSE_X_DATA_SET_IDX] > 0x7F)
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_X_DATA_SET_IDX] - 0x100);
                                                }
                                                else
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_X_DATA_SET_IDX]);
                                                }
                                                tmp_assign += " X:" + tmp_sbyte;
                                                if (ir_data_infos[fi].device_data[MOUSE_Y_DATA_SET_IDX] > 0x7F)
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_Y_DATA_SET_IDX] - 0x100);
                                                }
                                                else
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_Y_DATA_SET_IDX]);
                                                }
                                                tmp_assign += " Y:" + tmp_sbyte;
                                            }
                                            else if (fj == MOUSE_VALUE_WHEELSCROLL)
                                            {   // WS
                                                if (ir_data_infos[fi].device_data[MOUSE_WS_DATA_SET_IDX] > 0x7F)
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_WS_DATA_SET_IDX] - 0x100);
                                                }
                                                else
                                                {
                                                    tmp_sbyte = (sbyte)(ir_data_infos[fi].device_data[MOUSE_WS_DATA_SET_IDX]);
                                                }
                                                tmp_assign += " " + tmp_sbyte;
                                            }

                                            break;
                                        }
                                    }
                                }
                                break;
                            case DEVICE_TYPE_KEYBOARD:
                                if (ir_data_infos[fi].device_data_size > 0)
                                {
                                    // Modifier
                                    int mod_count = 0;
                                    for (int fj = 0; fj < keyboard_set_value.Length && fj < keyboard_select_value_disp.Length; fj++)
                                    {
                                        if ((ir_data_infos[fi].device_data[KEYBOARD_DATA_MODIFIER_SET_IDX] & keyboard_set_value[fj]) != 0)
                                        {
                                            if (mod_count == 0)
                                            {
                                                tmp_assign += " ";
                                            }
                                            else
                                            {
                                                tmp_assign += "+";
                                            }
                                            tmp_assign += keyboard_select_value_disp[fj];
                                            mod_count++;
                                        }
                                    }

                                    // Key
                                    if (ir_data_infos[fi].device_data[KEYBOARD_DATA_KEYCODE_SET_IDX] != 0)
                                    {
                                        for (int fj = 0; fj < VKtoUSBkey.Length; fj++)
                                        {
                                            if (ir_data_infos[fi].device_data[KEYBOARD_DATA_KEYCODE_SET_IDX] == VKtoUSBkey[fj])
                                            {
                                                tmp_assign += " + " + ((Keys)fj).ToString();
                                                break;
                                            }
                                        }
                                    }
                                }
                                break;
                            case DEVICE_TYPE_VOLUME:
                                if (ir_data_infos[fi].device_data_size > 0)
                                {
                                    for (int fj = 0; fj < volume_set_value.Length && fj < volume_select_value_disp.Length; fj++)
                                    {
                                        if (volume_set_value[fj] == ir_data_infos[fi].device_data[VOLUME_DATA_SET_IDX])
                                        {
                                            tmp_assign += " " + volume_select_value_disp[fj];
                                            break;
                                        }
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    my_set_data_textbox[fi].Text = tmp_assign;

                }
            }
            catch
            {
            }
        }

        private void btn_Setting_Set_Click(object sender, EventArgs e)
        {
            try
            {
                if (0 <= ir_data_select_no && ir_data_select_no < Constants.IR_DATA_REC_NUM)
                {
                    // �ۑ��o�b�t�@�ɂ��R�s�[
                    my_Ir_data.ir_data_set(ir_data_select_no, txtbx_memo.Text, ir_read_start_freq, ir_read_data_total_size, ir_read_data);

                    // �ݒ肵��USB���͐ݒ�l����荞��Ńo�b�t�@�ɕۑ�
                    my_usb_setting_data_set();
                    my_ir_data_info_now_set(ir_data_select_no);

                    // ���X�g�ɕ\��
                    my_list_data_disp();

                    // Flash�֕ۑ��v��
                    ir_data_info_erase_reqs[ir_data_select_no] = true;
                    ir_data_info_erase_comp = false;
                    ir_data_info_erase_req = true;
                    ir_data_info_write_reqs[ir_data_select_no] = true;
                    ir_data_info_write_comp = false;
                    ir_data_info_write_req = true;

                }
            }
            catch
            {
            }
        }

        private void btn_setting_clr_Click(object sender, EventArgs e)
        {
            try
            {
                if (0 <= ir_data_select_no && ir_data_select_no < Constants.IR_DATA_REC_NUM)
                {
                    //�����m�F
                    string tmp_msg = string.Format(Constants.IR_DATA_CLEAR_MSG, ir_data_select_no+1);
                    if (DialogResult.OK == MessageBox.Show(tmp_msg, Constants.APPLICATION_NAME, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning))
                    {
                        // �ۑ��o�b�t�@���N���A
                        my_Ir_data.ir_data_clear(ir_data_select_no);

                        //// �ݒ肵��USB���͐ݒ�l����荞��Ńo�b�t�@�ɕۑ�
                        cmbbx_device_type.SelectedIndex = DEVICE_TYPE_NONE;
                        my_usb_setting_data_set();
                        ir_data_infos[ir_data_select_no].clr();


                        // �ۑ��o�b�t�@����R�s�[
                        my_Ir_data.ir_data_get(ir_data_select_no, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);

                        my_ir_data_info_now_get(ir_data_select_no);

                        my_select_data_disp(ir_data_select_no);

                        // ���X�g�ɕ\��
                        my_list_data_disp();

                        // Flash�����v��
                        ir_data_info_erase_reqs[ir_data_select_no] = true;
                        ir_data_info_erase_comp = false;
                        ir_data_info_erase_req = true;
                        // �N���A�f�[�^�ۑ�
                        ir_data_info_write_reqs[ir_data_select_no] = true;
                        ir_data_info_write_comp = false;
                        ir_data_info_write_req = true;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_select_No_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.IR_DATA_REC_NUM && btn_ir_read_start.Enabled == true)
                {
                    ir_data_select_no = idx;


                    // �ۑ��o�b�t�@����R�s�[
                    my_Ir_data.ir_data_get(ir_data_select_no, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);

                    my_ir_data_info_now_get(ir_data_select_no);

                    my_select_data_disp(ir_data_select_no);
                }
            }
            catch
            {
            }
        }

        private void btn_send_No_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.IR_DATA_REC_NUM)
                {
                    ir_send_data_set_buff_no = idx;
                    ir_send_data_set_pos = 0;
                    b_ir_send_data_set_req = true;
                }
            }
            catch
            {
            }
        }
        /// �w�肳�ꂽ��������ɂ��镶��������邩������
        private static int my_Count_String(string strInput, string strFind)
        {
            int foundCount = 0;
            int sPos = strInput.IndexOf(strFind);
            while (sPos > -1)
            {
                foundCount++;
                sPos = strInput.IndexOf(strFind, sPos + 1);
            }

            return foundCount;
        }
        /// ��������_�u���N�H�[�g�ň͂�
        private static string my_Enclose_Double_Quotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"��""�Ƃ���
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }
        private int my_csv_to_array_buff(string p_csv_text, ref string[] o_csv_buff)
        {
            int i_ret = 0;
            try
            {
                //�O��̉��s���폜���Ă���
                p_csv_text = p_csv_text.Trim(new char[] { '\r', '\n' });

                //1�s��CSV����e�t�B�[���h���擾���邽�߂̐��K�\��
                System.Text.RegularExpressions.Regex regCsv =
                    new System.Text.RegularExpressions.Regex(
                    "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                    System.Text.RegularExpressions.RegexOptions.None);

                // "�̐������������ׂ�
                if ((my_Count_String(p_csv_text, "\"") % 2) == 0)
                {
                    //�s�̍Ō�̉��s�L�����폜
                    p_csv_text = p_csv_text.TrimEnd(new char[] { '\r', '\n' });
                    //�Ō�Ɂu,�v������
                    p_csv_text += ",";

                    //1�̍s����t�B�[���h�����o��
                    System.Collections.ArrayList csvFields = new System.Collections.ArrayList();
                    System.Text.RegularExpressions.Match m = regCsv.Match(p_csv_text);
                    while (m.Success)
                    {
                        string field = m.Groups[1].Value;
                        //�O��̋󔒂��폜
                        field = field.Trim();
                        //"�ň͂܂�Ă��鎞
                        if (field.StartsWith("\"") && field.EndsWith("\""))
                        {
                            //�O���"�����
                            field = field.Substring(1, field.Length - 2);
                            //�u""�v���u"�v�ɂ���
                            field = field.Replace("\"\"", "\"");
                        }
                        csvFields.Add(field);
                        m = m.NextMatch();
                    }

                    csvFields.TrimToSize();

                    // �o�̓o�b�t�@�ɃZ�b�g
                    o_csv_buff = new string[csvFields.Count];
                    for (int fi = 0; fi < csvFields.Count; fi++ )
                    {
                        o_csv_buff[fi] = csvFields[fi].ToString();
                    }
                    i_ret = csvFields.Count;
                }
                else
                {   // "�̐����
                    i_ret = -1;
                }
            }
            catch
            {
            }
            return i_ret;
        }

        private void txtbx_memo_Enter(object sender, EventArgs e)
        {
            try
            {
                if (txtbx_memo.Text == Constants.IR_DATA_MEMO_DEFAULT)
                {
                    txtbx_memo.SelectAll();
                }
            }
            catch
            {
            }
        }

        private void btn_debug_flash_read_Click(object sender, EventArgs e)
        {
            try
            {
                debug_flash_read_start_addr = Convert.ToUInt32(txtbx_debug_flash_read_addr.Text, 16);
                debug_flash_read_size = Convert.ToUInt32(txtbx_debug_flash_read_size.Text, 16);
                if (debug_flash_read_size < debug_flash_read_buff.Length
                    && (debug_flash_read_start_addr + debug_flash_read_size) < 0x200000)
                {
                    debug_flash_read_comp = false;
                    debug_flash_read_req = true;
                }
            }
            catch
            {
            }
        }

        private void my_usb_input_set_control_enabled(int p_device_type)
        {
            try
            {
                switch (p_device_type)
                {
                    case DEVICE_TYPE_NONE:
                        cmbbx_mouse_input.Visible = false;
                        num_x.Visible = false;
                        num_y.Visible = false;
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                        {
                            my_keyboard_modifier[fi].Visible = false;
                        }
                        txtbx_Key_Input.Visible = false;
                        cmbbx_volume_input.Visible = false;
                        break;
                    case DEVICE_TYPE_MOUSE:
                        cmbbx_mouse_input.Visible = true;
                        num_x.Visible = false;
                        num_y.Visible = false;
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                        {
                            my_keyboard_modifier[fi].Visible = false;
                        }
                        txtbx_Key_Input.Visible = false;
                        cmbbx_volume_input.Visible = false;
                        break;
                    case DEVICE_TYPE_KEYBOARD:
                        cmbbx_mouse_input.Visible = false;
                        num_x.Visible = false;
                        num_y.Visible = false;
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                        {
                            my_keyboard_modifier[fi].Visible = true;
                        }
                        txtbx_Key_Input.Visible = true;
                        cmbbx_volume_input.Visible = false;
                        break;
                    case DEVICE_TYPE_VOLUME:
                        cmbbx_mouse_input.Visible = false;
                        num_x.Visible = false;
                        num_y.Visible = false;
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                        {
                            my_keyboard_modifier[fi].Visible = false;
                        }
                        txtbx_Key_Input.Visible = false;
                        cmbbx_volume_input.Visible = true;
                        break;
                }
            }
            catch
            {
            }
        }
        private void my_usb_input_value_set(int p_device_type, byte[] p_device_data, byte p_device_data_size)
        {
            sbyte tmp_sbyte;
            decimal tmp_dec;
            try
            {
                // ��U�N���A
                for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                {
                    my_keyboard_modifier[fi].Checked = false;
                }
                txtbx_Key_Input.Text = "�����ɓ���";
                cmbbx_mouse_input.SelectedIndex = 0;
                cmbbx_volume_input.SelectedIndex = 0;

                switch (p_device_type)
                {
                    case DEVICE_TYPE_NONE:
                        break;
                    case DEVICE_TYPE_MOUSE:
                        for (int fi = 0; fi < mouse_set_value.Length && fi < cmbbx_mouse_input.Items.Count; fi++)
                        {
                            if (p_device_data[MOUSE_DATA_SET_IDX] == mouse_set_value[fi])
                            {
                                cmbbx_mouse_input.SelectedIndex = fi;

                                if(fi == MOUSE_VALUE_MOUSEMOVE)
                                {
                                    if (p_device_data[MOUSE_X_DATA_SET_IDX] > 0x7F)
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_X_DATA_SET_IDX] - 0x100);
                                    }
                                    else
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_X_DATA_SET_IDX]);
                                    }
                                    tmp_dec = tmp_sbyte;
                                    num_x.Value = tmp_dec;
                                    if (p_device_data[MOUSE_Y_DATA_SET_IDX] > 0x7F)
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_Y_DATA_SET_IDX] - 0x100);
                                    }
                                    else
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_Y_DATA_SET_IDX]);
                                    }
                                    tmp_dec = tmp_sbyte;
                                    num_y.Value = tmp_dec;
                                }
                                else if (fi == MOUSE_VALUE_WHEELSCROLL)
                                {
                                    if (p_device_data[MOUSE_WS_DATA_SET_IDX] > 0x7F)
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_WS_DATA_SET_IDX] - 0x100);
                                    }
                                    else
                                    {
                                        tmp_sbyte = (sbyte)(p_device_data[MOUSE_WS_DATA_SET_IDX]);
                                    }
                                    tmp_dec = tmp_sbyte;
                                    num_x.Value = tmp_dec;
                                }

                                break;
                            }
                        }
                        break;
                    case DEVICE_TYPE_KEYBOARD:
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++)
                        {
                            if (((p_device_data[KEYBOARD_DATA_MODIFIER_SET_IDX] >> fi) & 0x01) != 0)
                            {
                                my_keyboard_modifier[fi].Checked = true;
                            }
                            else
                            {
                                my_keyboard_modifier[fi].Checked = false;
                            }
                        }
                        // Key
                        if (p_device_data[KEYBOARD_DATA_KEYCODE_SET_IDX] == 0)
                        {
                            txtbx_Key_Input.Text = "�����ɓ���";
                        }
                        else
                        {
                            for (int fj = 0; fj < VKtoUSBkey.Length; fj++)
                            {
                                if (p_device_data[KEYBOARD_DATA_KEYCODE_SET_IDX] == VKtoUSBkey[fj])
                                {
                                    txtbx_Key_Input.Text = ((Keys)fj).ToString();

                                    tmp_keyboard_input_key = p_device_data[KEYBOARD_DATA_KEYCODE_SET_IDX];
                                    break;
                                }
                            }
                        }
                        break;
                    case DEVICE_TYPE_VOLUME:
                        for (int fi = 0; fi < volume_set_value.Length && fi < cmbbx_volume_input.Items.Count; fi++)
                        {
                            if (p_device_data[VOLUME_DATA_SET_IDX] == volume_set_value[fi])
                            {
                                cmbbx_volume_input.SelectedIndex = fi;
                                break;
                            }
                        }
                        break;
                }
            }
            catch
            {
            }
        }

        private void my_ir_data_info_now_get(int p_select_no)
        {
            try
            {
                if (0 <= p_select_no && p_select_no < ir_data_infos.Length)
                {
                    ir_data_infos[p_select_no].get(ref ir_data_info_select.ir_freq, 
                                                    ref ir_data_info_select.ir_data_byte_size,
                                                    ref ir_data_info_select.ir_data_bit_len,
                                                    ref ir_data_info_select.device_type,
                                                    ref ir_data_info_select.device_data_size,
                                                    ir_data_info_select.device_data,
                                                    ref ir_data_info_select.memo_byte_size,
                                                    ir_data_info_select.memo_data);
                }
            }
            catch
            {
            }
        }

        private void my_ir_data_info_now_set(int p_set_no)
        {
            try
            {
                if (0 <= p_set_no && p_set_no < ir_data_infos.Length)
                {
                    ir_data_info_select.ir_freq = (uint)ir_read_start_freq;
                    ir_data_info_select.ir_data_byte_size = (uint)ir_read_data_total_size * 4;
                    ir_data_info_select.ir_data_bit_len = (uint)ir_read_data_total_size;
                    byte[] data = System.Text.Encoding.Unicode.GetBytes(txtbx_memo.Text);
                    ir_data_info_select.memo_byte_size = (byte)(data.Length & 0xFF);
                    Array.Copy(data, 0, ir_data_info_select.memo_data, 0, data.Length & 0xFF);
                    for (int fi = 0; fi < data.Length; fi++ )
                    {
                        ir_data_infos[p_set_no].memo_data[fi] = data[fi];
                    }

                    ir_data_infos[p_set_no].set(ir_data_info_select.ir_freq,
                                                ir_data_info_select.ir_data_byte_size,
                                                ir_data_info_select.ir_data_bit_len,
                                                ir_data_info_select.device_type,
                                                ir_data_info_select.device_data_size,
                                                ir_data_info_select.device_data,
                                                ir_data_info_select.memo_byte_size,
                                                ir_data_info_select.memo_data);
                }
            }
            catch
            {
            }
        }

        private void my_usb_setting_data_set()
        {
            try
            {
                ir_data_info_select.clr();

                switch(cmbbx_device_type.SelectedIndex)
                {
                    case DEVICE_TYPE_NONE:
                        ir_data_info_select.device_type = (byte)(DEVICE_TYPE_NONE & 0xFF);
                        break;
                    case DEVICE_TYPE_MOUSE:
                        ir_data_info_select.device_type = (byte)(DEVICE_TYPE_MOUSE & 0xFF);
                        ir_data_info_select.device_data_size = 4;
                        if (0 <= cmbbx_mouse_input.SelectedIndex && cmbbx_mouse_input.SelectedIndex < mouse_set_value.Length)
                        {
                            ir_data_info_select.device_data[MOUSE_DATA_SET_IDX] = mouse_set_value[cmbbx_mouse_input.SelectedIndex];

                            if (cmbbx_mouse_input.SelectedIndex == MOUSE_VALUE_MOUSEMOVE)
                            {
                                ir_data_info_select.device_data[MOUSE_X_DATA_SET_IDX] = (byte)((int)(num_x.Value) & 0xFF);
                                ir_data_info_select.device_data[MOUSE_Y_DATA_SET_IDX] = (byte)((int)(num_y.Value) & 0xFF);
                            }
                            else if (cmbbx_mouse_input.SelectedIndex == MOUSE_VALUE_WHEELSCROLL)
                            {
                                ir_data_info_select.device_data[MOUSE_WS_DATA_SET_IDX] = (byte)((int)(num_x.Value) & 0xFF);
                            }
                        }
                        break;
                    case DEVICE_TYPE_KEYBOARD:
                        ir_data_info_select.device_type = (byte)(DEVICE_TYPE_KEYBOARD & 0xFF);
                        ir_data_info_select.device_data_size = 8;
                        for (int fi = 0; fi < my_keyboard_modifier.Length; fi++ )
                        {
                            if (my_keyboard_modifier[fi].Checked == true)
                            {
                                ir_data_info_select.device_data[KEYBOARD_DATA_MODIFIER_SET_IDX] |= keyboard_set_value[fi];
                            }
                        }
                        ir_data_info_select.device_data[KEYBOARD_DATA_KEYCODE_SET_IDX] = tmp_keyboard_input_key; // USB Key
                        break;
                    case DEVICE_TYPE_VOLUME:
                        ir_data_info_select.device_type = (byte)(DEVICE_TYPE_VOLUME & 0xFF);
                        if (0 <= cmbbx_volume_input.SelectedIndex && cmbbx_volume_input.SelectedIndex < volume_set_value.Length)
                        {
                            ir_data_info_select.device_data[VOLUME_DATA_SET_IDX] = volume_set_value[cmbbx_volume_input.SelectedIndex];
                        }
                        break;
                    default:
                        ir_data_info_select.device_type = (byte)(DEVICE_TYPE_NONE & 0xFF);
                        break;
                }
            }
            catch
            {
            }
        }

        private void cmbbx_device_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                my_usb_input_set_control_enabled(cmbbx_device_type.SelectedIndex);
            }
            catch
            {
            }
        }

        private void txtbx_Key_Input_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                if (txtbx_Key_Input.Text != e.KeyCode.ToString())
                {
                    txtbx_Key_Input.Text = e.KeyCode.ToString();
                    tmp_keyboard_input_key = VKtoUSBkey[e.KeyCode.GetHashCode()];
                    e.IsInputKey = true;
                }
            }
        }

        private void txtbx_Key_Input_KeyDown(object sender, KeyEventArgs e)
        {
            txtbx_Key_Input.Text = e.KeyCode.ToString();
            tmp_keyboard_input_key = VKtoUSBkey[e.KeyCode.GetHashCode()];
            e.SuppressKeyPress = true;
        }

        private void txtbx_Key_Input_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.PrintScreen)
            {
                if (txtbx_Key_Input.Text != e.KeyCode.ToString())
                {
                    txtbx_Key_Input.Text = e.KeyCode.ToString();
                    tmp_keyboard_input_key = VKtoUSBkey[e.KeyCode.GetHashCode()];
                    e.SuppressKeyPress = true;
                }
            }
        }

        private void cmbbx_mouse_input_SelectedIndexChanged(object sender, EventArgs e)
        {
            sbyte tmp_sbyte;
            decimal tmp_dec;
            try
            {
                switch (cmbbx_mouse_input.SelectedIndex)
                {
                    case MOUSE_VALUE_MOUSEMOVE:
                        if (ir_data_info_select.device_data[MOUSE_X_DATA_SET_IDX] > 0x7F)
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_X_DATA_SET_IDX] - 0x100);
                        }
                        else
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_X_DATA_SET_IDX]);
                        }
                        tmp_dec = tmp_sbyte;
                        num_x.Value = tmp_dec;
                        if (ir_data_info_select.device_data[MOUSE_Y_DATA_SET_IDX] > 0x7F)
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_Y_DATA_SET_IDX] - 0x100);
                        }
                        else
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_Y_DATA_SET_IDX]);
                        }
                        tmp_dec = tmp_sbyte;
                        num_y.Value = tmp_dec;
                        num_x.Visible = true;
                        num_y.Visible = true;
                        break;
                    case MOUSE_VALUE_WHEELSCROLL:
                        if (ir_data_info_select.device_data[MOUSE_WS_DATA_SET_IDX] > 0x7F)
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_WS_DATA_SET_IDX] - 0x100);
                        }
                        else
                        {
                            tmp_sbyte = (sbyte)(ir_data_info_select.device_data[MOUSE_WS_DATA_SET_IDX]);
                        }
                        tmp_dec = tmp_sbyte;
                        num_x.Value = tmp_dec;
                        num_x.Visible = true;
                        num_y.Visible = false;
                        break;
                    default:
                        num_x.Value = 0;
                        num_y.Value = 0;
                        num_x.Visible = false;
                        num_y.Visible = false;
                        break;
                }
            }
            catch
            {
            }
        }

        private void btn_backup_export_Click(object sender, EventArgs e)
        {
            try
            {
                //�t�@�C�����쐬
                string file_name = "backup_";
                DateTime dt = DateTime.Now;

                //���t�ǉ�
                file_name += string.Format("{0:0000}{1:00}{2:00}_{3:00}{4:00}{5:00}", dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);
                saveFileDialog1.FileName = file_name;

                if (saveFileDialog1.InitialDirectory == "")
                {
                    saveFileDialog1.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                }
                saveFileDialog1.Title = Constants.BACKUP_FILE_SAVE_DIALOG_TITLE;
                saveFileDialog1.DefaultExt = Constants.BACKUP_FILE_EXTENSION;
                saveFileDialog1.Filter = Constants.BACKUP_FILE_FILTER;

                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    // �v���O���X�o�[�̍ő�l��ݒ�
                    int prog_max = 0;
                    // Backup�̏ꍇ�́AFlashMemory�̓ǂݍ��݉񐔂����Z
                    prog_max = prog_max + (int)(Constants.FM_TOTAL_SIZE / Constants.FM_USB_READ_DATA_SIZE) + 1;
                    my_progress_bar_display(true, 0, prog_max);
                    backup_restore_progressbar_value = 0;
                    backup_restore_progressbar_max_value = prog_max;

                    backup_restore_error_code = 0;
                    backup_file_path = saveFileDialog1.FileName;
                    backup_restore_flag = Constants.BACKUP_FLAG_BACKUP;
                }
            }
            catch
            {
            }
        }

        private void btn_backup_import_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show(Constants.RESTORE_WARNING_MSG, Constants.APPLICATION_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    openFileDialog1.Title = Constants.BACKUP_FILE_OPEN_DIALOG_TITLE;
                    openFileDialog1.DefaultExt = Constants.BACKUP_FILE_EXTENSION;
                    openFileDialog1.Filter = Constants.BACKUP_FILE_FILTER;
                    openFileDialog1.FileName = "";
                    if (openFileDialog1.InitialDirectory == "")
                    {
                        openFileDialog1.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                    }

                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        // �v���O���X�o�[�̍ő�l��ݒ�
                        int prog_max = 0;
                        // Flash�����̏ꍇ�́A�Z�N�^�[�������Z
                        prog_max += (int)Constants.FM_SECTOR_NUM;
                        // Restore�̏ꍇ�́AFlashMemory�̏������݉񐔂����Z
                        prog_max = prog_max + (((int)Constants.FM_TOTAL_SIZE / 0x100) * ((0x100 / (int)Constants.FM_USB_WRITE_DATA_SIZE) + 1));
                        my_progress_bar_display(true, 0, prog_max);
                        backup_restore_progressbar_value = 0;
                        backup_restore_progressbar_max_value = prog_max;

                        backup_restore_error_code = 0;
                        backup_file_path = openFileDialog1.FileName;
                        backup_restore_flag = Constants.BACKUP_FLAG_RESTORE;
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_setup_reset_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show(Constants.FLASHERASE_WARNING_MSG, Constants.APPLICATION_NAME, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    my_progress_bar_display(true, 0, (int)Constants.FM_SECTOR_NUM);
                    backup_restore_progressbar_value = 0;
                    backup_restore_progressbar_max_value = (int)Constants.FM_SECTOR_NUM;

                    backup_restore_error_code = 0;
                    backup_restore_flag = Constants.BACKUP_FLAG_RESET;
                }
            }
            catch
            {
            }
        }


        private void my_progress_bar_display(bool p_visible, int p_now_val, int p_max_val)
        {
            try
            {
                if (p_visible == true)
                {   // �\��
                    pgb_process_status.Value = p_now_val;
                    pgb_process_status.Maximum = p_max_val;
                    lbl_progress_now_value.Text = p_now_val.ToString();
                    lbl_progress_total_value.Text = p_max_val.ToString();

                    pgb_process_status.Visible = p_visible;
                    lbl_progress_title.Visible = p_visible;
                    lbl_progress_now_value.Visible = p_visible;
                    lbl_progress_per.Visible = p_visible;
                    lbl_progress_total_value.Visible = p_visible;
                }
                else
                {   // ��\��
                    pgb_process_status.Visible = p_visible;
                    lbl_progress_title.Visible = p_visible;
                    lbl_progress_now_value.Visible = p_visible;
                    lbl_progress_per.Visible = p_visible;
                    lbl_progress_total_value.Visible = p_visible;

                    pgb_process_status.Value = 0;
                    pgb_process_status.Maximum = 0;
                    lbl_progress_now_value.Text = "0";
                    lbl_progress_total_value.Text = "0";
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// Backup �t�@�C���̓ǂݏo��
        /// </summary>
        /// <param name="p_File_Path"></param>
        /// <param name="p_al_data"></param>
        /// <returns></returns>
        private bool my_Load_Backup_File(string p_File_Path, ref ArrayList p_al_data)
        {
            bool b_ret = false;
            try
            {
                // �t�@�C���̗L�����`�F�b�N
                if (File.Exists(p_File_Path) == true)
                {
                    try
                    {
                        byte[] bs = System.IO.File.ReadAllBytes(p_File_Path);
                        
                        // �T�C�Y�`�F�b�N
                        if (bs.Length == Constants.FM_TOTAL_SIZE)
                        {
                            p_al_data.Clear();

                            p_al_data.AddRange(bs);
                        }
                        else
                        {
                            // �T�C�Y�G���[
                            b_ret = true;
                        }
                    }
                    catch
                    {   // ��O����
                        b_ret = true;
                    }
                }
                else
                {   //�t�@�C���Ȃ�
                    b_ret = true;
                }

            }
            catch
            {
            }
            return b_ret;
        }

        /// <summary>
        /// Backup �t�@�C���̕ۑ�
        /// </summary>
        /// <param name="p_File_Path"></param>
        /// <param name="p_al_data"></param>
        /// <returns></returns>
        private bool my_Save_Backup_File(string p_File_Path, ArrayList p_al_data)
        {
            bool b_ret = false;
            byte[] byte_buff = new byte[1024];
            int pos = 0;
            int out_size = 0;
            try
            {
                FileStream fs = null;
                try
                {
                    fs = new FileStream(p_File_Path, FileMode.Create, FileAccess.Write);
                    while (pos < p_al_data.Count)
                    {
                        out_size = 0;
                        //�o�C�g�z��ɃR�s�[
                        for (int fi = 0; fi < byte_buff.Length && pos < p_al_data.Count; fi++)
                        {
                            byte_buff[fi] = (byte)p_al_data[pos];
                            out_size++;
                            pos++;
                        }
                        fs.Write(byte_buff, 0, out_size);
                    }
                }
                catch
                {
                    b_ret = true;
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                        fs.Dispose();
                    }
                }
            }
            catch
            {
            }
            return b_ret;
        }

        /// <summary>
        /// �\���R���g���[���̗L��/�����ݒ�
        /// </summary>
        /// <param name="flag"></param>
        private void my_Display_Enabled(bool flag, bool start_btn_flag, bool stop_btn_flag)
        {

            gbx_Setting.Enabled = flag;
            gbx_Setting_list.Enabled = flag;

            btn_ir_read_start.Enabled = start_btn_flag;
            btn_ir_read_stop.Enabled = stop_btn_flag;

            btn_backup_export.Enabled = flag;
            btn_backup_import.Enabled = flag;
            btn_setup_reset.Enabled = flag;
        }

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


    } //public partial class Form1 : Form


    static class Constants
    {
        public const string APPLICATION_NAME = "USB IR Remote Controller Advance Configuration Tool";

        public const int IR_DATA_BUFF_SIZE = 4800; // 4800 = 2400bit * 2(ON/OFF) PIC32MX230F064B
        //public const int IR_DATA_BUFF_SIZE = 12800; // 12800 = 6400bit * 2(ON/OFF) PIC32MX250F128B
        public const int IR_DATA_REC_NUM = 32;
        public const string IR_DATA_MEMO_DEFAULT = "���̂�t���ĉ�����";
        public const string IR_DATA_CLEAR_MSG = "No.{0}�̐ݒ���������܂��B��낵���ł����H";

        public const uint FM_TOTAL_SIZE = 0x200000;		// FLASH MEMORY ���T�C�Y
        public const uint FM_SECTOR_NUM = 0x20;   		// FLASH MEMORY �Z�N�^�[��
        public const uint FM_SECTOR_SIZE = 0x10000;        // FLASH MEMORY �Z�N�^�[�T�C�Y
        public const uint FM_USB_READ_DATA_SIZE = 62;             // USB���[�h�T�C�Y�i1��̒ʐM�ł́j
        public const uint FM_USB_WRITE_DATA_SIZE = 58;             // USB���C�g�T�C�Y�i1��̒ʐM�ł́j

        public const int BACKUP_FLAG_NON = 0x0000;
        public const int BACKUP_FLAG_BACKUP = 0x0001;
        public const int BACKUP_FLAG_RESTORE = 0x0002;
        public const int BACKUP_FLAG_RESET = 0x0003;
        public const string BACKUP_FILE_SAVE_DIALOG_TITLE = "�o�b�N�A�b�v�t�@�C����ۑ����܂�";
        public const string BACKUP_FILE_OPEN_DIALOG_TITLE = "�o�b�N�A�b�v�t�@�C����I�����ĉ�����";
        public const string BACKUP_FILE_EXTENSION = ".txt";
        public const string BACKUP_FILE_FILTER = "�o�b�N�A�b�v�t�@�C��(*.txt)|*.txt|���ׂẴt�@�C��(*.*)|*.*";
        public const string RESTORE_WARNING_MSG = "�ݒ肪���ׂď㏑������A���������܂��B��낵���ł����H";
        public const string FLASHERASE_WARNING_MSG = "�ݒ�����ׂď������܂��B��낵���ł����H";
        public const string RESET_WARNING_MSG = "�ݒ�����ׂď��������܂��B��낵���ł����H";

        public const string RESTORE_ERROR_MSG1 = "�G���[�������������𒆒f���܂����B\n(ERROR CODE={0})";
        public const string RESTORE_COMP_WARNING_MSG1 = "�ݒ�̓ǂݍ��݂��������܂����B\nUSB�P�[�u�������O���A��ʍ����Ɂh�ڑ�����Ă��܂���h�ƕ\�����ꂽ��AUSB�P�[�u����}�������Ă��������B";
    }


    [Serializable()]
    public class IrData
    {
        [System.Xml.Serialization.XmlElement("MEMO")]
        public string[] memo;           // ����
        [System.Xml.Serialization.XmlElement("IR_FREQ")]
        public int[] ir_freq;           // ���g��
        [System.Xml.Serialization.XmlElement("IR_DATA_SIZE")]
        public int[] ir_data_size;      // �f�[�^�T�C�Y
        [System.Xml.Serialization.XmlElement("IR_DATA")]
        public uint[,] ir_data_rec_buff;        // �f�[�^

        public IrData()
        {
        }
        public IrData(int p_rec_num, int p_ir_data_buff_size)
        {
            int fi, fj;
            try
            {
                memo = new string[p_rec_num];
                ir_freq = new int[p_rec_num];
                ir_data_size = new int[p_rec_num];
                ir_data_rec_buff = new uint[p_rec_num, p_ir_data_buff_size];

                for (fi = 0; fi < p_rec_num; fi++)
                {
                    memo[fi] = "";
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                    for (fj = 0; fj < p_ir_data_buff_size; fj++)
                    {
                        ir_data_rec_buff[fi,fj] = 0;
                    }
                }
            }
            catch
            {
            }
        }

        public int Init()
        {
            int ret = 0;
            int fi, fj;
            try
            {
                for (fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
                {
                    memo[fi] = "";
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                    for (fj = 0; fj < Constants.IR_DATA_BUFF_SIZE; fj++)
                    {
                        ir_data_rec_buff[fi, fj] = 0;
                    }
                }
            }
            catch
            {
            }
            return ret;
        }
        public int Dispose()
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_set(int p_idx, string p_memo, int p_ir_freq, int p_ir_data_size, uint[] p_ir_data)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    memo[p_idx] = p_memo;
                    ir_freq[p_idx] = p_ir_freq;
                    ir_data_size[p_idx] = p_ir_data_size;
                    for (int fj = 0; fj < (p_ir_data_size * 2); fj++)
                    {
                        ir_data_rec_buff[p_idx, fj] = p_ir_data[fj];
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_get(int p_idx, string p_memo, ref int p_ir_freq, ref int p_ir_data_size, ref uint[] p_ir_data, int p_ir_data_buff_size)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    for (int fi = 0; fi < p_ir_data_buff_size; fi++)
                    {
                        p_ir_data[fi] = 0;
                    }

                    p_memo = memo[p_idx];
                    p_ir_freq = ir_freq[p_idx];
                    p_ir_data_size = ir_data_size[p_idx];
                    for (int fj = 0; fj < (p_ir_data_size * 2); fj++)
                    {
                        p_ir_data[fj] = ir_data_rec_buff[p_idx, fj];
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_clear(int p_idx)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    memo[p_idx] = "";
                    ir_freq[p_idx] = 0;
                    ir_data_size[p_idx] = 0;
                    for (int fj = 0; fj < Constants.IR_DATA_BUFF_SIZE; fj++)
                    {
                        ir_data_rec_buff[p_idx, fj] = 0;
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_all_clear()
        {
            int ret = 0;
            try
            {
                Init();
            }
            catch
            {
            }
            return ret;
        }
    }

} //namespace HID_PnP_Demo