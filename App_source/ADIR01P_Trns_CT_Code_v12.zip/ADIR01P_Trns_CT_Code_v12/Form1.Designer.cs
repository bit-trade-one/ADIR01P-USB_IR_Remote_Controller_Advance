namespace IR_Remote_Control_Pro
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.connect_status_lbl = new System.Windows.Forms.Label();
            this.debug01_lbl = new System.Windows.Forms.Label();
            this.debug02_lbl = new System.Windows.Forms.Label();
            this.debug03_lbl = new System.Windows.Forms.Label();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_FW_Version = new System.Windows.Forms.Label();
            this.lbl_ir_read_size = new System.Windows.Forms.Label();
            this.lbl_ir_read_result = new System.Windows.Forms.Label();
            this.btn_ir_data_file_read = new System.Windows.Forms.Button();
            this.btn_ir_data_file_save = new System.Windows.Forms.Button();
            this.btn_clip_copy = new System.Windows.Forms.Button();
            this.rtxtbx_ir_read_data = new System.Windows.Forms.RichTextBox();
            this.btn_ir_read_stop = new System.Windows.Forms.Button();
            this.btn_ir_read_start = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.gbx_Setting = new System.Windows.Forms.GroupBox();
            this.btn_setting_clr = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Setting_Set = new System.Windows.Forms.Button();
            this.txtbx_memo = new System.Windows.Forms.TextBox();
            this.lbl_SelectNo = new System.Windows.Forms.Label();
            this.gbx_Setting_list = new System.Windows.Forms.GroupBox();
            this.txtbx_memo_No32 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No16 = new System.Windows.Forms.TextBox();
            this.btn_send_No32 = new System.Windows.Forms.Button();
            this.btn_send_No16 = new System.Windows.Forms.Button();
            this.btn_select_No32 = new System.Windows.Forms.Button();
            this.btn_select_No16 = new System.Windows.Forms.Button();
            this.txtbx_memo_No31 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No15 = new System.Windows.Forms.TextBox();
            this.btn_send_No31 = new System.Windows.Forms.Button();
            this.btn_send_No15 = new System.Windows.Forms.Button();
            this.txtbx_memo_No30 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No14 = new System.Windows.Forms.TextBox();
            this.btn_select_No31 = new System.Windows.Forms.Button();
            this.btn_select_No15 = new System.Windows.Forms.Button();
            this.btn_send_No30 = new System.Windows.Forms.Button();
            this.btn_send_No14 = new System.Windows.Forms.Button();
            this.btn_select_No30 = new System.Windows.Forms.Button();
            this.btn_select_No14 = new System.Windows.Forms.Button();
            this.txtbx_memo_No29 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No13 = new System.Windows.Forms.TextBox();
            this.btn_send_No29 = new System.Windows.Forms.Button();
            this.btn_send_No13 = new System.Windows.Forms.Button();
            this.btn_select_No29 = new System.Windows.Forms.Button();
            this.btn_select_No13 = new System.Windows.Forms.Button();
            this.txtbx_memo_No28 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No12 = new System.Windows.Forms.TextBox();
            this.btn_send_No28 = new System.Windows.Forms.Button();
            this.btn_send_No12 = new System.Windows.Forms.Button();
            this.btn_select_No28 = new System.Windows.Forms.Button();
            this.btn_select_No12 = new System.Windows.Forms.Button();
            this.txtbx_memo_No27 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No11 = new System.Windows.Forms.TextBox();
            this.btn_send_No27 = new System.Windows.Forms.Button();
            this.btn_send_No11 = new System.Windows.Forms.Button();
            this.btn_select_No27 = new System.Windows.Forms.Button();
            this.btn_select_No11 = new System.Windows.Forms.Button();
            this.txtbx_memo_No26 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No10 = new System.Windows.Forms.TextBox();
            this.btn_send_No26 = new System.Windows.Forms.Button();
            this.btn_send_No10 = new System.Windows.Forms.Button();
            this.btn_select_No26 = new System.Windows.Forms.Button();
            this.btn_select_No10 = new System.Windows.Forms.Button();
            this.txtbx_memo_No25 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No09 = new System.Windows.Forms.TextBox();
            this.btn_send_No25 = new System.Windows.Forms.Button();
            this.btn_send_No09 = new System.Windows.Forms.Button();
            this.btn_select_No25 = new System.Windows.Forms.Button();
            this.btn_select_No09 = new System.Windows.Forms.Button();
            this.txtbx_memo_No24 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No08 = new System.Windows.Forms.TextBox();
            this.btn_send_No24 = new System.Windows.Forms.Button();
            this.btn_send_No08 = new System.Windows.Forms.Button();
            this.btn_select_No24 = new System.Windows.Forms.Button();
            this.btn_select_No08 = new System.Windows.Forms.Button();
            this.txtbx_memo_No23 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No07 = new System.Windows.Forms.TextBox();
            this.btn_send_No23 = new System.Windows.Forms.Button();
            this.btn_send_No07 = new System.Windows.Forms.Button();
            this.btn_select_No23 = new System.Windows.Forms.Button();
            this.btn_select_No07 = new System.Windows.Forms.Button();
            this.txtbx_memo_No22 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No06 = new System.Windows.Forms.TextBox();
            this.btn_send_No22 = new System.Windows.Forms.Button();
            this.btn_send_No06 = new System.Windows.Forms.Button();
            this.btn_select_No22 = new System.Windows.Forms.Button();
            this.btn_select_No06 = new System.Windows.Forms.Button();
            this.txtbx_memo_No21 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No05 = new System.Windows.Forms.TextBox();
            this.btn_send_No21 = new System.Windows.Forms.Button();
            this.btn_send_No05 = new System.Windows.Forms.Button();
            this.btn_select_No21 = new System.Windows.Forms.Button();
            this.btn_select_No05 = new System.Windows.Forms.Button();
            this.txtbx_memo_No20 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No04 = new System.Windows.Forms.TextBox();
            this.btn_send_No20 = new System.Windows.Forms.Button();
            this.btn_send_No04 = new System.Windows.Forms.Button();
            this.btn_select_No20 = new System.Windows.Forms.Button();
            this.btn_select_No04 = new System.Windows.Forms.Button();
            this.txtbx_memo_No19 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No03 = new System.Windows.Forms.TextBox();
            this.btn_send_No19 = new System.Windows.Forms.Button();
            this.btn_send_No03 = new System.Windows.Forms.Button();
            this.btn_select_No19 = new System.Windows.Forms.Button();
            this.btn_select_No03 = new System.Windows.Forms.Button();
            this.txtbx_memo_No18 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No02 = new System.Windows.Forms.TextBox();
            this.btn_send_No18 = new System.Windows.Forms.Button();
            this.btn_send_No02 = new System.Windows.Forms.Button();
            this.btn_select_No18 = new System.Windows.Forms.Button();
            this.btn_select_No02 = new System.Windows.Forms.Button();
            this.txtbx_memo_No17 = new System.Windows.Forms.TextBox();
            this.txtbx_memo_No01 = new System.Windows.Forms.TextBox();
            this.btn_send_No17 = new System.Windows.Forms.Button();
            this.btn_send_No01 = new System.Windows.Forms.Button();
            this.btn_select_No17 = new System.Windows.Forms.Button();
            this.btn_select_No01 = new System.Windows.Forms.Button();
            this.btn_timer_set_display = new System.Windows.Forms.Button();
            this.gbx_timer_setting = new System.Windows.Forms.GroupBox();
            this.btn_timer_list_import = new System.Windows.Forms.Button();
            this.dgv_timer_set_list = new System.Windows.Forms.DataGridView();
            this.chkbx_select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Send_data_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_timer_list_export = new System.Windows.Forms.Button();
            this.lbl_timer_now_time = new System.Windows.Forms.Label();
            this.btn_timer_item_del = new System.Windows.Forms.Button();
            this.gbx_timer_item_add = new System.Windows.Forms.GroupBox();
            this.lbl_timer_set_no = new System.Windows.Forms.Label();
            this.lbl_timer_set_time = new System.Windows.Forms.Label();
            this.cmbbx_timer_set_no = new System.Windows.Forms.ComboBox();
            this.dtp_timer_set_time = new System.Windows.Forms.DateTimePicker();
            this.btn_timer_item_add = new System.Windows.Forms.Button();
            this.btn_timer_on_off = new System.Windows.Forms.Button();
            this.imglist_timer_onoff = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1.SuspendLayout();
            this.gbx_Setting.SuspendLayout();
            this.gbx_Setting_list.SuspendLayout();
            this.gbx_timer_setting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_timer_set_list)).BeginInit();
            this.gbx_timer_item_add.SuspendLayout();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 50;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // connect_status_lbl
            // 
            this.connect_status_lbl.AutoSize = true;
            this.connect_status_lbl.BackColor = System.Drawing.Color.Transparent;
            this.connect_status_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(27)))), ((int)(((byte)(26)))));
            this.connect_status_lbl.Location = new System.Drawing.Point(20, 622);
            this.connect_status_lbl.Name = "connect_status_lbl";
            this.connect_status_lbl.Size = new System.Drawing.Size(41, 12);
            this.connect_status_lbl.TabIndex = 501;
            this.connect_status_lbl.Text = "���ڑ�";
            // 
            // debug01_lbl
            // 
            this.debug01_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug01_lbl.Location = new System.Drawing.Point(6, 48);
            this.debug01_lbl.Name = "debug01_lbl";
            this.debug01_lbl.Size = new System.Drawing.Size(880, 24);
            this.debug01_lbl.TabIndex = 902;
            this.debug01_lbl.Text = "label1";
            // 
            // debug02_lbl
            // 
            this.debug02_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug02_lbl.Location = new System.Drawing.Point(6, 81);
            this.debug02_lbl.Name = "debug02_lbl";
            this.debug02_lbl.Size = new System.Drawing.Size(880, 24);
            this.debug02_lbl.TabIndex = 903;
            this.debug02_lbl.Text = "label1";
            // 
            // debug03_lbl
            // 
            this.debug03_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.debug03_lbl.Location = new System.Drawing.Point(6, 114);
            this.debug03_lbl.Name = "debug03_lbl";
            this.debug03_lbl.Size = new System.Drawing.Size(880, 24);
            this.debug03_lbl.TabIndex = 904;
            this.debug03_lbl.Text = "label1";
            // 
            // colum_lbl
            // 
            this.colum_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.colum_lbl.Location = new System.Drawing.Point(6, 15);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(880, 24);
            this.colum_lbl.TabIndex = 901;
            this.colum_lbl.Text = "label1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Controls.Add(this.debug01_lbl);
            this.groupBox1.Controls.Add(this.debug02_lbl);
            this.groupBox1.Controls.Add(this.debug03_lbl);
            this.groupBox1.Location = new System.Drawing.Point(12, 706);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(890, 146);
            this.groupBox1.TabIndex = 900;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // lbl_FW_Version
            // 
            this.lbl_FW_Version.BackColor = System.Drawing.Color.Transparent;
            this.lbl_FW_Version.Location = new System.Drawing.Point(750, 622);
            this.lbl_FW_Version.Name = "lbl_FW_Version";
            this.lbl_FW_Version.Size = new System.Drawing.Size(400, 12);
            this.lbl_FW_Version.TabIndex = 502;
            this.lbl_FW_Version.Text = "FW Version";
            this.lbl_FW_Version.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lbl_ir_read_size
            // 
            this.lbl_ir_read_size.Location = new System.Drawing.Point(265, 23);
            this.lbl_ir_read_size.Name = "lbl_ir_read_size";
            this.lbl_ir_read_size.Size = new System.Drawing.Size(315, 18);
            this.lbl_ir_read_size.TabIndex = 508;
            this.lbl_ir_read_size.Text = "�ǂݍ��݃T�C�Y";
            // 
            // lbl_ir_read_result
            // 
            this.lbl_ir_read_result.Location = new System.Drawing.Point(161, 23);
            this.lbl_ir_read_result.Name = "lbl_ir_read_result";
            this.lbl_ir_read_result.Size = new System.Drawing.Size(83, 18);
            this.lbl_ir_read_result.TabIndex = 507;
            this.lbl_ir_read_result.Text = "�ǂݍ��݌���";
            // 
            // btn_ir_data_file_read
            // 
            this.btn_ir_data_file_read.Location = new System.Drawing.Point(670, 425);
            this.btn_ir_data_file_read.Name = "btn_ir_data_file_read";
            this.btn_ir_data_file_read.Size = new System.Drawing.Size(100, 23);
            this.btn_ir_data_file_read.TabIndex = 392;
            this.btn_ir_data_file_read.Text = "�C���|�[�g";
            this.btn_ir_data_file_read.UseVisualStyleBackColor = true;
            this.btn_ir_data_file_read.Click += new System.EventHandler(this.btn_ir_data_file_read_Click);
            // 
            // btn_ir_data_file_save
            // 
            this.btn_ir_data_file_save.Location = new System.Drawing.Point(565, 425);
            this.btn_ir_data_file_save.Name = "btn_ir_data_file_save";
            this.btn_ir_data_file_save.Size = new System.Drawing.Size(100, 23);
            this.btn_ir_data_file_save.TabIndex = 391;
            this.btn_ir_data_file_save.Text = "�G�N�X�|�[�g";
            this.btn_ir_data_file_save.UseVisualStyleBackColor = true;
            this.btn_ir_data_file_save.Click += new System.EventHandler(this.btn_ir_data_file_save_Click);
            // 
            // btn_clip_copy
            // 
            this.btn_clip_copy.Location = new System.Drawing.Point(586, 73);
            this.btn_clip_copy.Name = "btn_clip_copy";
            this.btn_clip_copy.Size = new System.Drawing.Size(120, 41);
            this.btn_clip_copy.TabIndex = 92;
            this.btn_clip_copy.Text = "�N���b�v�{�[�h�ɃR�s�[";
            this.btn_clip_copy.UseVisualStyleBackColor = true;
            this.btn_clip_copy.Click += new System.EventHandler(this.btn_clip_copy_Click);
            // 
            // rtxtbx_ir_read_data
            // 
            this.rtxtbx_ir_read_data.Font = new System.Drawing.Font("�l�r �S�V�b�N", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.rtxtbx_ir_read_data.Location = new System.Drawing.Point(10, 68);
            this.rtxtbx_ir_read_data.Name = "rtxtbx_ir_read_data";
            this.rtxtbx_ir_read_data.Size = new System.Drawing.Size(570, 56);
            this.rtxtbx_ir_read_data.TabIndex = 91;
            this.rtxtbx_ir_read_data.Text = "";
            // 
            // btn_ir_read_stop
            // 
            this.btn_ir_read_stop.Enabled = false;
            this.btn_ir_read_stop.Location = new System.Drawing.Point(85, 41);
            this.btn_ir_read_stop.Name = "btn_ir_read_stop";
            this.btn_ir_read_stop.Size = new System.Drawing.Size(70, 23);
            this.btn_ir_read_stop.TabIndex = 13;
            this.btn_ir_read_stop.Text = "�L�^��~";
            this.btn_ir_read_stop.UseVisualStyleBackColor = true;
            this.btn_ir_read_stop.Click += new System.EventHandler(this.btn_ir_read_stop_Click);
            // 
            // btn_ir_read_start
            // 
            this.btn_ir_read_start.Location = new System.Drawing.Point(85, 18);
            this.btn_ir_read_start.Name = "btn_ir_read_start";
            this.btn_ir_read_start.Size = new System.Drawing.Size(70, 23);
            this.btn_ir_read_start.TabIndex = 12;
            this.btn_ir_read_start.Text = "�L�^�J�n";
            this.btn_ir_read_start.UseVisualStyleBackColor = true;
            this.btn_ir_read_start.Click += new System.EventHandler(this.btn_ir_read_start_Click);
            // 
            // gbx_Setting
            // 
            this.gbx_Setting.BackColor = System.Drawing.Color.Transparent;
            this.gbx_Setting.Controls.Add(this.btn_setting_clr);
            this.gbx_Setting.Controls.Add(this.label2);
            this.gbx_Setting.Controls.Add(this.btn_Setting_Set);
            this.gbx_Setting.Controls.Add(this.txtbx_memo);
            this.gbx_Setting.Controls.Add(this.btn_clip_copy);
            this.gbx_Setting.Controls.Add(this.lbl_SelectNo);
            this.gbx_Setting.Controls.Add(this.rtxtbx_ir_read_data);
            this.gbx_Setting.Controls.Add(this.btn_ir_read_start);
            this.gbx_Setting.Controls.Add(this.lbl_ir_read_size);
            this.gbx_Setting.Controls.Add(this.lbl_ir_read_result);
            this.gbx_Setting.Controls.Add(this.btn_ir_read_stop);
            this.gbx_Setting.Location = new System.Drawing.Point(12, 12);
            this.gbx_Setting.Name = "gbx_Setting";
            this.gbx_Setting.Size = new System.Drawing.Size(717, 130);
            this.gbx_Setting.TabIndex = 10;
            this.gbx_Setting.TabStop = false;
            this.gbx_Setting.Text = "�ݒ�";
            // 
            // btn_setting_clr
            // 
            this.btn_setting_clr.Location = new System.Drawing.Point(10, 41);
            this.btn_setting_clr.Name = "btn_setting_clr";
            this.btn_setting_clr.Size = new System.Drawing.Size(70, 23);
            this.btn_setting_clr.TabIndex = 901;
            this.btn_setting_clr.Text = "�ݒ����";
            this.btn_setting_clr.UseVisualStyleBackColor = true;
            this.btn_setting_clr.Click += new System.EventHandler(this.btn_setting_clr_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "����";
            // 
            // btn_Setting_Set
            // 
            this.btn_Setting_Set.Location = new System.Drawing.Point(586, 22);
            this.btn_Setting_Set.Name = "btn_Setting_Set";
            this.btn_Setting_Set.Size = new System.Drawing.Size(120, 42);
            this.btn_Setting_Set.TabIndex = 16;
            this.btn_Setting_Set.Text = "�ۑ�";
            this.btn_Setting_Set.UseVisualStyleBackColor = true;
            this.btn_Setting_Set.Click += new System.EventHandler(this.btn_Setting_Set_Click);
            // 
            // txtbx_memo
            // 
            this.txtbx_memo.Location = new System.Drawing.Point(195, 45);
            this.txtbx_memo.Name = "txtbx_memo";
            this.txtbx_memo.Size = new System.Drawing.Size(385, 19);
            this.txtbx_memo.TabIndex = 15;
            this.txtbx_memo.Enter += new System.EventHandler(this.txtbx_memo_Enter);
            // 
            // lbl_SelectNo
            // 
            this.lbl_SelectNo.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_SelectNo.Location = new System.Drawing.Point(19, 20);
            this.lbl_SelectNo.Name = "lbl_SelectNo";
            this.lbl_SelectNo.Size = new System.Drawing.Size(60, 23);
            this.lbl_SelectNo.TabIndex = 11;
            this.lbl_SelectNo.Text = "No.00";
            // 
            // gbx_Setting_list
            // 
            this.gbx_Setting_list.BackColor = System.Drawing.Color.Transparent;
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No32);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No16);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No32);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No16);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No32);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No16);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No31);
            this.gbx_Setting_list.Controls.Add(this.btn_ir_data_file_read);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No15);
            this.gbx_Setting_list.Controls.Add(this.btn_ir_data_file_save);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No31);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No15);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No30);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No14);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No31);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No15);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No30);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No14);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No30);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No14);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No29);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No13);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No29);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No13);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No29);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No13);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No28);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No12);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No28);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No12);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No28);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No12);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No27);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No11);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No27);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No11);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No27);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No11);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No26);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No10);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No26);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No10);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No26);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No10);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No25);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No09);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No25);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No09);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No25);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No09);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No24);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No08);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No24);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No08);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No24);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No08);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No23);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No07);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No23);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No07);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No23);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No07);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No22);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No06);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No22);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No06);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No22);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No06);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No21);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No05);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No21);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No05);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No21);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No05);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No20);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No04);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No20);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No04);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No20);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No04);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No19);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No03);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No19);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No03);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No19);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No03);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No18);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No02);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No18);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No02);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No18);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No02);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No17);
            this.gbx_Setting_list.Controls.Add(this.txtbx_memo_No01);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No17);
            this.gbx_Setting_list.Controls.Add(this.btn_send_No01);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No17);
            this.gbx_Setting_list.Controls.Add(this.btn_select_No01);
            this.gbx_Setting_list.Location = new System.Drawing.Point(12, 150);
            this.gbx_Setting_list.Name = "gbx_Setting_list";
            this.gbx_Setting_list.Size = new System.Drawing.Size(780, 455);
            this.gbx_Setting_list.TabIndex = 200;
            this.gbx_Setting_list.TabStop = false;
            this.gbx_Setting_list.Text = "�ꗗ";
            // 
            // txtbx_memo_No32
            // 
            this.txtbx_memo_No32.Location = new System.Drawing.Point(520, 395);
            this.txtbx_memo_No32.Name = "txtbx_memo_No32";
            this.txtbx_memo_No32.ReadOnly = true;
            this.txtbx_memo_No32.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No32.TabIndex = 358;
            // 
            // txtbx_memo_No16
            // 
            this.txtbx_memo_No16.Location = new System.Drawing.Point(119, 395);
            this.txtbx_memo_No16.Name = "txtbx_memo_No16";
            this.txtbx_memo_No16.ReadOnly = true;
            this.txtbx_memo_No16.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No16.TabIndex = 278;
            // 
            // btn_send_No32
            // 
            this.btn_send_No32.Location = new System.Drawing.Point(464, 393);
            this.btn_send_No32.Name = "btn_send_No32";
            this.btn_send_No32.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No32.TabIndex = 357;
            this.btn_send_No32.Text = "���M";
            this.btn_send_No32.UseVisualStyleBackColor = true;
            this.btn_send_No32.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No16
            // 
            this.btn_send_No16.Location = new System.Drawing.Point(63, 393);
            this.btn_send_No16.Name = "btn_send_No16";
            this.btn_send_No16.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No16.TabIndex = 277;
            this.btn_send_No16.Text = "���M";
            this.btn_send_No16.UseVisualStyleBackColor = true;
            this.btn_send_No16.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No32
            // 
            this.btn_select_No32.Location = new System.Drawing.Point(411, 393);
            this.btn_select_No32.Name = "btn_select_No32";
            this.btn_select_No32.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No32.TabIndex = 356;
            this.btn_select_No32.Text = "No.01";
            this.btn_select_No32.UseVisualStyleBackColor = true;
            this.btn_select_No32.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No16
            // 
            this.btn_select_No16.Location = new System.Drawing.Point(10, 393);
            this.btn_select_No16.Name = "btn_select_No16";
            this.btn_select_No16.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No16.TabIndex = 276;
            this.btn_select_No16.Text = "No.01";
            this.btn_select_No16.UseVisualStyleBackColor = true;
            this.btn_select_No16.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No31
            // 
            this.txtbx_memo_No31.Location = new System.Drawing.Point(520, 370);
            this.txtbx_memo_No31.Name = "txtbx_memo_No31";
            this.txtbx_memo_No31.ReadOnly = true;
            this.txtbx_memo_No31.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No31.TabIndex = 353;
            // 
            // txtbx_memo_No15
            // 
            this.txtbx_memo_No15.Location = new System.Drawing.Point(119, 370);
            this.txtbx_memo_No15.Name = "txtbx_memo_No15";
            this.txtbx_memo_No15.ReadOnly = true;
            this.txtbx_memo_No15.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No15.TabIndex = 273;
            // 
            // btn_send_No31
            // 
            this.btn_send_No31.Location = new System.Drawing.Point(464, 368);
            this.btn_send_No31.Name = "btn_send_No31";
            this.btn_send_No31.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No31.TabIndex = 352;
            this.btn_send_No31.Text = "���M";
            this.btn_send_No31.UseVisualStyleBackColor = true;
            this.btn_send_No31.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No15
            // 
            this.btn_send_No15.Location = new System.Drawing.Point(63, 368);
            this.btn_send_No15.Name = "btn_send_No15";
            this.btn_send_No15.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No15.TabIndex = 272;
            this.btn_send_No15.Text = "���M";
            this.btn_send_No15.UseVisualStyleBackColor = true;
            this.btn_send_No15.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // txtbx_memo_No30
            // 
            this.txtbx_memo_No30.Location = new System.Drawing.Point(520, 345);
            this.txtbx_memo_No30.Name = "txtbx_memo_No30";
            this.txtbx_memo_No30.ReadOnly = true;
            this.txtbx_memo_No30.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No30.TabIndex = 348;
            // 
            // txtbx_memo_No14
            // 
            this.txtbx_memo_No14.Location = new System.Drawing.Point(119, 345);
            this.txtbx_memo_No14.Name = "txtbx_memo_No14";
            this.txtbx_memo_No14.ReadOnly = true;
            this.txtbx_memo_No14.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No14.TabIndex = 268;
            // 
            // btn_select_No31
            // 
            this.btn_select_No31.Location = new System.Drawing.Point(411, 368);
            this.btn_select_No31.Name = "btn_select_No31";
            this.btn_select_No31.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No31.TabIndex = 351;
            this.btn_select_No31.Text = "No.01";
            this.btn_select_No31.UseVisualStyleBackColor = true;
            this.btn_select_No31.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No15
            // 
            this.btn_select_No15.Location = new System.Drawing.Point(10, 368);
            this.btn_select_No15.Name = "btn_select_No15";
            this.btn_select_No15.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No15.TabIndex = 271;
            this.btn_select_No15.Text = "No.01";
            this.btn_select_No15.UseVisualStyleBackColor = true;
            this.btn_select_No15.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_send_No30
            // 
            this.btn_send_No30.Location = new System.Drawing.Point(464, 343);
            this.btn_send_No30.Name = "btn_send_No30";
            this.btn_send_No30.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No30.TabIndex = 347;
            this.btn_send_No30.Text = "���M";
            this.btn_send_No30.UseVisualStyleBackColor = true;
            this.btn_send_No30.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No14
            // 
            this.btn_send_No14.Location = new System.Drawing.Point(63, 343);
            this.btn_send_No14.Name = "btn_send_No14";
            this.btn_send_No14.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No14.TabIndex = 267;
            this.btn_send_No14.Text = "���M";
            this.btn_send_No14.UseVisualStyleBackColor = true;
            this.btn_send_No14.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No30
            // 
            this.btn_select_No30.Location = new System.Drawing.Point(411, 343);
            this.btn_select_No30.Name = "btn_select_No30";
            this.btn_select_No30.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No30.TabIndex = 346;
            this.btn_select_No30.Text = "No.01";
            this.btn_select_No30.UseVisualStyleBackColor = true;
            this.btn_select_No30.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No14
            // 
            this.btn_select_No14.Location = new System.Drawing.Point(10, 343);
            this.btn_select_No14.Name = "btn_select_No14";
            this.btn_select_No14.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No14.TabIndex = 266;
            this.btn_select_No14.Text = "No.01";
            this.btn_select_No14.UseVisualStyleBackColor = true;
            this.btn_select_No14.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No29
            // 
            this.txtbx_memo_No29.Location = new System.Drawing.Point(520, 320);
            this.txtbx_memo_No29.Name = "txtbx_memo_No29";
            this.txtbx_memo_No29.ReadOnly = true;
            this.txtbx_memo_No29.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No29.TabIndex = 343;
            // 
            // txtbx_memo_No13
            // 
            this.txtbx_memo_No13.Location = new System.Drawing.Point(119, 320);
            this.txtbx_memo_No13.Name = "txtbx_memo_No13";
            this.txtbx_memo_No13.ReadOnly = true;
            this.txtbx_memo_No13.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No13.TabIndex = 263;
            // 
            // btn_send_No29
            // 
            this.btn_send_No29.Location = new System.Drawing.Point(464, 318);
            this.btn_send_No29.Name = "btn_send_No29";
            this.btn_send_No29.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No29.TabIndex = 342;
            this.btn_send_No29.Text = "���M";
            this.btn_send_No29.UseVisualStyleBackColor = true;
            this.btn_send_No29.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No13
            // 
            this.btn_send_No13.Location = new System.Drawing.Point(63, 318);
            this.btn_send_No13.Name = "btn_send_No13";
            this.btn_send_No13.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No13.TabIndex = 262;
            this.btn_send_No13.Text = "���M";
            this.btn_send_No13.UseVisualStyleBackColor = true;
            this.btn_send_No13.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No29
            // 
            this.btn_select_No29.Location = new System.Drawing.Point(411, 318);
            this.btn_select_No29.Name = "btn_select_No29";
            this.btn_select_No29.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No29.TabIndex = 341;
            this.btn_select_No29.Text = "No.01";
            this.btn_select_No29.UseVisualStyleBackColor = true;
            this.btn_select_No29.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No13
            // 
            this.btn_select_No13.Location = new System.Drawing.Point(10, 318);
            this.btn_select_No13.Name = "btn_select_No13";
            this.btn_select_No13.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No13.TabIndex = 261;
            this.btn_select_No13.Text = "No.01";
            this.btn_select_No13.UseVisualStyleBackColor = true;
            this.btn_select_No13.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No28
            // 
            this.txtbx_memo_No28.Location = new System.Drawing.Point(520, 295);
            this.txtbx_memo_No28.Name = "txtbx_memo_No28";
            this.txtbx_memo_No28.ReadOnly = true;
            this.txtbx_memo_No28.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No28.TabIndex = 338;
            // 
            // txtbx_memo_No12
            // 
            this.txtbx_memo_No12.Location = new System.Drawing.Point(119, 295);
            this.txtbx_memo_No12.Name = "txtbx_memo_No12";
            this.txtbx_memo_No12.ReadOnly = true;
            this.txtbx_memo_No12.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No12.TabIndex = 258;
            // 
            // btn_send_No28
            // 
            this.btn_send_No28.Location = new System.Drawing.Point(464, 293);
            this.btn_send_No28.Name = "btn_send_No28";
            this.btn_send_No28.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No28.TabIndex = 337;
            this.btn_send_No28.Text = "���M";
            this.btn_send_No28.UseVisualStyleBackColor = true;
            this.btn_send_No28.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No12
            // 
            this.btn_send_No12.Location = new System.Drawing.Point(63, 293);
            this.btn_send_No12.Name = "btn_send_No12";
            this.btn_send_No12.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No12.TabIndex = 257;
            this.btn_send_No12.Text = "���M";
            this.btn_send_No12.UseVisualStyleBackColor = true;
            this.btn_send_No12.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No28
            // 
            this.btn_select_No28.Location = new System.Drawing.Point(411, 293);
            this.btn_select_No28.Name = "btn_select_No28";
            this.btn_select_No28.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No28.TabIndex = 336;
            this.btn_select_No28.Text = "No.01";
            this.btn_select_No28.UseVisualStyleBackColor = true;
            this.btn_select_No28.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No12
            // 
            this.btn_select_No12.Location = new System.Drawing.Point(10, 293);
            this.btn_select_No12.Name = "btn_select_No12";
            this.btn_select_No12.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No12.TabIndex = 256;
            this.btn_select_No12.Text = "No.01";
            this.btn_select_No12.UseVisualStyleBackColor = true;
            this.btn_select_No12.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No27
            // 
            this.txtbx_memo_No27.Location = new System.Drawing.Point(520, 270);
            this.txtbx_memo_No27.Name = "txtbx_memo_No27";
            this.txtbx_memo_No27.ReadOnly = true;
            this.txtbx_memo_No27.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No27.TabIndex = 333;
            // 
            // txtbx_memo_No11
            // 
            this.txtbx_memo_No11.Location = new System.Drawing.Point(119, 270);
            this.txtbx_memo_No11.Name = "txtbx_memo_No11";
            this.txtbx_memo_No11.ReadOnly = true;
            this.txtbx_memo_No11.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No11.TabIndex = 253;
            // 
            // btn_send_No27
            // 
            this.btn_send_No27.Location = new System.Drawing.Point(464, 268);
            this.btn_send_No27.Name = "btn_send_No27";
            this.btn_send_No27.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No27.TabIndex = 332;
            this.btn_send_No27.Text = "���M";
            this.btn_send_No27.UseVisualStyleBackColor = true;
            this.btn_send_No27.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No11
            // 
            this.btn_send_No11.Location = new System.Drawing.Point(63, 268);
            this.btn_send_No11.Name = "btn_send_No11";
            this.btn_send_No11.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No11.TabIndex = 252;
            this.btn_send_No11.Text = "���M";
            this.btn_send_No11.UseVisualStyleBackColor = true;
            this.btn_send_No11.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No27
            // 
            this.btn_select_No27.Location = new System.Drawing.Point(411, 268);
            this.btn_select_No27.Name = "btn_select_No27";
            this.btn_select_No27.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No27.TabIndex = 331;
            this.btn_select_No27.Text = "No.01";
            this.btn_select_No27.UseVisualStyleBackColor = true;
            this.btn_select_No27.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No11
            // 
            this.btn_select_No11.Location = new System.Drawing.Point(10, 268);
            this.btn_select_No11.Name = "btn_select_No11";
            this.btn_select_No11.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No11.TabIndex = 251;
            this.btn_select_No11.Text = "No.01";
            this.btn_select_No11.UseVisualStyleBackColor = true;
            this.btn_select_No11.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No26
            // 
            this.txtbx_memo_No26.Location = new System.Drawing.Point(520, 245);
            this.txtbx_memo_No26.Name = "txtbx_memo_No26";
            this.txtbx_memo_No26.ReadOnly = true;
            this.txtbx_memo_No26.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No26.TabIndex = 328;
            // 
            // txtbx_memo_No10
            // 
            this.txtbx_memo_No10.Location = new System.Drawing.Point(119, 245);
            this.txtbx_memo_No10.Name = "txtbx_memo_No10";
            this.txtbx_memo_No10.ReadOnly = true;
            this.txtbx_memo_No10.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No10.TabIndex = 248;
            // 
            // btn_send_No26
            // 
            this.btn_send_No26.Location = new System.Drawing.Point(464, 243);
            this.btn_send_No26.Name = "btn_send_No26";
            this.btn_send_No26.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No26.TabIndex = 327;
            this.btn_send_No26.Text = "���M";
            this.btn_send_No26.UseVisualStyleBackColor = true;
            this.btn_send_No26.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No10
            // 
            this.btn_send_No10.Location = new System.Drawing.Point(63, 243);
            this.btn_send_No10.Name = "btn_send_No10";
            this.btn_send_No10.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No10.TabIndex = 247;
            this.btn_send_No10.Text = "���M";
            this.btn_send_No10.UseVisualStyleBackColor = true;
            this.btn_send_No10.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No26
            // 
            this.btn_select_No26.Location = new System.Drawing.Point(411, 243);
            this.btn_select_No26.Name = "btn_select_No26";
            this.btn_select_No26.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No26.TabIndex = 326;
            this.btn_select_No26.Text = "No.01";
            this.btn_select_No26.UseVisualStyleBackColor = true;
            this.btn_select_No26.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No10
            // 
            this.btn_select_No10.Location = new System.Drawing.Point(10, 243);
            this.btn_select_No10.Name = "btn_select_No10";
            this.btn_select_No10.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No10.TabIndex = 246;
            this.btn_select_No10.Text = "No.01";
            this.btn_select_No10.UseVisualStyleBackColor = true;
            this.btn_select_No10.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No25
            // 
            this.txtbx_memo_No25.Location = new System.Drawing.Point(520, 220);
            this.txtbx_memo_No25.Name = "txtbx_memo_No25";
            this.txtbx_memo_No25.ReadOnly = true;
            this.txtbx_memo_No25.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No25.TabIndex = 323;
            // 
            // txtbx_memo_No09
            // 
            this.txtbx_memo_No09.Location = new System.Drawing.Point(119, 220);
            this.txtbx_memo_No09.Name = "txtbx_memo_No09";
            this.txtbx_memo_No09.ReadOnly = true;
            this.txtbx_memo_No09.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No09.TabIndex = 243;
            // 
            // btn_send_No25
            // 
            this.btn_send_No25.Location = new System.Drawing.Point(464, 218);
            this.btn_send_No25.Name = "btn_send_No25";
            this.btn_send_No25.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No25.TabIndex = 322;
            this.btn_send_No25.Text = "���M";
            this.btn_send_No25.UseVisualStyleBackColor = true;
            this.btn_send_No25.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No09
            // 
            this.btn_send_No09.Location = new System.Drawing.Point(63, 218);
            this.btn_send_No09.Name = "btn_send_No09";
            this.btn_send_No09.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No09.TabIndex = 242;
            this.btn_send_No09.Text = "���M";
            this.btn_send_No09.UseVisualStyleBackColor = true;
            this.btn_send_No09.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No25
            // 
            this.btn_select_No25.Location = new System.Drawing.Point(411, 218);
            this.btn_select_No25.Name = "btn_select_No25";
            this.btn_select_No25.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No25.TabIndex = 321;
            this.btn_select_No25.Text = "No.01";
            this.btn_select_No25.UseVisualStyleBackColor = true;
            this.btn_select_No25.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No09
            // 
            this.btn_select_No09.Location = new System.Drawing.Point(10, 218);
            this.btn_select_No09.Name = "btn_select_No09";
            this.btn_select_No09.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No09.TabIndex = 241;
            this.btn_select_No09.Text = "No.01";
            this.btn_select_No09.UseVisualStyleBackColor = true;
            this.btn_select_No09.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No24
            // 
            this.txtbx_memo_No24.Location = new System.Drawing.Point(520, 195);
            this.txtbx_memo_No24.Name = "txtbx_memo_No24";
            this.txtbx_memo_No24.ReadOnly = true;
            this.txtbx_memo_No24.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No24.TabIndex = 318;
            // 
            // txtbx_memo_No08
            // 
            this.txtbx_memo_No08.Location = new System.Drawing.Point(119, 195);
            this.txtbx_memo_No08.Name = "txtbx_memo_No08";
            this.txtbx_memo_No08.ReadOnly = true;
            this.txtbx_memo_No08.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No08.TabIndex = 238;
            // 
            // btn_send_No24
            // 
            this.btn_send_No24.Location = new System.Drawing.Point(464, 193);
            this.btn_send_No24.Name = "btn_send_No24";
            this.btn_send_No24.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No24.TabIndex = 317;
            this.btn_send_No24.Text = "���M";
            this.btn_send_No24.UseVisualStyleBackColor = true;
            this.btn_send_No24.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No08
            // 
            this.btn_send_No08.Location = new System.Drawing.Point(63, 193);
            this.btn_send_No08.Name = "btn_send_No08";
            this.btn_send_No08.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No08.TabIndex = 237;
            this.btn_send_No08.Text = "���M";
            this.btn_send_No08.UseVisualStyleBackColor = true;
            this.btn_send_No08.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No24
            // 
            this.btn_select_No24.Location = new System.Drawing.Point(411, 193);
            this.btn_select_No24.Name = "btn_select_No24";
            this.btn_select_No24.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No24.TabIndex = 316;
            this.btn_select_No24.Text = "No.01";
            this.btn_select_No24.UseVisualStyleBackColor = true;
            this.btn_select_No24.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No08
            // 
            this.btn_select_No08.Location = new System.Drawing.Point(10, 193);
            this.btn_select_No08.Name = "btn_select_No08";
            this.btn_select_No08.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No08.TabIndex = 236;
            this.btn_select_No08.Text = "No.01";
            this.btn_select_No08.UseVisualStyleBackColor = true;
            this.btn_select_No08.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No23
            // 
            this.txtbx_memo_No23.Location = new System.Drawing.Point(520, 170);
            this.txtbx_memo_No23.Name = "txtbx_memo_No23";
            this.txtbx_memo_No23.ReadOnly = true;
            this.txtbx_memo_No23.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No23.TabIndex = 313;
            // 
            // txtbx_memo_No07
            // 
            this.txtbx_memo_No07.Location = new System.Drawing.Point(119, 170);
            this.txtbx_memo_No07.Name = "txtbx_memo_No07";
            this.txtbx_memo_No07.ReadOnly = true;
            this.txtbx_memo_No07.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No07.TabIndex = 233;
            // 
            // btn_send_No23
            // 
            this.btn_send_No23.Location = new System.Drawing.Point(464, 168);
            this.btn_send_No23.Name = "btn_send_No23";
            this.btn_send_No23.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No23.TabIndex = 312;
            this.btn_send_No23.Text = "���M";
            this.btn_send_No23.UseVisualStyleBackColor = true;
            this.btn_send_No23.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No07
            // 
            this.btn_send_No07.Location = new System.Drawing.Point(63, 168);
            this.btn_send_No07.Name = "btn_send_No07";
            this.btn_send_No07.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No07.TabIndex = 232;
            this.btn_send_No07.Text = "���M";
            this.btn_send_No07.UseVisualStyleBackColor = true;
            this.btn_send_No07.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No23
            // 
            this.btn_select_No23.Location = new System.Drawing.Point(411, 168);
            this.btn_select_No23.Name = "btn_select_No23";
            this.btn_select_No23.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No23.TabIndex = 311;
            this.btn_select_No23.Text = "No.01";
            this.btn_select_No23.UseVisualStyleBackColor = true;
            this.btn_select_No23.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No07
            // 
            this.btn_select_No07.Location = new System.Drawing.Point(10, 168);
            this.btn_select_No07.Name = "btn_select_No07";
            this.btn_select_No07.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No07.TabIndex = 231;
            this.btn_select_No07.Text = "No.01";
            this.btn_select_No07.UseVisualStyleBackColor = true;
            this.btn_select_No07.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No22
            // 
            this.txtbx_memo_No22.Location = new System.Drawing.Point(520, 145);
            this.txtbx_memo_No22.Name = "txtbx_memo_No22";
            this.txtbx_memo_No22.ReadOnly = true;
            this.txtbx_memo_No22.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No22.TabIndex = 308;
            // 
            // txtbx_memo_No06
            // 
            this.txtbx_memo_No06.Location = new System.Drawing.Point(119, 145);
            this.txtbx_memo_No06.Name = "txtbx_memo_No06";
            this.txtbx_memo_No06.ReadOnly = true;
            this.txtbx_memo_No06.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No06.TabIndex = 228;
            // 
            // btn_send_No22
            // 
            this.btn_send_No22.Location = new System.Drawing.Point(464, 143);
            this.btn_send_No22.Name = "btn_send_No22";
            this.btn_send_No22.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No22.TabIndex = 307;
            this.btn_send_No22.Text = "���M";
            this.btn_send_No22.UseVisualStyleBackColor = true;
            this.btn_send_No22.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No06
            // 
            this.btn_send_No06.Location = new System.Drawing.Point(63, 143);
            this.btn_send_No06.Name = "btn_send_No06";
            this.btn_send_No06.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No06.TabIndex = 227;
            this.btn_send_No06.Text = "���M";
            this.btn_send_No06.UseVisualStyleBackColor = true;
            this.btn_send_No06.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No22
            // 
            this.btn_select_No22.Location = new System.Drawing.Point(411, 143);
            this.btn_select_No22.Name = "btn_select_No22";
            this.btn_select_No22.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No22.TabIndex = 306;
            this.btn_select_No22.Text = "No.01";
            this.btn_select_No22.UseVisualStyleBackColor = true;
            this.btn_select_No22.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No06
            // 
            this.btn_select_No06.Location = new System.Drawing.Point(10, 143);
            this.btn_select_No06.Name = "btn_select_No06";
            this.btn_select_No06.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No06.TabIndex = 226;
            this.btn_select_No06.Text = "No.01";
            this.btn_select_No06.UseVisualStyleBackColor = true;
            this.btn_select_No06.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No21
            // 
            this.txtbx_memo_No21.Location = new System.Drawing.Point(520, 120);
            this.txtbx_memo_No21.Name = "txtbx_memo_No21";
            this.txtbx_memo_No21.ReadOnly = true;
            this.txtbx_memo_No21.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No21.TabIndex = 303;
            // 
            // txtbx_memo_No05
            // 
            this.txtbx_memo_No05.Location = new System.Drawing.Point(119, 120);
            this.txtbx_memo_No05.Name = "txtbx_memo_No05";
            this.txtbx_memo_No05.ReadOnly = true;
            this.txtbx_memo_No05.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No05.TabIndex = 223;
            // 
            // btn_send_No21
            // 
            this.btn_send_No21.Location = new System.Drawing.Point(464, 118);
            this.btn_send_No21.Name = "btn_send_No21";
            this.btn_send_No21.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No21.TabIndex = 302;
            this.btn_send_No21.Text = "���M";
            this.btn_send_No21.UseVisualStyleBackColor = true;
            this.btn_send_No21.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No05
            // 
            this.btn_send_No05.Location = new System.Drawing.Point(63, 118);
            this.btn_send_No05.Name = "btn_send_No05";
            this.btn_send_No05.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No05.TabIndex = 222;
            this.btn_send_No05.Text = "���M";
            this.btn_send_No05.UseVisualStyleBackColor = true;
            this.btn_send_No05.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No21
            // 
            this.btn_select_No21.Location = new System.Drawing.Point(411, 118);
            this.btn_select_No21.Name = "btn_select_No21";
            this.btn_select_No21.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No21.TabIndex = 301;
            this.btn_select_No21.Text = "No.01";
            this.btn_select_No21.UseVisualStyleBackColor = true;
            this.btn_select_No21.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No05
            // 
            this.btn_select_No05.Location = new System.Drawing.Point(10, 118);
            this.btn_select_No05.Name = "btn_select_No05";
            this.btn_select_No05.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No05.TabIndex = 221;
            this.btn_select_No05.Text = "No.01";
            this.btn_select_No05.UseVisualStyleBackColor = true;
            this.btn_select_No05.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No20
            // 
            this.txtbx_memo_No20.Location = new System.Drawing.Point(520, 95);
            this.txtbx_memo_No20.Name = "txtbx_memo_No20";
            this.txtbx_memo_No20.ReadOnly = true;
            this.txtbx_memo_No20.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No20.TabIndex = 298;
            // 
            // txtbx_memo_No04
            // 
            this.txtbx_memo_No04.Location = new System.Drawing.Point(119, 95);
            this.txtbx_memo_No04.Name = "txtbx_memo_No04";
            this.txtbx_memo_No04.ReadOnly = true;
            this.txtbx_memo_No04.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No04.TabIndex = 218;
            // 
            // btn_send_No20
            // 
            this.btn_send_No20.Location = new System.Drawing.Point(464, 93);
            this.btn_send_No20.Name = "btn_send_No20";
            this.btn_send_No20.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No20.TabIndex = 297;
            this.btn_send_No20.Text = "���M";
            this.btn_send_No20.UseVisualStyleBackColor = true;
            this.btn_send_No20.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No04
            // 
            this.btn_send_No04.Location = new System.Drawing.Point(63, 93);
            this.btn_send_No04.Name = "btn_send_No04";
            this.btn_send_No04.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No04.TabIndex = 217;
            this.btn_send_No04.Text = "���M";
            this.btn_send_No04.UseVisualStyleBackColor = true;
            this.btn_send_No04.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No20
            // 
            this.btn_select_No20.Location = new System.Drawing.Point(411, 93);
            this.btn_select_No20.Name = "btn_select_No20";
            this.btn_select_No20.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No20.TabIndex = 296;
            this.btn_select_No20.Text = "No.01";
            this.btn_select_No20.UseVisualStyleBackColor = true;
            this.btn_select_No20.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No04
            // 
            this.btn_select_No04.Location = new System.Drawing.Point(10, 93);
            this.btn_select_No04.Name = "btn_select_No04";
            this.btn_select_No04.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No04.TabIndex = 216;
            this.btn_select_No04.Text = "No.01";
            this.btn_select_No04.UseVisualStyleBackColor = true;
            this.btn_select_No04.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No19
            // 
            this.txtbx_memo_No19.Location = new System.Drawing.Point(520, 70);
            this.txtbx_memo_No19.Name = "txtbx_memo_No19";
            this.txtbx_memo_No19.ReadOnly = true;
            this.txtbx_memo_No19.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No19.TabIndex = 293;
            // 
            // txtbx_memo_No03
            // 
            this.txtbx_memo_No03.Location = new System.Drawing.Point(119, 70);
            this.txtbx_memo_No03.Name = "txtbx_memo_No03";
            this.txtbx_memo_No03.ReadOnly = true;
            this.txtbx_memo_No03.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No03.TabIndex = 213;
            // 
            // btn_send_No19
            // 
            this.btn_send_No19.Location = new System.Drawing.Point(464, 68);
            this.btn_send_No19.Name = "btn_send_No19";
            this.btn_send_No19.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No19.TabIndex = 292;
            this.btn_send_No19.Text = "���M";
            this.btn_send_No19.UseVisualStyleBackColor = true;
            this.btn_send_No19.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No03
            // 
            this.btn_send_No03.Location = new System.Drawing.Point(63, 68);
            this.btn_send_No03.Name = "btn_send_No03";
            this.btn_send_No03.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No03.TabIndex = 212;
            this.btn_send_No03.Text = "���M";
            this.btn_send_No03.UseVisualStyleBackColor = true;
            this.btn_send_No03.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No19
            // 
            this.btn_select_No19.Location = new System.Drawing.Point(411, 68);
            this.btn_select_No19.Name = "btn_select_No19";
            this.btn_select_No19.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No19.TabIndex = 291;
            this.btn_select_No19.Text = "No.01";
            this.btn_select_No19.UseVisualStyleBackColor = true;
            this.btn_select_No19.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No03
            // 
            this.btn_select_No03.Location = new System.Drawing.Point(10, 68);
            this.btn_select_No03.Name = "btn_select_No03";
            this.btn_select_No03.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No03.TabIndex = 211;
            this.btn_select_No03.Text = "No.01";
            this.btn_select_No03.UseVisualStyleBackColor = true;
            this.btn_select_No03.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No18
            // 
            this.txtbx_memo_No18.Location = new System.Drawing.Point(520, 45);
            this.txtbx_memo_No18.Name = "txtbx_memo_No18";
            this.txtbx_memo_No18.ReadOnly = true;
            this.txtbx_memo_No18.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No18.TabIndex = 288;
            // 
            // txtbx_memo_No02
            // 
            this.txtbx_memo_No02.Location = new System.Drawing.Point(119, 45);
            this.txtbx_memo_No02.Name = "txtbx_memo_No02";
            this.txtbx_memo_No02.ReadOnly = true;
            this.txtbx_memo_No02.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No02.TabIndex = 208;
            // 
            // btn_send_No18
            // 
            this.btn_send_No18.Location = new System.Drawing.Point(464, 43);
            this.btn_send_No18.Name = "btn_send_No18";
            this.btn_send_No18.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No18.TabIndex = 287;
            this.btn_send_No18.Text = "���M";
            this.btn_send_No18.UseVisualStyleBackColor = true;
            this.btn_send_No18.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No02
            // 
            this.btn_send_No02.Location = new System.Drawing.Point(63, 43);
            this.btn_send_No02.Name = "btn_send_No02";
            this.btn_send_No02.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No02.TabIndex = 207;
            this.btn_send_No02.Text = "���M";
            this.btn_send_No02.UseVisualStyleBackColor = true;
            this.btn_send_No02.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No18
            // 
            this.btn_select_No18.Location = new System.Drawing.Point(411, 43);
            this.btn_select_No18.Name = "btn_select_No18";
            this.btn_select_No18.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No18.TabIndex = 286;
            this.btn_select_No18.Text = "No.01";
            this.btn_select_No18.UseVisualStyleBackColor = true;
            this.btn_select_No18.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No02
            // 
            this.btn_select_No02.Location = new System.Drawing.Point(10, 43);
            this.btn_select_No02.Name = "btn_select_No02";
            this.btn_select_No02.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No02.TabIndex = 206;
            this.btn_select_No02.Text = "No.01";
            this.btn_select_No02.UseVisualStyleBackColor = true;
            this.btn_select_No02.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // txtbx_memo_No17
            // 
            this.txtbx_memo_No17.Location = new System.Drawing.Point(520, 20);
            this.txtbx_memo_No17.Name = "txtbx_memo_No17";
            this.txtbx_memo_No17.ReadOnly = true;
            this.txtbx_memo_No17.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No17.TabIndex = 283;
            // 
            // txtbx_memo_No01
            // 
            this.txtbx_memo_No01.Location = new System.Drawing.Point(119, 20);
            this.txtbx_memo_No01.Name = "txtbx_memo_No01";
            this.txtbx_memo_No01.ReadOnly = true;
            this.txtbx_memo_No01.Size = new System.Drawing.Size(250, 19);
            this.txtbx_memo_No01.TabIndex = 203;
            // 
            // btn_send_No17
            // 
            this.btn_send_No17.Location = new System.Drawing.Point(464, 18);
            this.btn_send_No17.Name = "btn_send_No17";
            this.btn_send_No17.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No17.TabIndex = 282;
            this.btn_send_No17.Text = "���M";
            this.btn_send_No17.UseVisualStyleBackColor = true;
            this.btn_send_No17.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_send_No01
            // 
            this.btn_send_No01.Location = new System.Drawing.Point(63, 18);
            this.btn_send_No01.Name = "btn_send_No01";
            this.btn_send_No01.Size = new System.Drawing.Size(50, 23);
            this.btn_send_No01.TabIndex = 202;
            this.btn_send_No01.Text = "���M";
            this.btn_send_No01.UseVisualStyleBackColor = true;
            this.btn_send_No01.Click += new System.EventHandler(this.btn_send_No_Click);
            // 
            // btn_select_No17
            // 
            this.btn_select_No17.Location = new System.Drawing.Point(411, 18);
            this.btn_select_No17.Name = "btn_select_No17";
            this.btn_select_No17.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No17.TabIndex = 281;
            this.btn_select_No17.Text = "No.01";
            this.btn_select_No17.UseVisualStyleBackColor = true;
            this.btn_select_No17.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_select_No01
            // 
            this.btn_select_No01.Location = new System.Drawing.Point(10, 18);
            this.btn_select_No01.Name = "btn_select_No01";
            this.btn_select_No01.Size = new System.Drawing.Size(50, 23);
            this.btn_select_No01.TabIndex = 201;
            this.btn_select_No01.Text = "No.01";
            this.btn_select_No01.UseVisualStyleBackColor = true;
            this.btn_select_No01.Click += new System.EventHandler(this.btn_select_No_Click);
            // 
            // btn_timer_set_display
            // 
            this.btn_timer_set_display.Location = new System.Drawing.Point(735, 26);
            this.btn_timer_set_display.Name = "btn_timer_set_display";
            this.btn_timer_set_display.Size = new System.Drawing.Size(57, 110);
            this.btn_timer_set_display.TabIndex = 400;
            this.btn_timer_set_display.Text = "�^�C�}�[�ݒ�\��";
            this.btn_timer_set_display.UseVisualStyleBackColor = true;
            this.btn_timer_set_display.Click += new System.EventHandler(this.btn_timer_set_display_Click);
            // 
            // gbx_timer_setting
            // 
            this.gbx_timer_setting.BackColor = System.Drawing.Color.Transparent;
            this.gbx_timer_setting.Controls.Add(this.btn_timer_list_import);
            this.gbx_timer_setting.Controls.Add(this.dgv_timer_set_list);
            this.gbx_timer_setting.Controls.Add(this.btn_timer_list_export);
            this.gbx_timer_setting.Controls.Add(this.lbl_timer_now_time);
            this.gbx_timer_setting.Controls.Add(this.btn_timer_item_del);
            this.gbx_timer_setting.Controls.Add(this.gbx_timer_item_add);
            this.gbx_timer_setting.Controls.Add(this.btn_timer_on_off);
            this.gbx_timer_setting.Location = new System.Drawing.Point(798, 12);
            this.gbx_timer_setting.Name = "gbx_timer_setting";
            this.gbx_timer_setting.Size = new System.Drawing.Size(190, 593);
            this.gbx_timer_setting.TabIndex = 401;
            this.gbx_timer_setting.TabStop = false;
            this.gbx_timer_setting.Text = "�^�C�}�[�ݒ�";
            // 
            // btn_timer_list_import
            // 
            this.btn_timer_list_import.Location = new System.Drawing.Point(97, 534);
            this.btn_timer_list_import.Name = "btn_timer_list_import";
            this.btn_timer_list_import.Size = new System.Drawing.Size(80, 23);
            this.btn_timer_list_import.TabIndex = 421;
            this.btn_timer_list_import.Text = "�C���|�[�g";
            this.btn_timer_list_import.UseVisualStyleBackColor = true;
            this.btn_timer_list_import.Click += new System.EventHandler(this.btn_timer_list_import_Click);
            // 
            // dgv_timer_set_list
            // 
            this.dgv_timer_set_list.AllowUserToAddRows = false;
            this.dgv_timer_set_list.AllowUserToDeleteRows = false;
            this.dgv_timer_set_list.AllowUserToResizeColumns = false;
            this.dgv_timer_set_list.AllowUserToResizeRows = false;
            this.dgv_timer_set_list.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_timer_set_list.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chkbx_select,
            this.time,
            this.Send_data_no});
            this.dgv_timer_set_list.Location = new System.Drawing.Point(12, 45);
            this.dgv_timer_set_list.Name = "dgv_timer_set_list";
            this.dgv_timer_set_list.RowHeadersVisible = false;
            this.dgv_timer_set_list.RowTemplate.Height = 21;
            this.dgv_timer_set_list.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_timer_set_list.Size = new System.Drawing.Size(165, 345);
            this.dgv_timer_set_list.TabIndex = 403;
            this.dgv_timer_set_list.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_timer_set_list_CellValueChanged);
            this.dgv_timer_set_list.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_timer_set_list_CellContentClick);
            // 
            // chkbx_select
            // 
            this.chkbx_select.HeaderText = "";
            this.chkbx_select.Name = "chkbx_select";
            this.chkbx_select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.chkbx_select.Width = 25;
            // 
            // time
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.time.DefaultCellStyle = dataGridViewCellStyle1;
            this.time.HeaderText = "����";
            this.time.Name = "time";
            this.time.ReadOnly = true;
            this.time.Width = 80;
            // 
            // Send_data_no
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.Send_data_no.DefaultCellStyle = dataGridViewCellStyle2;
            this.Send_data_no.HeaderText = "No.";
            this.Send_data_no.Name = "Send_data_no";
            this.Send_data_no.ReadOnly = true;
            this.Send_data_no.Width = 40;
            // 
            // btn_timer_list_export
            // 
            this.btn_timer_list_export.Location = new System.Drawing.Point(12, 534);
            this.btn_timer_list_export.Name = "btn_timer_list_export";
            this.btn_timer_list_export.Size = new System.Drawing.Size(80, 23);
            this.btn_timer_list_export.TabIndex = 420;
            this.btn_timer_list_export.Text = "�G�N�X�|�[�g";
            this.btn_timer_list_export.UseVisualStyleBackColor = true;
            this.btn_timer_list_export.Click += new System.EventHandler(this.btn_timer_list_export_Click);
            // 
            // lbl_timer_now_time
            // 
            this.lbl_timer_now_time.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbl_timer_now_time.Location = new System.Drawing.Point(12, 567);
            this.lbl_timer_now_time.Name = "lbl_timer_now_time";
            this.lbl_timer_now_time.Size = new System.Drawing.Size(165, 17);
            this.lbl_timer_now_time.TabIndex = 422;
            this.lbl_timer_now_time.Text = "���ݎ���";
            this.lbl_timer_now_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_timer_item_del
            // 
            this.btn_timer_item_del.Location = new System.Drawing.Point(12, 393);
            this.btn_timer_item_del.Name = "btn_timer_item_del";
            this.btn_timer_item_del.Size = new System.Drawing.Size(80, 23);
            this.btn_timer_item_del.TabIndex = 404;
            this.btn_timer_item_del.Text = "�I�����폜";
            this.btn_timer_item_del.UseVisualStyleBackColor = true;
            this.btn_timer_item_del.Click += new System.EventHandler(this.btn_timer_item_del_Click);
            // 
            // gbx_timer_item_add
            // 
            this.gbx_timer_item_add.Controls.Add(this.lbl_timer_set_no);
            this.gbx_timer_item_add.Controls.Add(this.lbl_timer_set_time);
            this.gbx_timer_item_add.Controls.Add(this.cmbbx_timer_set_no);
            this.gbx_timer_item_add.Controls.Add(this.dtp_timer_set_time);
            this.gbx_timer_item_add.Controls.Add(this.btn_timer_item_add);
            this.gbx_timer_item_add.Location = new System.Drawing.Point(12, 430);
            this.gbx_timer_item_add.Name = "gbx_timer_item_add";
            this.gbx_timer_item_add.Size = new System.Drawing.Size(165, 95);
            this.gbx_timer_item_add.TabIndex = 410;
            this.gbx_timer_item_add.TabStop = false;
            this.gbx_timer_item_add.Text = "�^�C�}�[�ݒ�ǉ�";
            // 
            // lbl_timer_set_no
            // 
            this.lbl_timer_set_no.Location = new System.Drawing.Point(12, 43);
            this.lbl_timer_set_no.Name = "lbl_timer_set_no";
            this.lbl_timer_set_no.Size = new System.Drawing.Size(57, 21);
            this.lbl_timer_set_no.TabIndex = 413;
            this.lbl_timer_set_no.Text = "���MNo.";
            // 
            // lbl_timer_set_time
            // 
            this.lbl_timer_set_time.Location = new System.Drawing.Point(12, 22);
            this.lbl_timer_set_time.Name = "lbl_timer_set_time";
            this.lbl_timer_set_time.Size = new System.Drawing.Size(57, 25);
            this.lbl_timer_set_time.TabIndex = 411;
            this.lbl_timer_set_time.Text = "���M����";
            // 
            // cmbbx_timer_set_no
            // 
            this.cmbbx_timer_set_no.FormattingEnabled = true;
            this.cmbbx_timer_set_no.Location = new System.Drawing.Point(75, 40);
            this.cmbbx_timer_set_no.Name = "cmbbx_timer_set_no";
            this.cmbbx_timer_set_no.Size = new System.Drawing.Size(80, 20);
            this.cmbbx_timer_set_no.TabIndex = 414;
            // 
            // dtp_timer_set_time
            // 
            this.dtp_timer_set_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_timer_set_time.Location = new System.Drawing.Point(75, 18);
            this.dtp_timer_set_time.Name = "dtp_timer_set_time";
            this.dtp_timer_set_time.ShowUpDown = true;
            this.dtp_timer_set_time.Size = new System.Drawing.Size(80, 19);
            this.dtp_timer_set_time.TabIndex = 412;
            // 
            // btn_timer_item_add
            // 
            this.btn_timer_item_add.Location = new System.Drawing.Point(45, 66);
            this.btn_timer_item_add.Name = "btn_timer_item_add";
            this.btn_timer_item_add.Size = new System.Drawing.Size(75, 23);
            this.btn_timer_item_add.TabIndex = 415;
            this.btn_timer_item_add.Text = "�ǉ�";
            this.btn_timer_item_add.UseVisualStyleBackColor = true;
            this.btn_timer_item_add.Click += new System.EventHandler(this.btn_timer_item_add_Click);
            // 
            // btn_timer_on_off
            // 
            this.btn_timer_on_off.ImageIndex = 0;
            this.btn_timer_on_off.ImageList = this.imglist_timer_onoff;
            this.btn_timer_on_off.Location = new System.Drawing.Point(10, 18);
            this.btn_timer_on_off.Name = "btn_timer_on_off";
            this.btn_timer_on_off.Size = new System.Drawing.Size(170, 25);
            this.btn_timer_on_off.TabIndex = 402;
            this.btn_timer_on_off.UseVisualStyleBackColor = true;
            this.btn_timer_on_off.Click += new System.EventHandler(this.btn_timer_on_off_Click);
            // 
            // imglist_timer_onoff
            // 
            this.imglist_timer_onoff.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglist_timer_onoff.ImageStream")));
            this.imglist_timer_onoff.TransparentColor = System.Drawing.Color.Transparent;
            this.imglist_timer_onoff.Images.SetKeyName(0, "timer-off.png");
            this.imglist_timer_onoff.Images.SetKeyName(1, "timer-on.png");
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = global::USB_IR_Remote_Controller_Advance_CT.Properties.Resources.sendBGs;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1159, 860);
            this.Controls.Add(this.gbx_timer_setting);
            this.Controls.Add(this.btn_timer_set_display);
            this.Controls.Add(this.gbx_Setting_list);
            this.Controls.Add(this.gbx_Setting);
            this.Controls.Add(this.lbl_FW_Version);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.connect_status_lbl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "USB IR Remote Controller Advance ���M�ݒ� Configuration Tool Ver ";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.gbx_Setting.ResumeLayout(false);
            this.gbx_Setting.PerformLayout();
            this.gbx_Setting_list.ResumeLayout(false);
            this.gbx_Setting_list.PerformLayout();
            this.gbx_timer_setting.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_timer_set_list)).EndInit();
            this.gbx_timer_item_add.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.Label connect_status_lbl;
        private System.Windows.Forms.Label debug01_lbl;
        private System.Windows.Forms.Label debug02_lbl;
        private System.Windows.Forms.Label debug03_lbl;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_FW_Version;
        private System.Windows.Forms.Button btn_ir_read_start;
        private System.Windows.Forms.RichTextBox rtxtbx_ir_read_data;
        private System.Windows.Forms.Label lbl_ir_read_result;
        private System.Windows.Forms.Button btn_ir_read_stop;
        private System.Windows.Forms.Label lbl_ir_read_size;
        private System.Windows.Forms.Button btn_ir_data_file_read;
        private System.Windows.Forms.Button btn_ir_data_file_save;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btn_clip_copy;
        private System.Windows.Forms.GroupBox gbx_Setting;
        private System.Windows.Forms.Label lbl_SelectNo;
        private System.Windows.Forms.GroupBox gbx_Setting_list;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Setting_Set;
        private System.Windows.Forms.TextBox txtbx_memo;
        private System.Windows.Forms.Button btn_send_No01;
        private System.Windows.Forms.Button btn_select_No01;
        private System.Windows.Forms.TextBox txtbx_memo_No01;
        private System.Windows.Forms.TextBox txtbx_memo_No16;
        private System.Windows.Forms.Button btn_send_No16;
        private System.Windows.Forms.Button btn_select_No16;
        private System.Windows.Forms.TextBox txtbx_memo_No15;
        private System.Windows.Forms.Button btn_send_No15;
        private System.Windows.Forms.TextBox txtbx_memo_No14;
        private System.Windows.Forms.Button btn_select_No15;
        private System.Windows.Forms.Button btn_send_No14;
        private System.Windows.Forms.Button btn_select_No14;
        private System.Windows.Forms.TextBox txtbx_memo_No13;
        private System.Windows.Forms.Button btn_send_No13;
        private System.Windows.Forms.Button btn_select_No13;
        private System.Windows.Forms.TextBox txtbx_memo_No12;
        private System.Windows.Forms.Button btn_send_No12;
        private System.Windows.Forms.Button btn_select_No12;
        private System.Windows.Forms.TextBox txtbx_memo_No11;
        private System.Windows.Forms.Button btn_send_No11;
        private System.Windows.Forms.Button btn_select_No11;
        private System.Windows.Forms.TextBox txtbx_memo_No10;
        private System.Windows.Forms.Button btn_send_No10;
        private System.Windows.Forms.Button btn_select_No10;
        private System.Windows.Forms.TextBox txtbx_memo_No09;
        private System.Windows.Forms.Button btn_send_No09;
        private System.Windows.Forms.Button btn_select_No09;
        private System.Windows.Forms.TextBox txtbx_memo_No08;
        private System.Windows.Forms.Button btn_send_No08;
        private System.Windows.Forms.Button btn_select_No08;
        private System.Windows.Forms.TextBox txtbx_memo_No07;
        private System.Windows.Forms.Button btn_send_No07;
        private System.Windows.Forms.Button btn_select_No07;
        private System.Windows.Forms.TextBox txtbx_memo_No06;
        private System.Windows.Forms.Button btn_send_No06;
        private System.Windows.Forms.Button btn_select_No06;
        private System.Windows.Forms.TextBox txtbx_memo_No05;
        private System.Windows.Forms.Button btn_send_No05;
        private System.Windows.Forms.Button btn_select_No05;
        private System.Windows.Forms.TextBox txtbx_memo_No04;
        private System.Windows.Forms.Button btn_send_No04;
        private System.Windows.Forms.Button btn_select_No04;
        private System.Windows.Forms.TextBox txtbx_memo_No03;
        private System.Windows.Forms.Button btn_send_No03;
        private System.Windows.Forms.Button btn_select_No03;
        private System.Windows.Forms.TextBox txtbx_memo_No02;
        private System.Windows.Forms.Button btn_send_No02;
        private System.Windows.Forms.Button btn_select_No02;
        private System.Windows.Forms.TextBox txtbx_memo_No32;
        private System.Windows.Forms.Button btn_send_No32;
        private System.Windows.Forms.Button btn_select_No32;
        private System.Windows.Forms.TextBox txtbx_memo_No31;
        private System.Windows.Forms.Button btn_send_No31;
        private System.Windows.Forms.TextBox txtbx_memo_No30;
        private System.Windows.Forms.Button btn_select_No31;
        private System.Windows.Forms.Button btn_send_No30;
        private System.Windows.Forms.Button btn_select_No30;
        private System.Windows.Forms.TextBox txtbx_memo_No29;
        private System.Windows.Forms.Button btn_send_No29;
        private System.Windows.Forms.Button btn_select_No29;
        private System.Windows.Forms.TextBox txtbx_memo_No28;
        private System.Windows.Forms.Button btn_send_No28;
        private System.Windows.Forms.Button btn_select_No28;
        private System.Windows.Forms.TextBox txtbx_memo_No27;
        private System.Windows.Forms.Button btn_send_No27;
        private System.Windows.Forms.Button btn_select_No27;
        private System.Windows.Forms.TextBox txtbx_memo_No26;
        private System.Windows.Forms.Button btn_send_No26;
        private System.Windows.Forms.Button btn_select_No26;
        private System.Windows.Forms.TextBox txtbx_memo_No25;
        private System.Windows.Forms.Button btn_send_No25;
        private System.Windows.Forms.Button btn_select_No25;
        private System.Windows.Forms.TextBox txtbx_memo_No24;
        private System.Windows.Forms.Button btn_send_No24;
        private System.Windows.Forms.Button btn_select_No24;
        private System.Windows.Forms.TextBox txtbx_memo_No23;
        private System.Windows.Forms.Button btn_send_No23;
        private System.Windows.Forms.Button btn_select_No23;
        private System.Windows.Forms.TextBox txtbx_memo_No22;
        private System.Windows.Forms.Button btn_send_No22;
        private System.Windows.Forms.Button btn_select_No22;
        private System.Windows.Forms.TextBox txtbx_memo_No21;
        private System.Windows.Forms.Button btn_send_No21;
        private System.Windows.Forms.Button btn_select_No21;
        private System.Windows.Forms.TextBox txtbx_memo_No20;
        private System.Windows.Forms.Button btn_send_No20;
        private System.Windows.Forms.Button btn_select_No20;
        private System.Windows.Forms.TextBox txtbx_memo_No19;
        private System.Windows.Forms.Button btn_send_No19;
        private System.Windows.Forms.Button btn_select_No19;
        private System.Windows.Forms.TextBox txtbx_memo_No18;
        private System.Windows.Forms.Button btn_send_No18;
        private System.Windows.Forms.Button btn_select_No18;
        private System.Windows.Forms.TextBox txtbx_memo_No17;
        private System.Windows.Forms.Button btn_send_No17;
        private System.Windows.Forms.Button btn_select_No17;
        private System.Windows.Forms.Button btn_setting_clr;
        private System.Windows.Forms.Button btn_timer_set_display;
        private System.Windows.Forms.GroupBox gbx_timer_setting;
        private System.Windows.Forms.GroupBox gbx_timer_item_add;
        private System.Windows.Forms.DateTimePicker dtp_timer_set_time;
        private System.Windows.Forms.Button btn_timer_item_add;
        private System.Windows.Forms.Button btn_timer_on_off;
        private System.Windows.Forms.Label lbl_timer_now_time;
        private System.Windows.Forms.Button btn_timer_item_del;
        private System.Windows.Forms.Label lbl_timer_set_no;
        private System.Windows.Forms.Label lbl_timer_set_time;
        private System.Windows.Forms.ComboBox cmbbx_timer_set_no;
        private System.Windows.Forms.DataGridView dgv_timer_set_list;
        private System.Windows.Forms.Button btn_timer_list_import;
        private System.Windows.Forms.Button btn_timer_list_export;
        private System.Windows.Forms.ImageList imglist_timer_onoff;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chkbx_select;
        private System.Windows.Forms.DataGridViewTextBoxColumn time;
        private System.Windows.Forms.DataGridViewTextBoxColumn Send_data_no;
    }
}

