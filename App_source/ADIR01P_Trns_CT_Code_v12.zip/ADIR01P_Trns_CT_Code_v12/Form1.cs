//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
/********************************************************************
 FileName:		Form1.cs
 Dependencies:	When compiled, needs .NET framework 2.0 redistributable to run.
 Hardware:		Need a free USB port to connect USB peripheral device
				programmed with appropriate Generic HID firmware.  VID and
				PID in firmware must match the VID and PID in this
				program.
 Compiler:  	Microsoft Visual C# 2005 Express Edition (or better)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�E for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively with Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS�ECONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  2.5a	07/17/2009	 Initial Release.  Ported from HID PnP Demo
                     application source, which was originally 
                     written in MSVC++ 2005 Express Edition.
********************************************************************
NOTE:	All user made code contained in this project is in the Form1.cs file.
		All other code and files were generated automatically by either the
		new project wizard, or by the development environment (ex: code is
		automatically generated if you create a new button on the form, and
		then double click on it, which creates a click event handler
		function).  User developed code (code not developed by the IDE) has
        been marked in "cut and paste blocks" to make it easier to identify.
********************************************************************/

//NOTE: In order for this program to "find" a USB device with a given VID and PID, 
//both the VID and PID in the USB device descriptor (in the USB firmware on the 
//microcontroller), as well as in this PC application source code, must match.
//To change the VID/PID in this PC application source code, scroll down to the 
//CheckIfPresentAndGetUSBDevicePath() function, and change the line that currently
//reads:

//   String DeviceIDToFind = "Vid_04d8&Pid_003f";


//NOTE 2: This C# program makes use of several functions in setupapi.dll and
//other Win32 DLLs.  However, one cannot call the functions directly in a 
//32-bit DLL if the project is built in "Any CPU" mode, when run on a 64-bit OS.
//When configured to build an "Any CPU" executable, the executable will "become"
//a 64-bit executable when run on a 64-bit OS.  On a 32-bit OS, it will run as 
//a 32-bit executable, and the pointer sizes and other aspects of this 
//application will be compatible with calling 32-bit DLLs.

//Therefore, on a 64-bit OS, this application will not work unless it is built in
//"x86" mode.  When built in this mode, the exectuable always runs in 32-bit mode
//even on a 64-bit OS.  This allows this application to make 32-bit DLL function 
//calls, when run on either a 32-bit or 64-bit OS.

//By default, on a new project, C# normally wants to build in "Any CPU" mode.  
//To switch to "x86" mode, open the "Configuration Manager" window.  In the 
//"Active solution platform:" drop down box, select "x86".  If this option does
//not appear, select: "<New...>" and then select the x86 option in the 
//"Type or select the new platform:" drop down box.  

//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------



using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;
using System.Threading;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Resources;


namespace IR_Remote_Control_Pro
{
    public partial class Form1 : Form
    {
#if DEBUG
        internal const bool __DEBUG_FLAG__ = true;    // �f�o�b�O��
#else
        internal const bool __DEBUG_FLAG__ = false;     // �����[�X��
#endif

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        internal const string DEF_VID_PID = "Vid_22EA&Pid_003A";
        internal const string DEF_VID_PID2 = "Mi_03";
        //Constant definitions from setupapi.h, which we aren't allowed to include directly since this is C#
        internal const uint DIGCF_PRESENT = 0x02;
        internal const uint DIGCF_DEVICEINTERFACE = 0x10;
        //Constants for CreateFile() and other file I/O functions
        internal const short FILE_ATTRIBUTE_NORMAL = 0x80;
        internal const short INVALID_HANDLE_VALUE = -1;
        internal const uint GENERIC_READ = 0x80000000;
        internal const uint GENERIC_WRITE = 0x40000000;
        internal const uint CREATE_NEW = 1;
        internal const uint CREATE_ALWAYS = 2;
        internal const uint OPEN_EXISTING = 3;
        internal const uint FILE_SHARE_READ = 0x00000001;
        internal const uint FILE_SHARE_WRITE = 0x00000002;
        //Constant definitions for certain WM_DEVICECHANGE messages
        internal const uint WM_DEVICECHANGE = 0x0219;
        internal const uint DBT_DEVICEARRIVAL = 0x8000;
        internal const uint DBT_DEVICEREMOVEPENDING = 0x8003;
        internal const uint DBT_DEVICEREMOVECOMPLETE = 0x8004;
        internal const uint DBT_CONFIGCHANGED = 0x0018;
        //Other constant definitions
        internal const uint DBT_DEVTYP_DEVICEINTERFACE = 0x05;
        internal const uint DEVICE_NOTIFY_WINDOW_HANDLE = 0x00;
        internal const uint ERROR_SUCCESS = 0x00;
        internal const uint ERROR_NO_MORE_ITEMS = 0x00000103;
        internal const uint SPDRP_HARDWAREID = 0x00000001;

        //Various structure definitions for structures that this code will be using
        internal struct SP_DEVICE_INTERFACE_DATA
        {
            internal uint cbSize;               //DWORD
            internal Guid InterfaceClassGuid;   //GUID
            internal uint Flags;                //DWORD
            internal uint Reserved;             //ULONG_PTR MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct SP_DEVICE_INTERFACE_DETAIL_DATA
        {
            internal uint cbSize;               //DWORD
            internal char[] DevicePath;         //TCHAR array of any size
        }
        
        internal struct SP_DEVINFO_DATA
        {
            internal uint cbSize;       //DWORD
            internal Guid ClassGuid;    //GUID
            internal uint DevInst;      //DWORD
            internal uint Reserved;     //ULONG_PTR  MSDN says ULONG_PTR is "typedef unsigned __int3264 ULONG_PTR;"  
        }

        internal struct DEV_BROADCAST_DEVICEINTERFACE
        {
            internal uint dbcc_size;            //DWORD
            internal uint dbcc_devicetype;      //DWORD
            internal uint dbcc_reserved;        //DWORD
            internal Guid dbcc_classguid;       //GUID
            internal char[] dbcc_name;          //TCHAR array
        }

        //internal struct SP_COMMTIMEOUTS
        //{
        //    internal uint ReadIntervalTimeout;
	    //    internal uint ReadTotalTimeoutMultiplier;
	    //    internal uint ReadTotalTimeoutConstant;
	    //    internal uint WriteTotalTimeoutMultiplier;
	    //    internal uint WriteTotalTimeoutConstant;
        //}


        //DLL Imports.  Need these to access various C style unmanaged functions contained in their respective DLL files.
        //--------------------------------------------------------------------------------------------------------------
        //Returns a HDEVINFO type for a device information set.  We will need the 
        //HDEVINFO as in input parameter for calling many of the other SetupDixxx() functions.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr SetupDiGetClassDevs(
            ref Guid ClassGuid,     //LPGUID    Input: Need to supply the class GUID. 
            IntPtr Enumerator,      //PCTSTR    Input: Use NULL here, not important for our purposes
            IntPtr hwndParent,      //HWND      Input: Use NULL here, not important for our purposes
            uint Flags);            //DWORD     Input: Flags describing what kind of filtering to use.

	    //Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
	    //from class GUID).  We need the interface GUID to get the device path.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInterfaces(
            IntPtr DeviceInfoSet,           //Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
            IntPtr DeviceInfoData,          //Input (optional)
            ref Guid InterfaceClassGuid,    //Input 
            uint MemberIndex,               //Input: "Index" of the device you are interested in getting the path for.
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData);    //Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

        //SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiDestroyDeviceInfoList(
            IntPtr DeviceInfoSet);          //Input: Give it a handle to a device info list to deallocate from RAM.

        //SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiEnumDeviceInfo(
            IntPtr DeviceInfoSet,
            uint MemberIndex,
            ref SP_DEVINFO_DATA DeviceInterfaceData);

        //SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceRegistryProperty(
            IntPtr DeviceInfoSet,
            ref SP_DEVINFO_DATA DeviceInfoData,
            uint Property,
            ref uint PropertyRegDataType,
            IntPtr PropertyBuffer,
            uint PropertyBufferSize,
            ref uint RequiredSize);

        //SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,                    //Input: Pointer to an structure which defines the device interface.  
            IntPtr  DeviceInterfaceDetailData,      //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will receive the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            ref uint RequiredSize,                  //Output (optional): The number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Overload for SetupDiGetDeviceInterfaceDetail().  Need this one since we can't pass NULL pointers directly in C#.
        [DllImport("setupapi.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern bool SetupDiGetDeviceInterfaceDetail(
            IntPtr DeviceInfoSet,                   //Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
            ref SP_DEVICE_INTERFACE_DATA DeviceInterfaceData,               //Input: Pointer to an structure which defines the device interface.  
            IntPtr DeviceInterfaceDetailData,       //Output: Pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA structure, which will contain the device path.
            uint DeviceInterfaceDetailDataSize,     //Input: Number of bytes to retrieve.
            IntPtr RequiredSize,                    //Output (optional): Pointer to a DWORD to tell you the number of bytes needed to hold the entire struct 
            IntPtr DeviceInfoData);                 //Output (optional): Pointer to a SP_DEVINFO_DATA structure

        //Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
        //description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
        //avoid possible build error conflicts.
        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        internal static extern IntPtr RegisterDeviceNotification(
            IntPtr hRecipient,
            IntPtr NotificationFilter,
            uint Flags);

        //Takes in a device path and opens a handle to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode, 
            IntPtr lpSecurityAttributes, 
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes, 
            IntPtr hTemplateFile);

        //Uses a handle (created with CreateFile()), and lets us write USB data to the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool WriteFile(
            SafeFileHandle hFile,
            byte[] lpBuffer,
            uint nNumberOfBytesToWrite,
            ref uint lpNumberOfBytesWritten,
            IntPtr lpOverlapped);

        //Uses a handle (created with CreateFile()), and lets us read USB data from the device.
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool ReadFile(
            SafeFileHandle hFile,
            IntPtr lpBuffer,
            uint nNumberOfBytesToRead,
            ref uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);

        //
        //[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        //static extern bool SetCommTimeouts(
        //    SafeFileHandle hFile,
        //    ref SP_COMMTIMEOUTS lpCommTimeouts);


	    //--------------- Global Varibles Section ------------------
	    //USB related variables that need to have wide scope.
	    bool AttachedState = false;						//Need to keep track of the USB device attachment status for proper plug and play operation.
        bool AttachedButBroken = false;
        bool AttachedFirstTime = true;
        bool UnAttachedFirstTime = true;
        SafeFileHandle WriteHandleToUSBDevice = null;
        SafeFileHandle ReadHandleToUSBDevice = null;
        String DevicePath = null;   //Need the find the proper device path before you can open file handles.

        bool b_FlashRead = false;
        bool b_FlashWrite = false;
        bool b_FlashErase = false;
        long l_ReadAddress = -1;
        byte byte_ReadSize = 0;
        byte[] FlashReadData = new byte[64];
        long l_WriteAddress = -1;
        byte byte_WriteSize = 0;
        byte[] FlashWriteData = new byte[64];
        int byte_FlashWrite_Ans = -1;
        long l_EraseAddress = -1;
        int byte_FlashErase_Ans = -1;

        // Ir
        int ir_data_select_no = 0;
        Button[] my_select_button;
        Button[] my_send_button;
        TextBox[] my_memo_textbox;

        // Read
        bool b_ir_read_start_req = false;
        bool b_ir_read_stop_req = false;
        bool b_ir_read_stop_comp = false;
        bool b_ir_read_data_get_req = false;
        bool b_ir_read_data_get_comp = false;
        bool b_ir_reading_flag = false;
        int ir_read_data_rec_buff_no = 0;
        int ir_read_data_get_count = 0;
        int ir_reading_data_get_count = 0;
        int ir_reading_data_get_count_fix = 0;
        int ir_read_data_total_size = 0;
        int[] ir_freq_select_datas = new int[26] { 25000, 26000, 27000, 28000, 29000, 30000, 31000, 32000, 33000, 34000, 35000, 36000, 37000, 38000, 39000, 40000, 41000, 42000, 43000, 44000, 45000, 46000, 47000, 48000, 49000, 50000};
        const int ir_freq_select_default = 38000;
        int ir_read_start_freq = ir_freq_select_default;
        byte ir_read_result_data = 0;
        int reading_redraw_interval = 0;
        // Send
        bool b_ir_send_data_set_req = false;
        int ir_send_data_set_pos = 0;
        int ir_send_data_set_buff_no = 0;
        const int ir_send_data_usb_send_max_size = 14;  // USB���M�P��ő��M����ő吔
        bool b_ir_send_send_req = false;
        int ir_send_send_req_buff_no = 0;
        // Data Buff
        //public const int IR_DATA_BUFF_SIZE = 32000;
        uint[] ir_read_data = new uint[Constants.IR_DATA_BUFF_SIZE];
        // Disp Buff data
        bool b_ir_data_buff_disp_req = false;
        int ir_data_buff_disp_no = 0;

        // IR Data REC
        //public const int IR_DATA_REC_NUM = 32;
        //int[,] ir_data_rec_buff = new int[Constants.IR_DATA_REC_NUM, Constants.IR_DATA_BUFF_SIZE];
        public IR_Remote_Control_Pro.IrData my_Ir_data = new IR_Remote_Control_Pro.IrData(Constants.IR_DATA_REC_NUM, Constants.IR_DATA_BUFF_SIZE);
        
        // timer
        bool timer_set_display_visible = false;
        bool timer_on_flag = false;
        DateTime timer_dt_pre;
        int timer_time_check_next_idx = 0;
        int[] timer_send_idx_buff = new int[Constants.TIMER_SET_SEND_BUFF_MAX];
        int timer_send_idx_buff_w_idx = 0;
        int timer_send_idx_buff_r_idx = 0;
        bool timer_send_idx_buff_full = false;

        public TimerSetInfo aTSI = new TimerSetInfo();

        // IR Data Code Match
        const int IR_DATA_MATCH_OK_RANGE = 5;   // �R�[�h��v���e�͈�

        int[] Debug_Array = new int[15];    //DEBUG
        int[] Debug_Arr2 = new int[15] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        bool b_ir_read_data_get_req_debug = false;


        const string c_APPLICATION_NAME = "USB IR Remote Controller Advance ���M�ݒ� Configuration Tool";
        bool VersionReadReq = true;
        bool VersionReadComp = false;
        byte[] version_buff = new byte[64];




        //Globally Unique Identifier (GUID) for HID class devices.  Windows uses GUIDs to identify things.
        Guid InterfaceClassGuid = new Guid(0x4d1e55b2, 0xf16f, 0x11cf, 0x88, 0xcb, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30); 
	    //--------------- End of Global Varibles ------------------

        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Need to check "Allow unsafe code" checkbox in build properties to use unsafe keyword.  Unsafe is needed to
        //properly interact with the unmanged C++ style APIs used to find and connect with the USB device.
        public unsafe Form1()
        {
            InitializeComponent();

            if (__DEBUG_FLAG__ == false)
            {
                this.Size = new System.Drawing.Size(Constants.FORM_SIZE_X_TIMER_DISPLAY_OFF, Constants.FORM_SIZE_Y_TIMER_DISPLAY_OFF);
            }



            //�������g�̃o�[�W���������擾����
            System.Diagnostics.FileVersionInfo fver = System.Diagnostics.FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetExecutingAssembly().Location);
            this.Text += fver.FileVersion;

            //�R���g���[���z��
            my_select_button = new Button[Constants.IR_DATA_REC_NUM] {  btn_select_No01, btn_select_No02, btn_select_No03, btn_select_No04, btn_select_No05, btn_select_No06, btn_select_No07, btn_select_No08,
                                                                        btn_select_No09, btn_select_No10, btn_select_No11, btn_select_No12, btn_select_No13, btn_select_No14, btn_select_No15, btn_select_No16,
                                                                        btn_select_No17, btn_select_No18, btn_select_No19, btn_select_No20, btn_select_No21, btn_select_No22, btn_select_No23, btn_select_No24,
                                                                        btn_select_No25, btn_select_No26, btn_select_No27, btn_select_No28, btn_select_No29, btn_select_No30, btn_select_No31, btn_select_No32};
            my_send_button = new Button[Constants.IR_DATA_REC_NUM] {    btn_send_No01, btn_send_No02, btn_send_No03, btn_send_No04, btn_send_No05, btn_send_No06, btn_send_No07, btn_send_No08,
                                                                        btn_send_No09, btn_send_No10, btn_send_No11, btn_send_No12, btn_send_No13, btn_send_No14, btn_send_No15, btn_send_No16,
                                                                        btn_send_No17, btn_send_No18, btn_send_No19, btn_send_No20, btn_send_No21, btn_send_No22, btn_send_No23, btn_send_No24,
                                                                        btn_send_No25, btn_send_No26, btn_send_No27, btn_send_No28, btn_send_No29, btn_send_No30, btn_send_No31, btn_send_No32};
            my_memo_textbox = new TextBox[Constants.IR_DATA_REC_NUM] {  txtbx_memo_No01, txtbx_memo_No02, txtbx_memo_No03, txtbx_memo_No04, txtbx_memo_No05, txtbx_memo_No06, txtbx_memo_No07, txtbx_memo_No08,
                                                                        txtbx_memo_No09, txtbx_memo_No10, txtbx_memo_No11, txtbx_memo_No12, txtbx_memo_No13, txtbx_memo_No14, txtbx_memo_No15, txtbx_memo_No16,
                                                                        txtbx_memo_No17, txtbx_memo_No18, txtbx_memo_No19, txtbx_memo_No20, txtbx_memo_No21, txtbx_memo_No22, txtbx_memo_No23, txtbx_memo_No24,
                                                                        txtbx_memo_No25, txtbx_memo_No26, txtbx_memo_No27, txtbx_memo_No28, txtbx_memo_No29, txtbx_memo_No30, txtbx_memo_No31, txtbx_memo_No32};

            int tmp_tabidx = 201;
            for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
            {
                my_select_button[fi].TabIndex = tmp_tabidx++;
                my_select_button[fi].Tag = fi;
                my_select_button[fi].Text = string.Format("No.{0:00}", fi + 1);
                my_send_button[fi].TabIndex = tmp_tabidx++;
                my_send_button[fi].Tag = fi;
                my_memo_textbox[fi].TabIndex = tmp_tabidx++;
                my_memo_textbox[fi].Tag = fi;
                my_memo_textbox[fi].TabStop = false;

                cmbbx_timer_set_no.Items.Add(string.Format("No.{0:00}", fi + 1));
            }
            cmbbx_timer_set_no.SelectedIndex = 0;

            btn_timer_set_display.Text = Constants.TIMER_SET_DISPLAY_BUTTON_ON_TEXT;

            // ���߂Ȃǂ̂��߂ɐe�ݒ�
            gbx_Setting.Parent = this;
            gbx_Setting_list.Parent = this;

            //�@���M�ݒ莞���ƃ^�C�}�[���M�`�F�b�N���Ԃ����ݓ����ɐݒ�
            DateTime tmp_dt_now = DateTime.Now;
            DateTime tmp_dt = new DateTime(tmp_dt_now.Year, tmp_dt_now.Month, tmp_dt_now.Day, tmp_dt_now.Hour, tmp_dt_now.Minute, tmp_dt_now.Second);
            dtp_timer_set_time.Value = tmp_dt;
            timer_dt_pre = tmp_dt;

            //TIMER�����ݒ�t�@�C���ǂݍ���
            string timer_ini_file_path = Path.Combine(System.Environment.CurrentDirectory, Constants.INIT_TIMER_DATA_FILE_NAME);
            int func_ret = my_timer_list_file_read(timer_ini_file_path);
            if (func_ret == 0)
            {
                //aTSI.set_check_all_clear(); // Check Clear
                timer_set_display_visible = aTSI.get_timer_setting_visible();
                timer_on_flag = aTSI.get_timer_setting_enabled();
                my_timer_list_display(aTSI);
                my_btn_timer_onoff_click(timer_on_flag);
            }
            else
            {
            }
            // �^�C�}�ݒ��ʕ\��
            my_timer_setting_display(timer_set_display_visible);


            //�����ݒ�t�@�C���ǂݍ���
            string ini_file_path = Path.Combine( System.Environment.CurrentDirectory, Constants.INIT_DATA_FILE_NAME);
            if (File.Exists(ini_file_path) == true)
            {   // �t�@�C������
                int i_ret = my_File_Read(ini_file_path);

                if (i_ret > 0)
                {
                    my_Ir_data.ir_data_get(0, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);
                    ir_read_data_get_count = ir_read_data_total_size * 2;

                    my_list_data_disp();
                }
            }

            // Select�f�[�^�\��
            my_select_data_disp(ir_data_select_no);


            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
			//Additional constructor code

            //Initialize tool tips, to provide pop up help when the mouse cursor is moved over objects on the form.
            //Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
            DEV_BROADCAST_DEVICEINTERFACE DeviceBroadcastHeader = new DEV_BROADCAST_DEVICEINTERFACE();
            DeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
            DeviceBroadcastHeader.dbcc_size = (uint)Marshal.SizeOf(DeviceBroadcastHeader);
            DeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
            DeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;

            //Need to get the address of the DeviceBroadcastHeader to call RegisterDeviceNotification(), but
            //can't use "&DeviceBroadcastHeader".  Instead, using a roundabout means to get the address by 
            //making a duplicate copy using Marshal.StructureToPtr().
            IntPtr pDeviceBroadcastHeader = IntPtr.Zero;  //Make a pointer.
            pDeviceBroadcastHeader = Marshal.AllocHGlobal(Marshal.SizeOf(DeviceBroadcastHeader)); //allocate memory for a new DEV_BROADCAST_DEVICEINTERFACE structure, and return the address 
            Marshal.StructureToPtr(DeviceBroadcastHeader, pDeviceBroadcastHeader, false);  //Copies the DeviceBroadcastHeader structure into the memory already allocated at DeviceBroadcastHeaderWithPointer
            RegisterDeviceNotification(this.Handle, pDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
			if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
			{
				uint ErrorStatusWrite;
				uint ErrorStatusRead;


				//We now have the proper device path, and we can finally open read and write handles to the device.
                WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

				if((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
				{
					AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
					AttachedButBroken = false;
                    connect_status_lbl.Text = "�ڑ�����܂���";
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState = false;		//Let the rest of this application known not to read/write to the device.
					AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
					if(ErrorStatusWrite == ERROR_SUCCESS)
						WriteHandleToUSBDevice.Close();
					if(ErrorStatusRead == ERROR_SUCCESS)
						ReadHandleToUSBDevice.Close();
				}
			}
			else	//Device must not be connected (or not programmed with correct firmware)
			{
				AttachedState = false;
				AttachedButBroken = false;
			}

            if (AttachedState == true)
            {
                connect_status_lbl.Text = "�ڑ�����܂����B";
            }
            else
            {
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";
            }

			ReadWriteThread.RunWorkerAsync();	//Recommend performing USB read/write operations in a separate thread.  Otherwise,
												//the Read/Write operations are effectively blocking functions and can lock up the
												//user interface if the I/O operations take a long time to complete.

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
        //PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
        //INPUT:	Uses globally declared String DevicePath, globally declared GUID, and the MY_DEVICE_ID constant.
        //OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
        //			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
        //			to the USB device with the matching VID/PID.

        bool CheckIfPresentAndGetUSBDevicePath()
        {
		    /* 
		    Before we can "connect" our application to our USB embedded device, we must first find the device.
		    A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
		    This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
		    a unique combination of VID and PID.  

		    Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
		    for each function used can be found in the MSDN library.  We will be using the following functions (unmanaged C functions):

		    SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
		    SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
		    GetLastError()							//provided by kernel32.dll, which comes with Windows
		    SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
		    SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
		    CreateFile()							//provided by kernel32.dll, which comes with Windows

            In order to call these unmanaged functions, the Marshal class is very useful.
             
		    We will also be using the following unusual data types and structures.  Documentation can also be found in
		    the MSDN library:

		    PSP_DEVICE_INTERFACE_DATA
		    PSP_DEVICE_INTERFACE_DETAIL_DATA
		    SP_DEVINFO_DATA
		    HDEVINFO
		    HANDLE
		    GUID

		    The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
		    read and write handles to the USB device.  Once the read/write handles are opened, only then can this
		    PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

		    Getting the device path is a multi-step round about process, which requires calling several of the
		    SetupDixxx() functions provided by setupapi.dll.
		    */

            try
            {
		        IntPtr DeviceInfoTable = IntPtr.Zero;
		        SP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA();
                SP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA();
                SP_DEVINFO_DATA DevInfoData = new SP_DEVINFO_DATA();

		        uint InterfaceIndex = 0;
		        uint dwRegType = 0;
		        uint dwRegSize = 0;
                uint dwRegSize2 = 0;
		        uint StructureSize = 0;
		        IntPtr PropertyValueBuffer = IntPtr.Zero;
                bool MatchFound = false;
                bool MatchFound2 = false;
		        uint ErrorStatus;
		        uint LoopCounter = 0;

                //Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
                //Make sure the value appearing in the parathesis matches the USB device descriptor
                //of the device that this aplication is intending to find.
                String DeviceIDToFind = DEF_VID_PID;
                String DeviceIDToFind2 = DEF_VID_PID2;

		        //First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
		        DeviceInfoTable = SetupDiGetClassDevs(ref InterfaceClassGuid, IntPtr.Zero, IntPtr.Zero, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

                if(DeviceInfoTable != IntPtr.Zero)
                {
		            //Now look through the list we just populated.  We are trying to see if any of them match our device. 
		            while(true)
		            {
                        InterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(InterfaceDataStructure);
			            if(SetupDiEnumDeviceInterfaces(DeviceInfoTable, IntPtr.Zero, ref InterfaceClassGuid, InterfaceIndex, ref InterfaceDataStructure))
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
                            if (ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
				            {	//Cound not find the device.  Must not have been attached.
					            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
					            return false;		
				            }
			            }
			            else	//Else some other kind of unknown error ocurred...
			            {
                            ErrorStatus = (uint)Marshal.GetLastWin32Error();
				            SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
				            return false;	
			            }

			            //Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
			            //check to see if it is the correct device or not.

			            //Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
                        DevInfoData.cbSize = (uint)Marshal.SizeOf(DevInfoData);
			            SetupDiEnumDeviceInfo(DeviceInfoTable, InterfaceIndex, ref DevInfoData);

			            //First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
			            SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, IntPtr.Zero, 0, ref dwRegSize);

			            //Allocate a buffer for the hardware ID.
                        //Should normally work, but could throw exception "OutOfMemoryException" if not enough resources available.
                        PropertyValueBuffer = Marshal.AllocHGlobal((int)dwRegSize);

			            //Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
			            //REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
			            //buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
			            //format "Vid_04d8&Pid_003f".
                        SetupDiGetDeviceRegistryProperty(DeviceInfoTable, ref DevInfoData, SPDRP_HARDWAREID, ref dwRegType, PropertyValueBuffer, dwRegSize, ref dwRegSize2);

			            //Now check if the first string in the hardware ID matches the device ID of the USB device we are trying to find.
			            String DeviceIDFromRegistry = Marshal.PtrToStringUni(PropertyValueBuffer); //Make a new string, fill it with the contents from the PropertyValueBuffer

			            Marshal.FreeHGlobal(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

			            //Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
			            DeviceIDFromRegistry = DeviceIDFromRegistry.ToLowerInvariant();
                        DeviceIDToFind = DeviceIDToFind.ToLowerInvariant();
                        DeviceIDToFind2 = DeviceIDToFind2.ToLowerInvariant();
			            //Now check if the hardware ID we are looking at contains the correct VID/PID
                        MatchFound = DeviceIDFromRegistry.Contains(DeviceIDToFind);
                        MatchFound2 = DeviceIDFromRegistry.Contains(DeviceIDToFind2);
                        if (MatchFound == true && MatchFound2 == true)
			            {
                            //Device must have been found.  In order to open I/O file handle(s), we will need the actual device path first.
				            //We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
				            //time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
				            //get the structure (after we have allocated enough memory for the structure.)
                            DetailedInterfaceDataStructure.cbSize = (uint)Marshal.SizeOf(DetailedInterfaceDataStructure);
				            //First call populates "StructureSize" with the correct value
				            SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, IntPtr.Zero, 0, ref StructureSize, IntPtr.Zero);
                            //Need to call SetupDiGetDeviceInterfaceDetail() again, this time specifying a pointer to a SP_DEVICE_INTERFACE_DETAIL_DATA buffer with the correct size of RAM allocated.
                            //First need to allocate the unmanaged buffer and get a pointer to it.
                            IntPtr pUnmanagedDetailedInterfaceDataStructure = IntPtr.Zero;  //Declare a pointer.
                            pUnmanagedDetailedInterfaceDataStructure = Marshal.AllocHGlobal((int)StructureSize);    //Reserve some unmanaged memory for the structure.
                            DetailedInterfaceDataStructure.cbSize = 6; //Initialize the cbSize parameter (4 bytes for DWORD + 2 bytes for unicode null terminator)
                            Marshal.StructureToPtr(DetailedInterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, false); //Copy managed structure contents into the unmanaged memory buffer.

                            //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the device path in the structure at pUnmanagedDetailedInterfaceDataStructure.
                            if (SetupDiGetDeviceInterfaceDetail(DeviceInfoTable, ref InterfaceDataStructure, pUnmanagedDetailedInterfaceDataStructure, StructureSize, IntPtr.Zero, IntPtr.Zero))
                            {
                                //Need to extract the path information from the unmanaged "structure".  The path starts at (pUnmanagedDetailedInterfaceDataStructure + sizeof(DWORD)).
                                IntPtr pToDevicePath = new IntPtr((uint)pUnmanagedDetailedInterfaceDataStructure.ToInt32() + 4);  //Add 4 to the pointer (to get the pointer to point to the path, instead of the DWORD cbSize parameter)
                                DevicePath = Marshal.PtrToStringUni(pToDevicePath); //Now copy the path information into the globally defined DevicePath String.
                                
                                //We now have the proper device path, and we can finally use the path to open I/O handle(s) to the device.
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure we no longer need.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return true;    //Returning the device path in the global DevicePath String
                            }
                            else //Some unknown failure occurred
                            {
                                uint ErrorCode = (uint)Marshal.GetLastWin32Error();
                                SetupDiDestroyDeviceInfoList(DeviceInfoTable);	//Clean up the old structure.
                                Marshal.FreeHGlobal(pUnmanagedDetailedInterfaceDataStructure);  //No longer need this unmanaged SP_DEVICE_INTERFACE_DETAIL_DATA buffer.  We already extracted the path information.
                                return false;    
                            }
                        }

			            InterfaceIndex++;	
			            //Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
			            //However, just in case some unexpected error occurs, keep track of the number of loops executed.
			            //If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
			            LoopCounter++;
			            if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
			            {
				            return false;
			            }
		            }//end of while(true)
                }
                return false;
            }//end of try
            catch
            {
                //Something went wrong if PC gets here.  Maybe a Marshal.AllocHGlobal() failed due to insufficient resources or something.
			    return false;	
            }
        }
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
        //This is a callback function that gets called when a Windows message is received by the form.
        //We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_DEVICECHANGE)
            {
                if (((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED))
                {
                    //WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
                    //sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
                    //to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
                    //(the message could have been totally unrelated to your application/USB device)

                    if (CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
                    {
                        //If executes to here, this means the device is currently attached and was found.
                        //This code needs to decide however what to do, based on whether or not the device was previously known to be
                        //attached or not.
                        if ((AttachedState == false) || (AttachedButBroken == true))	//Check the previous attachment state
                        {
                            uint ErrorStatusWrite;
                            uint ErrorStatusRead;

                            //We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
                            //is now possible to open read and write handles to the device.
                            WriteHandleToUSBDevice = CreateFile(DevicePath, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusWrite = (uint)Marshal.GetLastWin32Error();
                            ReadHandleToUSBDevice = CreateFile(DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, IntPtr.Zero, OPEN_EXISTING, 0, IntPtr.Zero);
                            ErrorStatusRead = (uint)Marshal.GetLastWin32Error();

                            if ((ErrorStatusWrite == ERROR_SUCCESS) && (ErrorStatusRead == ERROR_SUCCESS))
                            {
                                AttachedState = true;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
                                AttachedButBroken = false;
                                connect_status_lbl.Text = "�ڑ�����܂����B";

                            }
                            else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
                            {
                                AttachedState = false;		//Let the rest of this application known not to read/write to the device.
                                AttachedButBroken = true;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
                                if (ErrorStatusWrite == ERROR_SUCCESS)
                                    WriteHandleToUSBDevice.Close();
                                if (ErrorStatusRead == ERROR_SUCCESS)
                                    ReadHandleToUSBDevice.Close();
                            }
                        }
                        //else we did find the device, but AttachedState was already true.  In this case, don't do anything to the read/write handles,
                        //since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
                    }
                    else	//Device must not be connected (or not programmed with correct firmware)
                    {
                        if (AttachedState == true)		//If it is currently set to true, that means the device was just now disconnected
                        {
                            AttachedState = false;
                            WriteHandleToUSBDevice.Close();
                            ReadHandleToUSBDevice.Close();
                        }
                        AttachedState = false;
                        AttachedButBroken = false;
                    }
                }
            } //end of: if(m.Msg == WM_DEVICECHANGE)

            base.WndProc(ref m);
        } //end of: WndProc() function
        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void ReadWriteThread_DoWork(object sender, DoWorkEventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

            /*This thread does the actual USB read/write operations (but only when AttachedState == true) to the USB device.
            It is generally preferrable to write applications so that read and write operations are handled in a separate
            thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
            take a very long time to complete.

            Since this is a separate thread, this code below executes independently from the rest of the
            code in this application.  All this thread does is read and write to the USB device.  It does not update
            the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
            The information that this thread obtains is stored in atomic global variables.
            Form updates are handled by the FormUpdateTimer Tick event handler function.

            This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
            This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
            Both of these functions are documented in the MSDN library.  Calling ReadFile() is a not perfectly straight
            foward in C# environment, since one of the input parameters is a pointer to a buffer that gets filled by ReadFile().
            The ReadFile() function is therefore called through a wrapper function ReadFileManagedBuffer().

            All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
            calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
            the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
            asynchronous I/O function calls.  

            Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
            USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
            when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
            the issue described in Microsoft knowledge base article 940021:
            http://support.microsoft.com/kb/940021/en-us 

            Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
            directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
            write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
            WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
            for some USB operations and the source code can be used	as an example.*/


            Byte[] OUTBuffer = new byte[65];	//Allocate a memory buffer equal to the OUT endpoint size + 1
		    Byte[] INBuffer = new byte[65];		//Allocate a memory buffer equal to the IN endpoint size + 1
		    uint BytesWritten = 0;
            uint BytesRead = 0;
            bool b_usb_write_ret = false;

		    while(true)
		    {
                try
                {
                    if (AttachedState == true)	//Do not try to use the read/write handles unless the USB device is attached and ready
                    {

                        /* Flash Read */
                        if (b_FlashRead == true)
                        {
                            b_FlashRead = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x11;		//0x21 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_ReadAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_ReadAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_ReadAddress >> 8) & 0xFF);		//
                            OUTBuffer[5] = (byte)(l_ReadAddress & 0xFF);		    //
                            OUTBuffer[6] = byte_ReadSize;		            //Size

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x11)
                                        {
                                            if (INBuffer[2] == byte_ReadSize)
                                            {
                                                // OK
                                                FlashReadData[0] = INBuffer[2];
                                                for (int fi = 0; fi < INBuffer[2]; fi++)
                                                {
                                                    FlashReadData[1 + fi] = INBuffer[3 + fi];
                                                }
                                            }
                                            else
                                            {
                                                // NG
                                                FlashReadData[0] = INBuffer[2];
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        /* Flash Write */
                        if (b_FlashWrite == true)
                        {
                            b_FlashWrite = false;
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x12;		//0x22 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_WriteAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_WriteAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_WriteAddress >> 8) & 0xFF);		    //
                            OUTBuffer[5] = (byte)(l_WriteAddress & 0xFF);		        //
                            OUTBuffer[6] = byte_WriteSize;		                           //Size
                            for (uint i = 0; i < byte_WriteSize; i++)
                            {
                                OUTBuffer[7 + i] = FlashWriteData[i];
                            }

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x12)
                                        {
                                            //ANS
                                            byte_FlashWrite_Ans = INBuffer[2];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        /* Flash Erase */
                        if (b_FlashErase == true)
                        {
                            b_FlashErase = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x13;		//0x22 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((l_EraseAddress >> 24) & 0xFF);		//Address
                            OUTBuffer[3] = (byte)((l_EraseAddress >> 16) & 0xFF);		//
                            OUTBuffer[4] = (byte)((l_EraseAddress >> 8) & 0xFF);		    //
                            OUTBuffer[5] = (byte)(l_EraseAddress & 0xFF);		        //

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            b_usb_write_ret = WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero);
                            if (b_usb_write_ret == true)	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x13)
                                        {
                                            //ANS
                                            byte_FlashErase_Ans = INBuffer[2];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }


                        //VersionReadReq = false;
                        if (VersionReadReq == true)
                        {
                            VersionReadReq = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x56;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x56)
                                        {
                                            for (uint i = 2; i < 65; i++)
                                            {
                                                version_buff[i - 2] = INBuffer[i];
                                            }
                                            VersionReadComp = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }

                        // IR�ǂݍ��݊J�n
                        if (b_ir_read_start_req == true)
                        {
                            b_ir_read_start_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x31;		//0x81 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)((ir_read_start_freq >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)(ir_read_start_freq & 0xFF);
                            OUTBuffer[4] = 0;   // �ǂݍ��ݒ�~�t���O�@��~�Ȃ�
                            OUTBuffer[5] = 0;   // �ǂݍ��ݒ�~ON����MSB
                            OUTBuffer[6] = 0;   // �ǂݍ��ݒ�~ON����LSB
                            OUTBuffer[7] = 0;   // �ǂݍ��ݒ�~OFF����MSB
                            OUTBuffer[8] = 0;   // �ǂݍ��ݒ�~OFF����LSB

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x31)
                                        {
                                            ir_reading_data_get_count = 0;
                                            ir_reading_data_get_count_fix = 0;
                                            b_ir_reading_flag = true;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��ݏI��
                        if (b_ir_read_stop_req == true)
                        {
                            b_ir_read_stop_req = false;
                            b_ir_reading_flag = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x32;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x32)
                                        {
                                            ir_read_result_data = INBuffer[2];
                                            b_ir_read_stop_comp = true;

                                            // �ǂݍ��ݐ���I�����́A�f�[�^�擾�v��������
                                            if (ir_read_result_data == 0x00)
                                            {
                                                b_ir_read_data_get_req = true;
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��݃f�[�^�擾
                        if (b_ir_read_data_get_req == true)
                        {
                            //b_ir_read_data_get_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x33;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x33)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && tmp_total_size >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++ )
                                                {
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_read_data_get_count++;
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_read_data_get_count++;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_read_data_total_size = tmp_total_size;
                                                b_ir_read_data_get_req = false;
                                                b_ir_read_data_get_comp = true;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��ݒ��f�[�^�擾
                        if (b_ir_reading_flag == true)
                        {
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x37;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x37)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && tmp_total_size >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++)
                                                {
                                                    ir_read_data[ir_reading_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_reading_data_get_count] = (ir_read_data[ir_reading_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_reading_data_get_count++;
                                                    ir_read_data[ir_reading_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_reading_data_get_count] = (ir_read_data[ir_reading_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_reading_data_get_count++;
                                                }

                                                if (tmp_total_size == (tmp_start_pos + tmp_read_size))
                                                {
                                                    ir_reading_data_get_count_fix = ir_reading_data_get_count;
                                                    ir_reading_data_get_count = 0;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_reading_data_get_count_fix = ir_reading_data_get_count;
                                                ir_reading_data_get_count = 0;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }

                        // IR���M�f�[�^����
                        if (b_ir_send_data_set_req == true
                            || timer_send_idx_buff_w_idx != timer_send_idx_buff_r_idx || timer_send_idx_buff_full == true)
                        {
                            // ���M��ԃ`�F�b�N
                            byte send_starus = 0xFF;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x38;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x38)
                                        {
                                            //send_starus = INBuffer[2];
                                            send_starus = INBuffer[3];
                                            //send_starus = INBuffer[4];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }

                            // �����M���
                            if(send_starus == 0)
                            {
                                if(b_ir_send_data_set_req == true)
                                {
                                    b_ir_send_data_set_req = false;

                                    for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                    {
                                        OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                    }

                                    // �ԊO�����M�f�[�^���Z�b�g
                                    while (true)
                                    {
                                        OUTBuffer[0] = 0;
                                        OUTBuffer[1] = 0x34;

                                        OUTBuffer[2] = (byte)((my_Ir_data.ir_data_size[ir_send_data_set_buff_no] >> 8) & 0xFF);
                                        OUTBuffer[3] = (byte)(my_Ir_data.ir_data_size[ir_send_data_set_buff_no] & 0xFF);
                                        OUTBuffer[4] = (byte)((ir_send_data_set_pos >> 8) & 0xFF);
                                        OUTBuffer[5] = (byte)(ir_send_data_set_pos & 0xFF);

                                        int set_data_size = my_Ir_data.ir_data_size[ir_send_data_set_buff_no] - ir_send_data_set_pos;
                                        if (set_data_size > ir_send_data_usb_send_max_size)
                                        {
                                            set_data_size = ir_send_data_usb_send_max_size;
                                        }
                                        else if (set_data_size < 0)
                                        {
                                            set_data_size = 0;
                                        }
                                        OUTBuffer[6] = (byte)(set_data_size & 0xFF);

                                        if (0 < set_data_size)
                                        {
                                            for (int fi = 0; fi < set_data_size; fi++)
                                            {
                                                int get_pos = ir_send_data_set_pos * 2;

                                                // ON Count
                                                OUTBuffer[7 + (fi * 4)] = (byte)((my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                                OUTBuffer[7 + (fi * 4) + 1] = (byte)(my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos++] & 0xFF);
                                                // OFF Count
                                                OUTBuffer[7 + (fi * 4) + 2] = (byte)((my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                                OUTBuffer[7 + (fi * 4) + 3] = (byte)(my_Ir_data.ir_data_rec_buff[ir_send_data_set_buff_no, get_pos++] & 0xFF); ;
                                                ir_send_data_set_pos++;
                                            }

                                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                            {
                                                //Now get the response packet from the firmware.
                                                INBuffer[0] = 0;
                                                {
                                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                    {
                                                        //INBuffer[0] is the report ID, which we don't care about.
                                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                        if (INBuffer[1] == 0x34)
                                                        {
                                                            if (INBuffer[2] == 0x00)
                                                            {   // OK
                                                            }
                                                            else
                                                            {
                                                                // NG
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                    }
                                                }
                                            }
                                            else
                                            {
                                            }
                                        }
                                        else
                                        {   // ���M�f�[�^�Ȃ�
                                            break;
                                        }
                                    }

                                    // �ԊO�����M�v�����Z�b�g
                                    b_ir_send_send_req = true;
                                    ir_send_send_req_buff_no = ir_send_data_set_buff_no;
                                }
                                else if (timer_send_idx_buff_w_idx != timer_send_idx_buff_r_idx || timer_send_idx_buff_full == true)
                                {
                                    int timer_ir_send_data_set_pos = 0;
                                    int timer_ir_send_data_set_buff_no = timer_send_idx_buff[timer_send_idx_buff_r_idx];

                                    if (0 <= timer_ir_send_data_set_buff_no && timer_ir_send_data_set_buff_no < Constants.IR_DATA_REC_NUM)
                                    {
                                        for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                                        {
                                            OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                                        }

                                        // �ԊO�����M�f�[�^���Z�b�g
                                        while (true)
                                        {
                                            OUTBuffer[0] = 0;
                                            OUTBuffer[1] = 0x34;

                                            OUTBuffer[2] = (byte)((my_Ir_data.ir_data_size[timer_ir_send_data_set_buff_no] >> 8) & 0xFF);
                                            OUTBuffer[3] = (byte)(my_Ir_data.ir_data_size[timer_ir_send_data_set_buff_no] & 0xFF);
                                            OUTBuffer[4] = (byte)((timer_ir_send_data_set_pos >> 8) & 0xFF);
                                            OUTBuffer[5] = (byte)(timer_ir_send_data_set_pos & 0xFF);

                                            int set_data_size = my_Ir_data.ir_data_size[timer_ir_send_data_set_buff_no] - timer_ir_send_data_set_pos;
                                            if (set_data_size > ir_send_data_usb_send_max_size)
                                            {
                                                set_data_size = ir_send_data_usb_send_max_size;
                                            }
                                            else if (set_data_size < 0)
                                            {
                                                set_data_size = 0;
                                            }
                                            OUTBuffer[6] = (byte)(set_data_size & 0xFF);

                                            if (0 < set_data_size)
                                            {
                                                for (int fi = 0; fi < set_data_size; fi++)
                                                {
                                                    int get_pos = timer_ir_send_data_set_pos * 2;

                                                    // ON Count
                                                    OUTBuffer[7 + (fi * 4)] = (byte)((my_Ir_data.ir_data_rec_buff[timer_ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                                    OUTBuffer[7 + (fi * 4) + 1] = (byte)(my_Ir_data.ir_data_rec_buff[timer_ir_send_data_set_buff_no, get_pos++] & 0xFF);
                                                    // OFF Count
                                                    OUTBuffer[7 + (fi * 4) + 2] = (byte)((my_Ir_data.ir_data_rec_buff[timer_ir_send_data_set_buff_no, get_pos] >> 8) & 0xFF);
                                                    OUTBuffer[7 + (fi * 4) + 3] = (byte)(my_Ir_data.ir_data_rec_buff[timer_ir_send_data_set_buff_no, get_pos++] & 0xFF); ;
                                                    timer_ir_send_data_set_pos++;
                                                }

                                                //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                                                if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                {
                                                    //Now get the response packet from the firmware.
                                                    INBuffer[0] = 0;
                                                    {
                                                        if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                                        {
                                                            //INBuffer[0] is the report ID, which we don't care about.
                                                            //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                                            //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                                            if (INBuffer[1] == 0x34)
                                                            {
                                                                if (INBuffer[2] == 0x00)
                                                                {   // OK
                                                                }
                                                                else
                                                                {
                                                                    // NG
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                }
                                            }
                                            else
                                            {   // ���M�f�[�^�Ȃ�
                                                break;
                                            }
                                        }

                                        // �ԊO�����M�v�����Z�b�g
                                        b_ir_send_send_req = true;
                                        ir_send_send_req_buff_no = timer_ir_send_data_set_buff_no;
                                    }

                                    timer_send_idx_buff_r_idx++;
                                    timer_send_idx_buff_r_idx &= (Constants.TIMER_SET_SEND_BUFF_MAX - 1);
                                    timer_send_idx_buff_full = false;
                                }
                            }
                        }


                        // IR���M�v���Z�b�g
                        if (b_ir_send_send_req == true)
                        {
                            b_ir_send_send_req = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;
                            OUTBuffer[1] = 0x35;
                            OUTBuffer[2] = (byte)((my_Ir_data.ir_freq[ir_send_send_req_buff_no] >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)(my_Ir_data.ir_freq[ir_send_send_req_buff_no] & 0xFF);
                            OUTBuffer[4] = (byte)((my_Ir_data.ir_data_size[ir_send_send_req_buff_no] >> 8) & 0xFF);
                            OUTBuffer[5] = (byte)(my_Ir_data.ir_data_size[ir_send_send_req_buff_no] & 0xFF);

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x35)
                                        {
                                            if (INBuffer[2] == 0x00)
                                            {   // OK
                                            }
                                            else
                                            {
                                                // NG
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }
                        // IR�ǂݍ��݃f�[�^�擾(�f�o�b�O)
                        if (b_ir_read_data_get_req_debug == true)
                        {
                            //b_ir_read_data_get_req_debug = false;

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x36;		//0x81 is the "Get Pushbutton State" command in the firmware
                            OUTBuffer[2] = (byte)(((ir_read_data_get_count / 2) >> 8) & 0xFF);
                            OUTBuffer[3] = (byte)((ir_read_data_get_count / 2) & 0xFF);
                            OUTBuffer[4] = 14;

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x36)
                                        {
                                            int tmp_total_size = 0;
                                            int tmp_start_pos = 0;
                                            byte tmp_read_size = 0;
                                            tmp_total_size = INBuffer[2];
                                            tmp_total_size = (tmp_total_size << 8) | INBuffer[3];
                                            tmp_start_pos = INBuffer[4];
                                            tmp_start_pos = (tmp_start_pos << 8) | INBuffer[5];
                                            tmp_read_size = INBuffer[6];

                                            if (tmp_total_size > 0 && ir_read_data.Length >= (tmp_start_pos + tmp_read_size) && tmp_read_size > 0 && tmp_total_size > tmp_start_pos)
                                            {
                                                for (int fi = 0; fi < tmp_read_size; fi++)
                                                {
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[7 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[8 + fi * 4];
                                                    ir_read_data_get_count++;
                                                    ir_read_data[ir_read_data_get_count] = INBuffer[9 + fi * 4];
                                                    ir_read_data[ir_read_data_get_count] = (ir_read_data[ir_read_data_get_count] << 8) | INBuffer[10 + fi * 4];
                                                    ir_read_data_get_count++;
                                                }
                                            }
                                            else
                                            {   // �ǂݍ��ݏI��
                                                ir_read_data_total_size = tmp_total_size;
                                                b_ir_read_data_get_req_debug = false;
                                                b_ir_read_data_get_comp = true;
                                            }



                                        }
                                    }
                                }
                            }
                            else
                            {
                                AttachedState = false;
                            }
                        }


#pragma warning disable 0162
                        //DEBUG DEBUG DEBUG *****************************************************************************************************
                        if (__DEBUG_FLAG__ == true)
                        {
                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }

                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x40;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x40)
                                        {
                                            Debug_Array[0] = (int)(INBuffer[2]);
                                            Debug_Array[1] = (int)(INBuffer[3]);
                                            Debug_Array[2] = (int)(INBuffer[4]);
                                            Debug_Array[3] = (int)(INBuffer[5]);
                                            Debug_Array[4] = (int)(INBuffer[6]);
                                            Debug_Array[5] = (int)(INBuffer[7]);
                                            Debug_Array[6] = (int)(INBuffer[8]);
                                            Debug_Array[7] = (int)(INBuffer[9]);
                                            Debug_Array[8] = (int)(INBuffer[10]);
                                            Debug_Array[9] = (int)(INBuffer[11]);
                                            Debug_Array[10] = (int)(INBuffer[12]);
                                            Debug_Array[11] = (int)(INBuffer[13]);
                                            Debug_Array[12] = (int)(INBuffer[14]);
                                            Debug_Array[13] = (int)(INBuffer[15]);
                                            Debug_Array[14] = (int)(INBuffer[16]);
                                            //Debug_3++;
                                        }
                                    }
                                }
                            }

                            for (uint i = 0; i < 65; i++)	//This loop is not strictly necessary.  Simply initializes unused bytes to
                            {
                                OUTBuffer[i] = 0xFF;				//0xFF for lower EMI and power consumption when driving the USB cable.
                            }
                            //Get the pushbutton state from the microcontroller firmware.
                            OUTBuffer[0] = 0;			//The first byte is the "Report ID" and does not get sent over the USB bus.  Always set = 0.
                            OUTBuffer[1] = 0x41;		//0x81 is the "Get Pushbutton State" command in the firmware

                            //To get the pushbutton state, first, we send a packet with our "Get Pushbutton State" command in it.
                            if (WriteFile(WriteHandleToUSBDevice, OUTBuffer, 65, ref BytesWritten, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                            {
                                //Now get the response packet from the firmware.
                                INBuffer[0] = 0;
                                {
                                    if (ReadFileManagedBuffer(ReadHandleToUSBDevice, INBuffer, 65, ref BytesRead, IntPtr.Zero))	//Blocking function, unless an "overlapped" structure is used
                                    {
                                        //INBuffer[0] is the report ID, which we don't care about.
                                        //INBuffer[1] is an echo back of the command (see microcontroller firmware).
                                        //INBuffer[2] contains the I/O port pin value for the pushbutton (see microcontroller firmware).  
                                        if (INBuffer[1] == 0x41)
                                        {
                                            Debug_Arr2[0] = (int)(INBuffer[2]);
                                            Debug_Arr2[1] = (int)(INBuffer[3]);
                                            Debug_Arr2[2] = (int)(INBuffer[4]);
                                            Debug_Arr2[3] = (int)(INBuffer[5]);
                                            Debug_Arr2[4] = (int)(INBuffer[6]);
                                            Debug_Arr2[5] = (int)(INBuffer[7]);
                                            Debug_Arr2[6] = (int)(INBuffer[8]);
                                            Debug_Arr2[7] = (int)(INBuffer[9]);
                                            Debug_Arr2[8] = (int)(INBuffer[10]);
                                            Debug_Arr2[9] = (int)(INBuffer[11]);
                                            Debug_Arr2[10] = (int)(INBuffer[12]);
                                            Debug_Arr2[11] = (int)(INBuffer[13]);
                                            Debug_Arr2[12] = (int)(INBuffer[14]);
                                            Debug_Arr2[13] = (int)(INBuffer[15]);
                                            Debug_Arr2[14] = (int)(INBuffer[16]);
                                        }
                                    }
                                }
                            }
                        }
                        //DEBUG DEBUG DEBUG *****************************************************************************************************
#pragma warning restore 0162
                        Thread.Sleep(1);
                    } //end of: if(AttachedState == true)
                    else
                    {
                        Thread.Sleep(5);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
                                            //high CPU utilization, with no particular benefit to the application.
                    }
                }
                catch
                {
                    //Exceptions can occur during the read or write operations.  For example,
                    //exceptions may occur if for instance the USB device is physically unplugged
                    //from the host while the above read/write functions are executing.

                    //Don't need to do anything special in this case.  The application will automatically
                    //re-establish communications based on the global AttachedState boolean variable used
                    //in conjunction with the WM_DEVICECHANGE messages to dyanmically respond to Plug and Play
                    //USB connection events.
                }

		    } //end of while(true) loop
            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }



        private void FormUpdateTimer_Tick(object sender, EventArgs e)
        {
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
            //This timer tick event handler function is used to update the user interface on the form, based on data
            //obtained asynchronously by the ReadWriteThread and the WM_DEVICECHANGE event handler functions.
            

            //Check if user interface on the form should be enabled or not, based on the attachment state of the USB device.
            if (AttachedState == true)
            {
                //Device is connected and ready to communicate, enable user interface on the form 
                connect_status_lbl.Text = "�ڑ�����܂����B";

                UnAttachedFirstTime = true;
            }
            if ((AttachedState == false) || (AttachedButBroken == true))
            {
                //Device not available to communicate. Disable user interface on the form.
                connect_status_lbl.Text = "�ڑ�����Ă��܂���B";

                AttachedFirstTime = true;

                // �o�[�W�����ǂݍ��ݗv����ݒ�
                VersionReadReq = true;
                VersionReadComp = false;

                if (UnAttachedFirstTime == true)
                {
                    UnAttachedFirstTime = false;

                    btn_ir_read_start.Enabled = false;
                    btn_ir_read_stop.Enabled = false;

                    my_timer_onoff_btn_set(false);

                    gbx_Setting.Enabled = false;
                    gbx_Setting_list.Enabled = false;
                    gbx_timer_setting.Enabled = false;
                }
            }

            //Update the various status indicators on the form with the latest info obtained from the ReadWriteThread()
            if (AttachedState == true)
            {

                if (AttachedFirstTime == true)
                {
                    AttachedFirstTime = false;

                    btn_ir_read_start.Enabled = true;
                    btn_ir_read_stop.Enabled = false;

                    gbx_Setting.Enabled = true;
                    gbx_Setting_list.Enabled = true;
                    gbx_timer_setting.Enabled = true;
                }

                // �t�@�[���E�F�A�o�[�W�����\��
                if (VersionReadComp == true)
                {
                    VersionReadComp = false;

                    lbl_FW_Version.Text = "FW Version " + Encoding.Default.GetString(version_buff);
                }

                // �ǂݍ��݌���
                if (b_ir_read_stop_comp == true)
                {
                    b_ir_read_stop_comp = false;
                    lbl_ir_read_result.Text = ir_read_result_data.ToString();
                }
                // �ǂݍ��݃f�[�^�\��
                if (b_ir_read_data_get_comp == true || b_ir_data_buff_disp_req == true || b_ir_reading_flag == true)
                {
                    string read_data_header = "";
                    read_data_header = "       ";
                    int const_1line_num = 16;
                    int line_data_count = 0;
                    int line_count = 1;
                    for (int fi = 0; fi < const_1line_num; fi++)
                    {
                        read_data_header += string.Format("{0:X4} ", fi);
                    }
                    read_data_header += "\n";

                    if (b_ir_read_data_get_comp == true)
                    {   // �ǂݍ��݃f�[�^�̕\��
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < ir_read_data_get_count; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", ir_read_data[fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                        lbl_ir_read_size.Text = "�ǂݍ��݃T�C�Y:" + ir_read_data_total_size.ToString() + "bits (" + string.Format("{0}", ir_read_data_total_size * 4) + "byte) : Freq=" + ir_read_start_freq.ToString() + "Hz";
                        //// �ۑ��o�b�t�@�ɂ��R�s�[
                        //my_Ir_data.ir_data_set(ir_read_data_rec_buff_no, ir_read_start_freq, ir_read_data_total_size, ir_read_data);
                    }
                    else if (b_ir_data_buff_disp_req == true)
                    {   // �o�b�t�@�̃f�[�^��\��
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < my_Ir_data.ir_data_size[ir_data_buff_disp_no]*2; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", my_Ir_data.ir_data_rec_buff[ir_data_buff_disp_no,fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                        lbl_ir_read_size.Text = "" + my_Ir_data.ir_data_size[ir_data_buff_disp_no].ToString() + "bits (" + string.Format("{0}", my_Ir_data.ir_data_size[ir_data_buff_disp_no] * 4) + "byte) : Freq=" + my_Ir_data.ir_freq[ir_data_buff_disp_no].ToString() + "Hz";
                    }
                    else if (b_ir_reading_flag == true)
                    {   // �ǂݍ��ݒ��f�[�^�̕\��
                        reading_redraw_interval++;
                        if (reading_redraw_interval >= 40)
                        {
                            reading_redraw_interval = 0;

                            rtxtbx_ir_read_data.Text = read_data_header;
                            for (int fi = 0; fi < ir_reading_data_get_count_fix; fi++)
                            {
                                if (line_data_count == 0)
                                {
                                    line_data_count = 0;
                                    rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                    line_count++;
                                }

                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", ir_read_data[fi]);

                                line_data_count++;
                                if (line_data_count >= const_1line_num)
                                {
                                    line_data_count = 0;
                                    rtxtbx_ir_read_data.Text += "\n";
                                }
                            }
                            lbl_ir_read_size.Text = "�ǂݍ��݃T�C�Y:" + ir_read_data_total_size.ToString() + "bits (" + string.Format("{0}", ir_read_data_total_size * 4) + "byte)";
                        }
                    }

                    b_ir_read_data_get_comp = false;
                    b_ir_data_buff_disp_req = false;
                }

                // �^�C�}�[���M�`�F�b�N
                if (timer_on_flag == true)
                {   // �^�C�}�[�ݒ蒆

                    //���ݎ����擾
                    DateTime timer_dt_now = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

                    if (timer_dt_pre.CompareTo(timer_dt_now) != 0)
                    {   // �O�������玞���ω�����

                        TimeSpan ts_now = new TimeSpan(timer_dt_now.Hour, timer_dt_now.Minute, timer_dt_now.Second);
                        // �^�C�}�[���M�����ƈ�v���Ă��邩�`�F�b�N
                        // ��v���Ă����瑗�M�o�b�t�@�ɃC���f�b�N�X��ۑ�
                        for (int fi = 0; fi < aTSI.timer_item_num; fi++)
                        {
                            DateTime dt_temp = (DateTime)aTSI.send_time[timer_time_check_next_idx];
                            TimeSpan ts_temp = new TimeSpan(dt_temp.Hour, dt_temp.Minute, dt_temp.Second);
                            if (ts_now.CompareTo(ts_temp) == 0)
                            {   // ���M�����ƈ�v�@�����`�F�b�N
                                if (timer_send_idx_buff_full == false)
                                {
                                    timer_send_idx_buff[timer_send_idx_buff_w_idx++] = (int)aTSI.send_data_no[timer_time_check_next_idx];

                                    timer_send_idx_buff_w_idx &= (Constants.TIMER_SET_SEND_BUFF_MAX - 1);
                                    if (timer_send_idx_buff_w_idx == timer_send_idx_buff_r_idx)
                                    {
                                        timer_send_idx_buff_full = true;
                                    }
                                }

                                timer_time_check_next_idx++;
                                if (timer_time_check_next_idx >= aTSI.timer_item_num)
                                {
                                    timer_time_check_next_idx = 0;
                                }
                                dgv_timer_set_list.CurrentCell = dgv_timer_set_list[0, timer_time_check_next_idx];
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    timer_dt_pre = timer_dt_now;
                }



                //DEBUG
                string debug_str = "";
                colum_lbl.Text = string.Format("{0:000} : {1:000} : {2:000} : {3:000} : {4:000} : {5:000} : {6:000} : {7:000} : {8:000} : {9:000} : {10:000} : {11:000} : {12:000} : {13:000} : {14:000}",
                                                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14);

                debug01_lbl.Text = string.Format("{0:000} : {1:000} : {2:000} : {3:000} : {4:000} : {5:000} : {6:000} : {7:000} : {8:000} : {9:000} : {10:000} : {11:000} : {12:000} : {13:000} : {14:000}",
                    Debug_Array[0], Debug_Array[1], Debug_Array[2], Debug_Array[3], Debug_Array[4], Debug_Array[5], Debug_Array[6], Debug_Array[7], Debug_Array[8], Debug_Array[9], Debug_Array[10], Debug_Array[11], Debug_Array[12], Debug_Array[13], Debug_Array[14]);
                debug_str = "";
                for (int fi = 0; fi < 15; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Array[fi]);
                }
                debug02_lbl.Text = debug_str;
                debug_str = "";
                for (int fi = 0; fi < 15; fi++)
                {
                    debug_str += string.Format(" {0:X2} : ", Debug_Arr2[fi]);
                }
                debug03_lbl.Text = debug_str;

            }

            //���ݎ����X�V
            lbl_timer_now_time.Text = string.Format("{0:00}:{1:00}:{2:00}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);

            //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
            //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

        //--------------------------------------------------------------------------------------------------------------------------
        //FUNCTION:	ReadFileManagedBuffer()
        //PURPOSE:	Wrapper function to call ReadFile()
        //
        //INPUT:	Uses managed versions of the same input parameters as ReadFile() uses.
        //
        //OUTPUT:	Returns boolean indicating if the function call was successful or not.
        //          Also returns data in the byte[] INBuffer, and the number of bytes read. 
        //
        //Notes:    Wrapper function used to call the ReadFile() function.  ReadFile() takes a pointer to an unmanaged buffer and deposits
        //          the bytes read into the buffer.  However, can't pass a pointer to a managed buffer directly to ReadFile().
        //          This ReadFileManagedBuffer() is a wrapper function to make it so application code can call ReadFile() easier
        //          by specifying a managed buffer.
        //--------------------------------------------------------------------------------------------------------------------------
        public unsafe bool ReadFileManagedBuffer(SafeFileHandle hFile, byte[] INBuffer, uint nNumberOfBytesToRead, ref uint lpNumberOfBytesRead, IntPtr lpOverlapped)
        {
            IntPtr pINBuffer = IntPtr.Zero;

            try
            {
                pINBuffer = Marshal.AllocHGlobal((int)nNumberOfBytesToRead);    //Allocate some unmanged RAM for the receive data buffer.

                if (ReadFile(hFile, pINBuffer, nNumberOfBytesToRead, ref lpNumberOfBytesRead, lpOverlapped))
                {
                    Marshal.Copy(pINBuffer, INBuffer, 0, (int)lpNumberOfBytesRead);    //Copy over the data from unmanged memory into the managed byte[] INBuffer
                    Marshal.FreeHGlobal(pINBuffer);
                    return true;
                }
                else
                {
                    Marshal.FreeHGlobal(pINBuffer);
                    return false;
                }

            }
            catch
            {
                if (pINBuffer != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(pINBuffer);
                }
                return false;
            }
        }


        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                //�����ݒ�t�@�C����������
                string ini_file_path = Path.Combine( System.Environment.CurrentDirectory, Constants.INIT_DATA_FILE_NAME);
                my_File_Save(ini_file_path, true);

                // Timer�ݒ��ʕ\����ԃZ�b�g
                aTSI.set_timer_setting_visible(timer_set_display_visible);
                // Timer�ݒ��ԃZ�b�g
                aTSI.set_timer_setting_enabled(timer_on_flag);
                //TIMER�����ݒ�t�@�C����������
                string timer_ini_file_path = Path.Combine(System.Environment.CurrentDirectory, Constants.INIT_TIMER_DATA_FILE_NAME);
                my_timer_list_file_save(timer_ini_file_path);
            }
            catch
            {
            }
        }

        private void btn_ir_read_start_Click(object sender, EventArgs e)
        {
            try
            {
                ir_read_start_freq = ir_freq_select_default;
                b_ir_read_start_req = true;

                btn_ir_read_start.Enabled = false;
                btn_ir_read_stop.Enabled = true;

                btn_Setting_Set.Enabled = false;
                btn_setting_clr.Enabled = false;
                btn_clip_copy.Enabled = false;
            }
            catch
            {
            }
        }

        private void btn_ir_read_stop_Click(object sender, EventArgs e)
        {
            try
            {
                ir_read_data_rec_buff_no = ir_data_select_no;
                ir_read_data_total_size = 0;
                ir_read_data_get_count = 0;
                b_ir_read_data_get_comp = false;
                b_ir_read_stop_comp = false;
                b_ir_read_stop_req = true;

                btn_ir_read_start.Enabled = true;
                btn_ir_read_stop.Enabled = false;

                btn_Setting_Set.Enabled = true;
                btn_setting_clr.Enabled = true;
                btn_clip_copy.Enabled = true;
            }
            catch
            {
            }
        }

        private void btn_ir_data_file_save_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileDialog1.Title = "Save As...";
                saveFileDialog1.Filter = "CSV file(*.csv)|*.csv|All file(*.*)|*.*";

                DialogResult dr = saveFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    my_File_Save(saveFileDialog1.FileName, true);
                }
            }
            catch
            {
            }
        }

        private int my_File_Save(string file_name, bool save_flag)
        {
            int ret = -1;
            try
            {

#if true   // CSV
                //System.Text.Encoding enc = System.Text.Encoding.GetEncoding("Shift_JIS");
                System.Text.Encoding enc = System.Text.Encoding.GetEncoding("UTF-8");
                System.IO.StreamWriter sw = null;
                try
                {
                    sw = new System.IO.StreamWriter(file_name, false, enc);
                    string out_str = "";
                    string tmp_str = "";
                    for (int data_idx = 0; data_idx < Constants.IR_DATA_REC_NUM; data_idx++)
                    {
                        out_str = "";

                        // memo
                        tmp_str = my_Ir_data.memo[data_idx];
                        out_str = my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // freq
                        tmp_str = string.Format("{0}", my_Ir_data.ir_freq[data_idx]);
                        out_str += my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // size
                        tmp_str = string.Format("{0}", my_Ir_data.ir_data_size[data_idx]);
                        out_str += my_Enclose_Double_Quotes(tmp_str);
                        out_str += ",";
                        // data
                        for (int data_pos = 0; data_pos < (my_Ir_data.ir_data_size[data_idx]*2); data_pos++)
                        {
                            if (data_pos > 0)
                            {
                                out_str += ",";
                            }
                            tmp_str = string.Format("0x{0:X4}", my_Ir_data.ir_data_rec_buff[data_idx, data_pos]);
                            out_str += my_Enclose_Double_Quotes(tmp_str);
                        }
                        sw.Write(out_str);
                        sw.Write("\r\n");//���s
                    }
                }
                catch
                {
                    sw.Write("\r\nerror");
                }
                finally
                {
                    if (sw != null)
                    {
                        sw.Close();
                        sw.Dispose();
                    }
                }

#endif
#if false   // XML
                Stream stream = null;
                try
                {
                    stream = File.Open(file_name, FileMode.Create);
                    SoapFormatter formatter = new SoapFormatter();

                    formatter.Serialize(stream, my_Ir_data);
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                        stream.Dispose();
                    }
                }
#endif
            }
            catch
            {
            }
            return ret;
        }

        private void btn_ir_data_file_read_Click(object sender, EventArgs e)
        {
            int i_ret = 0;
            try
            {
                openFileDialog1.Title = "Open...";
                openFileDialog1.Filter = "CSV file(*.csv)|*.csv|All file(*.*)|*.*";

                DialogResult dr = openFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    i_ret = my_File_Read(openFileDialog1.FileName);

                    if (i_ret > 0)
                    {
                        my_Ir_data.ir_data_get(0, txtbx_memo.Text, ref ir_read_start_freq, ref ir_read_data_total_size, ref ir_read_data, ir_read_data.Length);
                        ir_read_data_get_count = ir_read_data_total_size * 2;

                        my_list_data_disp();

                        ir_data_select_no = 0;
                        my_select_data_disp(ir_data_select_no);
                    }
                }
            }
            catch
            {
            }
        }

        private int my_File_Read(string file_name)
        {
            int ret = 0;
            try
            {

#if true   // CSV
                //System.Text.Encoding enc = System.Text.Encoding.GetEncoding("Shift_JIS");
                System.Text.Encoding enc = System.Text.Encoding.GetEncoding("UTF-8");
                System.IO.StreamReader sr = null;
                try
                {
                    sr = new System.IO.StreamReader(file_name, enc);
                    string in_str = "";
                    int read_idx = 0;

                    my_Ir_data.ir_data_all_clear();

                    while (sr.Peek() > -1 && read_idx < Constants.IR_DATA_REC_NUM && ret >= 0)
                    {
                        in_str = sr.ReadLine();
                        try
                        {
                            string[] in_str_arry = new string[1];
                            if (my_csv_to_array_buff(in_str, ref in_str_arry) >= 3)
                            {   // freq, data size
                                string memo = in_str_arry[0];
                                int freq = int.Parse(in_str_arry[1]);
                                int data_size = int.Parse(in_str_arry[2]);
                                if (data_size > 0)
                                {   // �f�[�^����
                                    if (in_str_arry.Length >= (2 + data_size))
                                    {   // �f�[�^�T�C�Y�Ǝ��ۂ̃f�[�^�̐����`�F�b�N
                                        uint[] tmp_data = new uint[data_size * 2];
                                        try
                                        {
                                            for (int fi = 0; fi < (data_size * 2); fi++)
                                            {
                                                //tmp_data[fi] = uint.Parse(in_str_arry[3+fi], System.Globalization.NumberStyles.HexNumber);
                                                tmp_data[fi] = Convert.ToUInt32(in_str_arry[3 + fi], 16);
                                            }

                                            // �����܂ŃG���[�Ȃ�
                                            // �f�[�^�Z�b�g
                                            my_Ir_data.ir_data_set(read_idx, memo, freq, data_size, tmp_data);
                                            ret++;
                                        }
                                        catch
                                        {
                                            ret = -3;
                                        }
                                    }
                                }
                                else
                                {
                                    // ��f�[�^�Z�b�g
                                    uint[] tmp_data = new uint[2];
                                    my_Ir_data.ir_data_set(read_idx, memo, freq, data_size, tmp_data);
                                    ret++;
                                }
                            }
                        }
                        catch
                        {
                            ret = -2;
                        }
                        read_idx++;
                    }
                }
                catch
                {
                    ret = -1;
                }
                finally
                {
                    if (sr != null)
                    {
                        sr.Close();
                        sr.Dispose();
                    }
                }

#endif
#if false   // XML
                Stream stream = null;
                try
                {
                    stream = File.Open(file_name, FileMode.Open);
                    SoapFormatter formatter = new SoapFormatter();

                    my_Ir_data = (IrData)formatter.Deserialize(stream);
                }
                catch
                {
                }
                finally
                {
                    if (stream != null)
                    {
                        stream.Close();
                        stream.Dispose();
                    }
                }
#endif
            }
            catch
            {
            }
            return ret;
        }

        private void btn_clip_copy_Click(object sender, EventArgs e)
        {
            string clip_copy_data = "";
            try
            {
                //                ir_data_select_no
                if (my_Ir_data.ir_data_size[ir_data_select_no] > 0)
                {
                    int line_data_count = 0;
                    for (int fi = 0; fi < my_Ir_data.ir_data_size[ir_data_select_no] * 2; fi++)
                    {
                        if(fi != 0)
                        {
                            clip_copy_data += ",";
                        }
                        if (line_data_count == 16)
                        {
                            line_data_count = 0;
                            //clip_copy_data += "\n";
                        }
                        clip_copy_data += string.Format("0x{0:X2},0x{1:X2}", (my_Ir_data.ir_data_rec_buff[ir_data_select_no, fi] >> 8) & 0xFF, my_Ir_data.ir_data_rec_buff[ir_data_select_no, fi] & 0xFF);
                        line_data_count++;
                    }
                }

                Clipboard.SetDataObject(clip_copy_data, true);
            }
            catch
            {
            }
        }

        private void my_select_data_disp(int p_select_no)
        {
            try
            {
                if (0 <= p_select_no && p_select_no < Constants.IR_DATA_REC_NUM)
                {
                    lbl_SelectNo.Text = "No." + string.Format("{0:00}", p_select_no + 1);

                    txtbx_memo.Text = my_Ir_data.memo[p_select_no];
                    if (txtbx_memo.Text == "")
                    {
                        txtbx_memo.Text = Constants.IR_DATA_MEMO_DEFAULT;
                    }

                    string read_data_header = "";
                    read_data_header = "       ";
                    int const_1line_num = 16;
                    int line_data_count = 0;
                    int line_count = 1;
                    for (int fi = 0; fi < const_1line_num; fi++)
                    {
                        read_data_header += string.Format("{0:X4} ", fi);
                    }
                    read_data_header += "\n";

                    // �o�b�t�@�̃f�[�^��\��
                    if (my_Ir_data.ir_data_size[p_select_no] > 0)
                    {
                        rtxtbx_ir_read_data.Text = read_data_header;
                        for (int fi = 0; fi < my_Ir_data.ir_data_size[p_select_no] * 2; fi++)
                        {
                            if (line_data_count == 0)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += string.Format("{0:X4} : ", line_count);
                                line_count++;
                            }

                            rtxtbx_ir_read_data.Text += string.Format("{0:X4} ", my_Ir_data.ir_data_rec_buff[p_select_no, fi]);

                            line_data_count++;
                            if (line_data_count >= const_1line_num)
                            {
                                line_data_count = 0;
                                rtxtbx_ir_read_data.Text += "\n";
                            }
                        }
                    }
                    else
                    {
                        rtxtbx_ir_read_data.Text = "";
                    }
                    lbl_ir_read_size.Text = "�ǂݍ��݃T�C�Y:" + my_Ir_data.ir_data_size[p_select_no].ToString() + "bits (" + string.Format("{0}", my_Ir_data.ir_data_size[p_select_no] * 4) + "byte) : Freq=" + my_Ir_data.ir_freq[p_select_no].ToString() + "Hz";

                }
                else
                {
                }
            }
            catch
            {
            }
        }

        private void my_list_data_disp()
        {
            try
            {
                for (int fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++ )
                {
                    my_memo_textbox[fi].Text = my_Ir_data.memo[fi];
                }
            }
            catch
            {
            }
        }

        private void btn_Setting_Set_Click(object sender, EventArgs e)
        {
            try
            {
                if (0 <= ir_data_select_no && ir_data_select_no < Constants.IR_DATA_REC_NUM)
                {
                    // �ۑ��o�b�t�@�ɂ��R�s�[
                    my_Ir_data.ir_data_set(ir_data_select_no, txtbx_memo.Text, ir_read_start_freq, ir_read_data_total_size, ir_read_data);
                    my_list_data_disp();
                }
            }
            catch
            {
            }
        }

        private void btn_setting_clr_Click(object sender, EventArgs e)
        {
            try
            {
                if (0 <= ir_data_select_no && ir_data_select_no < Constants.IR_DATA_REC_NUM)
                {
                    //�����m�F
                    string tmp_msg = string.Format(Constants.IR_DATA_CLEAR_MSG, ir_data_select_no + 1);
                    if (DialogResult.OK == MessageBox.Show(tmp_msg, c_APPLICATION_NAME, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning))
                    {
                        // �ۑ��o�b�t�@�N���A
                        my_Ir_data.ir_data_clear(ir_data_select_no);

                        my_select_data_disp(ir_data_select_no);

                        //my_Ir_data.ir_data_set(ir_data_select_no, txtbx_memo.Text, ir_read_start_freq, ir_read_data_total_size, ir_read_data);
                        my_list_data_disp();
                    }
                }
            }
            catch
            {
            }
        }

        private void btn_select_No_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.IR_DATA_REC_NUM && btn_ir_read_start.Enabled == true)
                {
                    ir_data_select_no = idx;
                    my_select_data_disp(ir_data_select_no);
                }
            }
            catch
            {
            }
        }

        private void btn_send_No_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = int.Parse(((System.Windows.Forms.Button)sender).Tag.ToString());
                if (0 <= idx && idx < Constants.IR_DATA_REC_NUM)
                {
                    ir_send_data_set_buff_no = idx;
                    ir_send_data_set_pos = 0;
                    b_ir_send_data_set_req = true;
                }
            }
            catch
            {
            }
        }
        /// �w�肳�ꂽ��������ɂ��镶��������邩������
        private static int my_Count_String(string strInput, string strFind)
        {
            int foundCount = 0;
            int sPos = strInput.IndexOf(strFind);
            while (sPos > -1)
            {
                foundCount++;
                sPos = strInput.IndexOf(strFind, sPos + 1);
            }

            return foundCount;
        }
        /// ��������_�u���N�H�[�g�ň͂�
        private static string my_Enclose_Double_Quotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"��""�Ƃ���
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }
        private int my_csv_to_array_buff(string p_csv_text, ref string[] o_csv_buff)
        {
            int i_ret = 0;
            try
            {
                //�O��̉��s���폜���Ă���
                p_csv_text = p_csv_text.Trim(new char[] { '\r', '\n' });

                //1�s��CSV����e�t�B�[���h���擾���邽�߂̐��K�\��
                System.Text.RegularExpressions.Regex regCsv =
                    new System.Text.RegularExpressions.Regex(
                    "\\s*(\"(?:[^\"]|\"\")*\"|[^,]*)\\s*,",
                    System.Text.RegularExpressions.RegexOptions.None);

                // "�̐������������ׂ�
                if ((my_Count_String(p_csv_text, "\"") % 2) == 0)
                {
                    //�s�̍Ō�̉��s�L�����폜
                    p_csv_text = p_csv_text.TrimEnd(new char[] { '\r', '\n' });
                    //�Ō�Ɂu,�v������
                    p_csv_text += ",";

                    //1�̍s����t�B�[���h�����o��
                    System.Collections.ArrayList csvFields = new System.Collections.ArrayList();
                    System.Text.RegularExpressions.Match m = regCsv.Match(p_csv_text);
                    while (m.Success)
                    {
                        string field = m.Groups[1].Value;
                        //�O��̋󔒂��폜
                        field = field.Trim();
                        //"�ň͂܂�Ă��鎞
                        if (field.StartsWith("\"") && field.EndsWith("\""))
                        {
                            //�O���"�����
                            field = field.Substring(1, field.Length - 2);
                            //�u""�v���u"�v�ɂ���
                            field = field.Replace("\"\"", "\"");
                        }
                        csvFields.Add(field);
                        m = m.NextMatch();
                    }

                    csvFields.TrimToSize();

                    // �o�̓o�b�t�@�ɃZ�b�g
                    o_csv_buff = new string[csvFields.Count];
                    for (int fi = 0; fi < csvFields.Count; fi++ )
                    {
                        o_csv_buff[fi] = csvFields[fi].ToString();
                    }
                    i_ret = csvFields.Count;
                }
                else
                {   // "�̐����
                    i_ret = -1;
                }
            }
            catch
            {
            }
            return i_ret;
        }

        private void txtbx_memo_Enter(object sender, EventArgs e)
        {
            try
            {
                if (txtbx_memo.Text == Constants.IR_DATA_MEMO_DEFAULT)
                {
                    txtbx_memo.SelectAll();
                }
            }
            catch
            {
            }
        }

        private void btn_timer_set_display_Click(object sender, EventArgs e)
        {
            try
            {
                if (timer_set_display_visible == true)
                {   // ��\����
                    my_timer_setting_display(false);
                }
                else
                {   // �\��
                    my_timer_setting_display(true);
                }
            }
            catch
            {
            }
        }
        private void my_timer_setting_display(bool p_visible)
        {
            try
            {
                if (p_visible == true)
                {   // �\��
                    System.Reflection.Assembly myAssembly = System.Reflection.Assembly.GetExecutingAssembly();
                    Bitmap bmp = new Bitmap(myAssembly.GetManifestResourceStream("USB_IR_Remote_Controller_Advance_CT.Resources.sendBG.png"));
                    this.BackgroundImage = bmp;

                    gbx_timer_setting.Visible = true;
                    btn_timer_set_display.Text = Constants.TIMER_SET_DISPLAY_BUTTON_OFF_TEXT;

                    this.Size = new System.Drawing.Size(Constants.FORM_SIZE_X_TIMER_DISPLAY_ON, this.Size.Height);
                    lbl_FW_Version.Location = new System.Drawing.Point(this.Size.Width - lbl_FW_Version.Size.Width - 10, lbl_FW_Version.Location.Y);

                    timer_set_display_visible = true;
                }
                else
                {   // ��\��
                    System.Reflection.Assembly myAssembly = System.Reflection.Assembly.GetExecutingAssembly();
                    Bitmap bmp = new Bitmap(myAssembly.GetManifestResourceStream("USB_IR_Remote_Controller_Advance_CT.Resources.sendBGs.png"));
                    this.BackgroundImage = bmp;

                    gbx_timer_setting.Visible = false;
                    btn_timer_set_display.Text = Constants.TIMER_SET_DISPLAY_BUTTON_ON_TEXT;

                    this.Size = new System.Drawing.Size(Constants.FORM_SIZE_X_TIMER_DISPLAY_OFF, this.Size.Height);
                    lbl_FW_Version.Location = new System.Drawing.Point(this.Size.Width - lbl_FW_Version.Size.Width - 10, lbl_FW_Version.Location.Y);

                    timer_set_display_visible = false;
                }
            }
            catch
            {
            }
        }

        private void btn_timer_on_off_Click(object sender, EventArgs e)
        {
            try
            {
                my_btn_timer_onoff_click(!timer_on_flag);
            }
            catch
            {
            }
        }

        private void my_btn_timer_onoff_click(bool p_onoff_flag)
        {
            try
            {
                if (p_onoff_flag == true)
                {
                    if (aTSI.timer_item_num > 0)
                    {
                        // ���̃^�C�}���M���ڈʒu���`�F�b�N
                        TimeSpan ts_now = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                        TimeSpan ts_temp;
                        DateTime dt_temp;
                        timer_time_check_next_idx = 0;
                        for (int fi = 0; fi < aTSI.timer_item_num; fi++)
                        {
                            dt_temp = (DateTime)aTSI.send_time[fi];
                            ts_temp = new TimeSpan(dt_temp.Hour, dt_temp.Minute, dt_temp.Second);
                            if (ts_now.CompareTo(ts_temp) < 0)
                            {
                                timer_time_check_next_idx = fi;
                                break;
                            }
                        }
                        //���ɑ��M����ʒu�����ݍs��
                        dgv_timer_set_list.CurrentCell = dgv_timer_set_list[0, timer_time_check_next_idx];


                        timer_send_idx_buff_w_idx = 0;
                        timer_send_idx_buff_r_idx = 0;
                        timer_send_idx_buff_full = false;

                        my_timer_onoff_btn_set(true);
                    }
                    else
                    {
                        MessageBox.Show(Constants.TIMER_SET_ITEM_NOTHING_MSG, c_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    my_timer_onoff_btn_set(false);
                }
            }
            catch
            {
            }
        }

        private void my_timer_onoff_btn_set(bool p_set)
        {
            try
            {
                timer_on_flag = p_set;
                if (p_set == true)
                {
                    btn_timer_on_off.ImageIndex = 1;

                    dgv_timer_set_list.Enabled = false;
                    btn_timer_item_del.Enabled = false;
                    gbx_timer_item_add.Enabled = false;
                }
                else
                {
                    btn_timer_on_off.ImageIndex = 0;

                    dgv_timer_set_list.Enabled = true;
                    btn_timer_item_del.Enabled = true;
                    gbx_timer_item_add.Enabled = true;
                }
            }
            catch
            {
            }
        }

        private void btn_timer_item_del_Click(object sender, EventArgs e)
        {
            try
            {
                aTSI.Del();
                my_timer_list_display(aTSI);
            }
            catch
            {
            }
        }

        private void btn_timer_item_add_Click(object sender, EventArgs e)
        {
            try
            {
                // Constants.TIMER_SET_ITEM_MAX
                if (aTSI.get_timer_set_num() < Constants.TIMER_SET_ITEM_MAX)
                {
                    DateTime tmp_dt = dtp_timer_set_time.Value;
                    int tmp_send_no = cmbbx_timer_set_no.SelectedIndex;
                    int set_idx = aTSI.get_set_pos(tmp_dt, tmp_send_no);
                    aTSI.Add(set_idx, tmp_dt, tmp_send_no);

                    my_timer_list_display(aTSI);
                }
                else
                {   // �ݒ荀�ڐ�����
                    string tmp_msg = string.Format(Constants.TIMER_SET_ITEM_NUM_OVER_MSG, Constants.TIMER_SET_ITEM_MAX);
                    MessageBox.Show(tmp_msg, c_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
            }
        }

        private void btn_timer_list_export_Click(object sender, EventArgs e)
        {
            try
            {
                saveFileDialog1.Title = "Save As...";
                saveFileDialog1.Filter = "XML file(*.xml)|*.xml|All file(*.*)|*.*";

                DialogResult dr = saveFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    my_timer_list_file_save(saveFileDialog1.FileName);
                }
            }
            catch
            {
            }
        }

        private void btn_timer_list_import_Click(object sender, EventArgs e)
        {
            int i_ret = 0;
            try
            {
                openFileDialog1.Title = "Open...";
                openFileDialog1.Filter = "XML file(*.xml)|*.xml|All file(*.*)|*.*";

                DialogResult dr = openFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    i_ret = my_timer_list_file_read(openFileDialog1.FileName);

                    if (i_ret == 0)
                    {
                        my_timer_list_display(aTSI);
                    }
                }
            }
            catch
            {
            }
        }

        private int my_timer_list_display(TimerSetInfo p_tsi)
        {
            int ret = -1;
            try
            {
                // ���ݕ\�����Ă���擪�ʒu���L��
                int top_idx = dgv_timer_set_list.FirstDisplayedScrollingRowIndex;

                dgv_timer_set_list.Rows.Clear();

                ret = 0;
                for (int fi = 0; fi < p_tsi.timer_item_num; fi++)
                {
                    try
                    {
                        bool tmp_check_status = (bool)p_tsi.check_status[fi];
                        TimeSpan tmp_ts = ((DateTime)p_tsi.send_time[fi]).TimeOfDay;
                        int tmp_send_no = (int)p_tsi.send_data_no[fi];

                        string[] row = new string[dgv_timer_set_list.Columns.Count];
                        row[1] = string.Format("{0:00}:{1:00}:{2:00}", tmp_ts.Hours, tmp_ts.Minutes, tmp_ts.Seconds);
                        row[2] = string.Format("{0}", tmp_send_no + 1);
                        //dgv_timer_set_list.Rows.Insert(fi, row);

                        //tmp_check_status = true;
                        dgv_timer_set_list.Rows.Add(tmp_check_status, string.Format("{0:00}:{1:00}:{2:00}", tmp_ts.Hours, tmp_ts.Minutes, tmp_ts.Seconds), string.Format("{0}", tmp_send_no + 1));
                    }
                    catch
                    {
                        ret = -2;
                    }
                }

                //�擪�ʒu�ݒ�
                if (top_idx >= dgv_timer_set_list.Rows.Count)
                {
                    top_idx = dgv_timer_set_list.Rows.Count;
                }
                dgv_timer_set_list.FirstDisplayedScrollingRowIndex = top_idx;
            }
            catch
            {
            }
            return ret;
        }

        private int my_timer_list_file_read(string file_name)
        {
            int ret = -1;
            try
            {
                // �t�@�C���L���`�F�b�N
                if (File.Exists(file_name) == true)
                {
                    System.Xml.Serialization.XmlSerializer serializer = null;
                    System.IO.FileStream fs = null;
                    try
                    {
                        serializer = new System.Xml.Serialization.XmlSerializer(typeof(TimerSetInfo));
                        fs = new System.IO.FileStream(file_name, System.IO.FileMode.Open);
                        TimerSetInfo aTSI_tmp = (TimerSetInfo)serializer.Deserialize(fs);

                        if (aTSI_tmp.timer_item_num <= Constants.TIMER_SET_ITEM_MAX)
                        {
                            //�ǂݍ��ݐ���
                            aTSI = aTSI_tmp;

                            ret = 0;
                        }
                        else
                        {
                            //�f�[�^���ُ�
                            string tmp_msg = string.Format(Constants.TIMER_SET_ITEM_NUM_OVER_MSG2, Constants.TIMER_SET_ITEM_MAX);
                            MessageBox.Show(tmp_msg, c_APPLICATION_NAME, MessageBoxButtons.OK, MessageBoxIcon.Error);
                            ret = -2;
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        if (fs != null)
                        {
                            fs.Close();
                            fs.Dispose();
                        }
                    }
                }
            }
            catch
            {
            }
            return ret;
        }
        private int my_timer_list_file_save(string file_name)
        {
            int ret = -1;
            try
            {
                System.Xml.Serialization.XmlSerializer serializer = null;
                System.IO.FileStream fs = null;

                try
                {
                    aTSI.timer_setting_enabled = timer_on_flag;

                    serializer = new System.Xml.Serialization.XmlSerializer(typeof(TimerSetInfo));
                    fs = new System.IO.FileStream(file_name, System.IO.FileMode.Create);
                    serializer.Serialize(fs, aTSI);


                    ret = 0;
                }
                catch
                {
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                        fs.Dispose();
                    }
                }
            }
            catch
            {
            }
            return ret;
        }

        private void dgv_timer_set_list_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || dgv_timer_set_list.RowCount <= 0)
                {
                    return;
                }

                if (e.ColumnIndex == dgv_timer_set_list.Columns["chkbx_select"].Index)
                {
                    if (dgv_timer_set_list[dgv_timer_set_list.Columns["chkbx_select"].Index, e.RowIndex].Value != null)
                    {
                        bool chk = (bool)(dgv_timer_set_list[dgv_timer_set_list.Columns["chkbx_select"].Index, e.RowIndex].Value);

                        aTSI.set_check_status(e.RowIndex, chk);
                    }
                }
            }
            catch
            {
            }
        }

        private void dgv_timer_set_list_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0 || dgv_timer_set_list.RowCount <= 0)
                {
                    return;
                }

                if (e.ColumnIndex == dgv_timer_set_list.Columns["chkbx_select"].Index)
                {
                    if (dgv_timer_set_list[dgv_timer_set_list.Columns["chkbx_select"].Index, e.RowIndex].Value != null)
                    {
                        bool chk = (bool)(dgv_timer_set_list[dgv_timer_set_list.Columns["chkbx_select"].Index, e.RowIndex].Value);

                        aTSI.set_check_status(e.RowIndex, chk);
                    }
                }
            }
            catch
            {
            }
        }


        //-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------


    } //public partial class Form1 : Form


    static class Constants
    {
        public const int IR_DATA_BUFF_SIZE = 4800; // 4800 = 2400bit * 2(ON/OFF) PIC32MX230F064B
        //public const int IR_DATA_BUFF_SIZE = 12800; // 12800 = 6400bit * 2(ON/OFF) PIC32MX250F128B
        public const int IR_DATA_REC_NUM = 32;
        public const string IR_DATA_MEMO_DEFAULT = "���̂�t���ĉ�����";
        public const string IR_DATA_CLEAR_MSG = "No.{0}�̐ݒ���������܂��B��낵���ł����H";
        public const string INIT_DATA_FILE_NAME = "usb_ir_remote_controller_advance.ini";
        public const string INIT_TIMER_DATA_FILE_NAME = "usb_ir_remote_controller_advance_timer.ini";
        public const string TIMER_SET_DISPLAY_BUTTON_ON_TEXT = "�^�C�}�[\r\n�ݒ�\r\n�\��";
        public const string TIMER_SET_DISPLAY_BUTTON_OFF_TEXT = "�^�C�}�[\r\n�ݒ�\r\n��\��";
        public const int TIMER_SET_ITEM_MAX = 1000;
        public const int TIMER_SET_SEND_BUFF_MAX = 0x400;
        public const string TIMER_SET_ITEM_NUM_OVER_MSG = "�ݒ荀�ڂ�����ȏ�ǉ��ł��܂���B�ő�ݒ萔 {0}";
        public const string TIMER_SET_ITEM_NUM_OVER_MSG2 = "�ݒ荀�ڐ��ُ� �ő�ݒ萔 {0}";
        public const string TIMER_SET_ITEM_NOTHING_MSG = "�^�C�}�[�ݒ荀�ڂ�����܂���";
        public const int FORM_SIZE_X_TIMER_DISPLAY_ON = 1165;
        public const int FORM_SIZE_Y_TIMER_DISPLAY_ON = 663;
        public const int FORM_SIZE_X_TIMER_DISPLAY_OFF = 965;
        public const int FORM_SIZE_Y_TIMER_DISPLAY_OFF = 663;
    }


    [Serializable()]
    public class IrData
    {
        [System.Xml.Serialization.XmlElement("MEMO")]
        public string[] memo;           // ����
        [System.Xml.Serialization.XmlElement("IR_FREQ")]
        public int[] ir_freq;           // ���g��
        [System.Xml.Serialization.XmlElement("IR_DATA_SIZE")]
        public int[] ir_data_size;      // �f�[�^�T�C�Y
        [System.Xml.Serialization.XmlElement("IR_DATA")]
        public uint[,] ir_data_rec_buff;        // �f�[�^

        public IrData()
        {
        }
        public IrData(int p_rec_num, int p_ir_data_buff_size)
        {
            int fi, fj;
            try
            {
                memo = new string[p_rec_num];
                ir_freq = new int[p_rec_num];
                ir_data_size = new int[p_rec_num];
                ir_data_rec_buff = new uint[p_rec_num, p_ir_data_buff_size];

                for (fi = 0; fi < p_rec_num; fi++)
                {
                    memo[fi] = "";
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                    for (fj = 0; fj < p_ir_data_buff_size; fj++)
                    {
                        ir_data_rec_buff[fi,fj] = 0;
                    }
                }
            }
            catch
            {
            }
        }

        public int Init()
        {
            int ret = 0;
            int fi, fj;
            try
            {
                for (fi = 0; fi < Constants.IR_DATA_REC_NUM; fi++)
                {
                    memo[fi] = "";
                    ir_freq[fi] = 0;
                    ir_data_size[fi] = 0;
                    for (fj = 0; fj < Constants.IR_DATA_BUFF_SIZE; fj++)
                    {
                        ir_data_rec_buff[fi, fj] = 0;
                    }
                }
            }
            catch
            {
            }
            return ret;
        }
        public int Dispose()
        {
            int ret = 0;
            try
            {
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_set(int p_idx, string p_memo, int p_ir_freq, int p_ir_data_size, uint[] p_ir_data)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    memo[p_idx] = p_memo;
                    ir_freq[p_idx] = p_ir_freq;
                    ir_data_size[p_idx] = p_ir_data_size;
                    for (int fj = 0; fj < (p_ir_data_size * 2); fj++)
                    {
                        ir_data_rec_buff[p_idx, fj] = p_ir_data[fj];
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_get(int p_idx, string p_memo, ref int p_ir_freq, ref int p_ir_data_size, ref uint[] p_ir_data, int p_ir_data_buff_size)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    for (int fi = 0; fi < p_ir_data_buff_size; fi++)
                    {
                        p_ir_data[fi] = 0;
                    }

                    p_memo = memo[p_idx];
                    p_ir_freq = ir_freq[p_idx];
                    p_ir_data_size = ir_data_size[p_idx];
                    for (int fj = 0; fj < (p_ir_data_size * 2); fj++)
                    {
                        p_ir_data[fj] = ir_data_rec_buff[p_idx, fj];
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_clear(int p_idx)
        {
            int ret = 0;
            try
            {
                if (0 <= p_idx && p_idx < Constants.IR_DATA_REC_NUM)
                {
                    memo[p_idx] = "";
                    ir_freq[p_idx] = 0;
                    ir_data_size[p_idx] = 0;
                    for (int fj = 0; fj < Constants.IR_DATA_BUFF_SIZE; fj++)
                    {
                        ir_data_rec_buff[p_idx, fj] = 0;
                    }
                }
                else
                {
                    ret = 1;
                }
            }
            catch
            {
            }
            return ret;
        }

        public int ir_data_all_clear()
        {
            int ret = 0;
            try
            {
                Init();
            }
            catch
            {
            }
            return ret;
        }
    }

    [Serializable()]
    public class TimerSetInfo
    {
        [System.Xml.Serialization.XmlElement("TIMER_SETTING_VISIBLE")]
        public bool timer_setting_visible;                    // 
        [System.Xml.Serialization.XmlElement("TIMER_SETTING_ENABLED")]
        public bool timer_setting_enabled;                    // 
        [System.Xml.Serialization.XmlElement("TIMER_ITEM_NUM")]
        public int timer_item_num;                    // �^�C�}�[�ݒ萔
        [System.Xml.Serialization.XmlArrayItem(typeof(bool))]
        public System.Collections.ArrayList check_status;
        [System.Xml.Serialization.XmlArrayItem(typeof(DateTime))]
        //[System.Xml.Serialization.XmlArrayItem(typeof(TimeSpan))]
        public System.Collections.ArrayList send_time;
        [System.Xml.Serialization.XmlArrayItem(typeof(int))]
        public System.Collections.ArrayList send_data_no;

        public TimerSetInfo()
        {
            try
            {
                timer_setting_visible = false;
                timer_setting_enabled = false;
                timer_item_num = 0;
                check_status = new ArrayList();
                send_time = new ArrayList();
                send_data_no = new ArrayList();
            }
            catch
            {
            }
        }

        public bool get_timer_setting_visible()
        {
            return timer_setting_visible;
        }
        public void set_timer_setting_visible(bool p_set_visible)
        {
            try
            {
                timer_setting_visible = p_set_visible;
            }
            catch
            {
            }
        }
        public bool get_timer_setting_enabled()
        {
            return timer_setting_enabled;
        }
        public void set_timer_setting_enabled(bool p_set_enabled)
        {
            try
            {
                timer_setting_enabled = p_set_enabled;
            }
            catch
            {
            }
        }

        public int get_set_pos(DateTime p_set_time, int p_send_no)
        {
            int ret = -1;
            try
            {
                int set_pos = 0;
                TimeSpan tmp_ts;
                int tmp_send_no;
                for (int fi = 0; fi < send_time.Count; fi++)
                {
                    set_pos = fi;

                    tmp_ts = ((DateTime)send_time[fi]).TimeOfDay;
                    int compare_ret = tmp_ts.CompareTo(p_set_time.TimeOfDay);
                    if (compare_ret > 0)
                    {
                        // fi�ʒu�̎������傫���̂ł��̈ʒu�ɒǉ�
                        break;
                    }
                    else if (compare_ret == 0)
                    {
                        // �����������Ȃ̂ŁANo.���`�F�b�N
                        tmp_send_no = (int)send_data_no[fi];
                        if (p_send_no < tmp_send_no)
                        {
                            // fi�ʒu�̑��MNo.�́A�傫���̂ł��̈ʒu�ɒǉ�
                            break;
                        }
                    }
                    set_pos++;
                }

                ret = set_pos;
            }
            catch
            {
            }
            return ret;
        }
        public int Add(int p_set_pos, DateTime p_set_time, int p_send_no)
        {
            int ret = -1;
            try
            {
                if (0 <= p_set_pos && p_set_pos <= send_time.Count)
                {
                    check_status.Insert(p_set_pos, false);
                    send_time.Insert(p_set_pos, p_set_time);
                    send_data_no.Insert(p_set_pos, p_send_no);
                    timer_item_num++;
                    ret = 0;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int Del()
        {
            int ret = -1;
            try
            {
                int del_idx = 0;
                int loop_count = timer_item_num;
                for (int fi = 0; fi < loop_count; fi++)
                {
                    bool tmp_check_status = (bool)check_status[del_idx];
                    if (tmp_check_status == true)
                    {
                        Del(del_idx);
                    }
                    else
                    {
                        del_idx++;
                    }
                }
                ret = 0;
            }
            catch
            {
            }
            return ret;
        }
        public int Del(int p_idx)
        {
            int ret = -1;
            try
            {
                if (0 <= p_idx && p_idx < check_status.Count && p_idx < send_time.Count && p_idx < send_data_no.Count)
                {
                    check_status.RemoveAt(p_idx);
                    send_time.RemoveAt(p_idx);
                    send_data_no.RemoveAt(p_idx);
                    timer_item_num--;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int get_timer_set_num()
        {
            int ret = 0;
            try
            {
                if (timer_item_num == check_status.Count && timer_item_num == send_time.Count && timer_item_num == send_data_no.Count)
                {
                    ret = timer_item_num;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int get_check_status(int p_idx, bool o_check_status)
        {
            int ret = -1;
            try
            {
                if (0 <= p_idx && p_idx < check_status.Count)
                {
                    o_check_status = (bool)check_status[p_idx];
                    ret = 0;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int set_check_status(int p_idx, bool p_check_status)
        {
            int ret = -1;
            try
            {
                if (0 <= p_idx && p_idx < check_status.Count)
                {
                    check_status[p_idx] = p_check_status;
                    ret = 0;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int get_timer_send_time(int p_idx, DateTime o_time)
        {
            int ret = -1;
            try
            {
                if (0 <= p_idx && p_idx < send_time.Count)
                {
                    o_time = (DateTime)send_time[p_idx];
                    ret = 0;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int get_timer_send_no(int p_idx)
        {
            int ret = -1;
            try
            {
                if (0 <= p_idx && p_idx < send_data_no.Count)
                {
                    ret = (int)send_data_no[p_idx];
                    ret = 0;
                }
                else
                {
                    ret = -2;
                }
            }
            catch
            {
            }
            return ret;
        }
        public int set_check_all_clear()
        {
            int ret = -1;
            try
            {
                for (int fi = 0; fi < check_status.Count; fi++)
                {
                    check_status[fi] = false;
                }
            }
            catch
            {
            }
            return ret;
        }
    }

} //namespace HID_PnP_Demo