﻿namespace USB_IR_sample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbbx_band = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_direction = new System.Windows.Forms.TextBox();
            this.btn_stop = new System.Windows.Forms.Button();
            this.btn_speed_down = new System.Windows.Forms.Button();
            this.btn_speed_up = new System.Windows.Forms.Button();
            this.btn_backward = new System.Windows.Forms.Button();
            this.btn_forward = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbbx_band
            // 
            this.cmbbx_band.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbx_band.FormattingEnabled = true;
            this.cmbbx_band.Items.AddRange(new object[] {
            "A",
            "B"});
            this.cmbbx_band.Location = new System.Drawing.Point(64, 12);
            this.cmbbx_band.Name = "cmbbx_band";
            this.cmbbx_band.Size = new System.Drawing.Size(88, 20);
            this.cmbbx_band.TabIndex = 101;
            this.cmbbx_band.SelectedIndexChanged += new System.EventHandler(this.cmbbx_band_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 12);
            this.label1.TabIndex = 102;
            this.label1.Text = "Band";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtbx_direction);
            this.groupBox1.Controls.Add(this.btn_stop);
            this.groupBox1.Controls.Add(this.btn_speed_down);
            this.groupBox1.Controls.Add(this.btn_speed_up);
            this.groupBox1.Controls.Add(this.btn_backward);
            this.groupBox1.Controls.Add(this.btn_forward);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(29, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(383, 129);
            this.groupBox1.TabIndex = 103;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "コントロール";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 12);
            this.label2.TabIndex = 104;
            this.label2.Text = "切換え";
            // 
            // txtbx_direction
            // 
            this.txtbx_direction.Font = new System.Drawing.Font("MS UI Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtbx_direction.Location = new System.Drawing.Point(24, 18);
            this.txtbx_direction.Name = "txtbx_direction";
            this.txtbx_direction.ReadOnly = true;
            this.txtbx_direction.Size = new System.Drawing.Size(99, 31);
            this.txtbx_direction.TabIndex = 108;
            this.txtbx_direction.Text = "前進";
            this.txtbx_direction.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_stop
            // 
            this.btn_stop.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_stop.Location = new System.Drawing.Point(282, 49);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(75, 49);
            this.btn_stop.TabIndex = 107;
            this.btn_stop.Text = "停止";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // btn_speed_down
            // 
            this.btn_speed_down.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_speed_down.Location = new System.Drawing.Point(154, 80);
            this.btn_speed_down.Name = "btn_speed_down";
            this.btn_speed_down.Size = new System.Drawing.Size(96, 35);
            this.btn_speed_down.TabIndex = 106;
            this.btn_speed_down.Text = "DOWN";
            this.btn_speed_down.UseVisualStyleBackColor = true;
            this.btn_speed_down.Click += new System.EventHandler(this.btn_speed_down_Click);
            // 
            // btn_speed_up
            // 
            this.btn_speed_up.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btn_speed_up.Location = new System.Drawing.Point(154, 36);
            this.btn_speed_up.Name = "btn_speed_up";
            this.btn_speed_up.Size = new System.Drawing.Size(96, 38);
            this.btn_speed_up.TabIndex = 105;
            this.btn_speed_up.Text = "UP";
            this.btn_speed_up.UseVisualStyleBackColor = true;
            this.btn_speed_up.Click += new System.EventHandler(this.btn_speed_up_Click);
            // 
            // btn_backward
            // 
            this.btn_backward.Location = new System.Drawing.Point(69, 86);
            this.btn_backward.Name = "btn_backward";
            this.btn_backward.Size = new System.Drawing.Size(46, 23);
            this.btn_backward.TabIndex = 104;
            this.btn_backward.Text = "後進";
            this.btn_backward.UseVisualStyleBackColor = true;
            this.btn_backward.Click += new System.EventHandler(this.btn_backward_Click);
            // 
            // btn_forward
            // 
            this.btn_forward.Location = new System.Drawing.Point(69, 55);
            this.btn_forward.Name = "btn_forward";
            this.btn_forward.Size = new System.Drawing.Size(46, 23);
            this.btn_forward.TabIndex = 2;
            this.btn_forward.Text = "前進";
            this.btn_forward.UseVisualStyleBackColor = true;
            this.btn_forward.Click += new System.EventHandler(this.btn_forward_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "前後進";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 12);
            this.label4.TabIndex = 104;
            this.label4.Text = "ショートカット";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 12);
            this.label5.TabIndex = 105;
            this.label5.Text = "前進：←キー";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 12);
            this.label6.TabIndex = 106;
            this.label6.Text = "後進：→キー";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 12);
            this.label7.TabIndex = 107;
            this.label7.Text = "UP：↑キー";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 12);
            this.label8.TabIndex = 108;
            this.label8.Text = "DOWN：↓キー";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 265);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 12);
            this.label9.TabIndex = 109;
            this.label9.Text = "STOP：ESCキー";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(434, 287);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbbx_band);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "USB IR Remote controller Advance";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbbx_band;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtbx_direction;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_speed_down;
        private System.Windows.Forms.Button btn_speed_up;
        private System.Windows.Forms.Button btn_backward;
        private System.Windows.Forms.Button btn_forward;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

