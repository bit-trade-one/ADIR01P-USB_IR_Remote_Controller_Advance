﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using USB_IR_Library;

namespace USB_IR_sample
{
    public partial class Form1 : Form
    {
#if DEBUG
        internal const bool __DEBUG_FLAG__ = true;    // デバッグ時
#else
        internal const bool __DEBUG_FLAG__ = false;     // リリース時
#endif

        int band_type = Constants.BAND_TYPE_A;
        int direction = Constants.DIRECTION_FORWARD;
        public string[] DIRECTION_STR = new string[] { "前進", "後進" };

        public Form1()
        {
            InitializeComponent();

            if (__DEBUG_FLAG__ == false)
            {
                // リリース時の画面サイズ
                this.Size = new System.Drawing.Size(450, 325);
            }
            cmbbx_band.SelectedIndex = 0;
        }

        private void cmbbx_band_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if(cmbbx_band.SelectedIndex == 0)
                {
                    band_type = Constants.BAND_TYPE_A;
                }
                else if (cmbbx_band.SelectedIndex == 1)
                {
                    band_type = Constants.BAND_TYPE_B;
                }
            }
            catch
            {
            }
        }

        private void btn_forward_Click(object sender, EventArgs e)
        {
            try
            {
                my_forward_set();
            }
            catch
            {
            }
        }
        private void my_forward_set()
        {
            try
            {
                direction = Constants.DIRECTION_FORWARD;
                txtbx_direction.Text = DIRECTION_STR[direction];
            }
            catch
            {
            }
        }

        private void btn_backward_Click(object sender, EventArgs e)
        {
            try
            {
                my_backward_set();
            }
            catch
            {
            }
        }
        private void my_backward_set()
        {
            try
            {
                direction = Constants.DIRECTION_BACKWARD;
                txtbx_direction.Text = DIRECTION_STR[direction];
            }
            catch
            {
            }
        }

        private void btn_speed_up_Click(object sender, EventArgs e)
        {
            try
            {
                my_speed_up();
            }
            catch
            {
            }
        }
        private void my_speed_up()
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBIR.openUSBIR(this.Handle);
                if (handle_usb_device != null)
                {

                    if (band_type == Constants.BAND_TYPE_A)
                    {   // BAND A
                        if (direction == Constants.DIRECTION_FORWARD)
                        {   // 前進
                            USBIR.writeUSBIR_Plarail_Speed_Up(handle_usb_device, USBIR.PLARAIL_BAND.BAND_A, USBIR.PLARAIL_DIRECTION.FORWARD);
                        }
                        else if (direction == Constants.DIRECTION_BACKWARD)
                        {   // 後進
                            USBIR.writeUSBIR_Plarail_Speed_Up(handle_usb_device, USBIR.PLARAIL_BAND.BAND_A, USBIR.PLARAIL_DIRECTION.BACKWARD);
                        }
                    }
                    else if (band_type == Constants.BAND_TYPE_B)
                    {   // BAND B
                        if (direction == Constants.DIRECTION_FORWARD)
                        {   // 前進
                            USBIR.writeUSBIR_Plarail_Speed_Up(handle_usb_device, USBIR.PLARAIL_BAND.BAND_B, USBIR.PLARAIL_DIRECTION.FORWARD);
                        }
                        else if (direction == Constants.DIRECTION_BACKWARD)
                        {   // 後進
                            USBIR.writeUSBIR_Plarail_Speed_Up(handle_usb_device, USBIR.PLARAIL_BAND.BAND_B, USBIR.PLARAIL_DIRECTION.BACKWARD);
                        }
                    }
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBIR.closeUSBIR(handle_usb_device);
                }
            }
        }

        private void btn_speed_down_Click(object sender, EventArgs e)
        {
            try
            {
                my_speed_down();
            }
            catch
            {
            }
        }
        private void my_speed_down()
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBIR.openUSBIR(this.Handle);
                if (handle_usb_device != null)
                {
                    if (band_type == Constants.BAND_TYPE_A)
                    {   // BAND A
                        USBIR.writeUSBIR_Plarail_Speed_Down(handle_usb_device, USBIR.PLARAIL_BAND.BAND_A);
                    }
                    else if (band_type == Constants.BAND_TYPE_B)
                    {   // BAND B
                        USBIR.writeUSBIR_Plarail_Speed_Down(handle_usb_device, USBIR.PLARAIL_BAND.BAND_B);
                    }
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBIR.closeUSBIR(handle_usb_device);
                }
            }
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            try
            {
                my_stop();
            }
            catch
            {
            }
        }
        private void my_stop()
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBIR.openUSBIR(this.Handle);
                if (handle_usb_device != null)
                {
                    if (band_type == Constants.BAND_TYPE_A)
                    {   // BAND A
                        USBIR.writeUSBIR_Plarail_Stop(handle_usb_device, USBIR.PLARAIL_BAND.BAND_A);
                    }
                    else if (band_type == Constants.BAND_TYPE_B)
                    {   // BAND B
                        USBIR.writeUSBIR_Plarail_Stop(handle_usb_device, USBIR.PLARAIL_BAND.BAND_A);
                    }
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBIR.closeUSBIR(handle_usb_device);
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Right)
                {
                    my_backward_set();
                    e.Handled = true;
                }
                else if (e.KeyCode == Keys.Left)
                {
                    my_forward_set();
                    e.Handled = true;
                }
                else if (e.KeyCode == Keys.Up)
                {
                    my_speed_up();
                    e.Handled = true;
                }
                else if (e.KeyCode == Keys.Down)
                {
                    my_speed_down();
                    e.Handled = true;
                }
                else if (e.KeyCode == Keys.Escape)
                {
                    my_stop();
                    e.Handled = true;
                }
            }
            catch
            {
            }
        }
    }


    static class Constants
    {
        public const int BAND_TYPE_A = 0; // BAND TYPE A
        public const int BAND_TYPE_B = 1; // BAND TYPE B
        public const int DIRECTION_FORWARD = 0; // DIRECTION FORWARD
        public const int DIRECTION_BACKWARD = 1; // DIRECTION BACKWARD
    }
}
